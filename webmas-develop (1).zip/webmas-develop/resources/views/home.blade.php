@extends('layouts.admin')
@section('content')
<div class="content">
    <div class="row">
        <div class="col-lg-12">
            <div style="display: flex; justify-content: end; align-items: center; align-content: center">
                <div class="form-group">
                    <div class="input-group">
                        <div class="input-group-addon">
                            <i class="fa fa-calendar"></i>
                        </div>
                        <input type="text" name="date" class="form-control pull-right" id="daterange">
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-4 col-xs-6">

            <div class="small-box bg-aqua">
                <div class="inner">
                    <h3 id="penjualan">{{ encodeCurrency($summaryPenjualan) }}</h3>
                    <p>Summary Penjualan</p>
                </div>
                <div class="icon">
                    <i class="fa fa-money"></i>
                </div>
                <a href="{{ route('admin.sales.index') }}" class="small-box-footer">
                    More info <i class="fa fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>

        <div class="col-lg-4 col-xs-6">

            <div class="small-box bg-green">
                <div class="inner">
                    <h3 id="pembelian">{{ encodeCurrency($summaryPembelian) }}</h3>
                    <p>Summary Pembelian</p>
                </div>
                <div class="icon">
                    <i class="fa fa-money"></i>
                </div>
                <a href="{{ route('admin.pembelian.index') }}" class="small-box-footer">
                    More info <i class="fa fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>

        <div class="col-lg-4 col-xs-6">

            <div class="small-box bg-yellow">
                <div class="inner">
                    <h3 id="pemesanan">{{ encodeCurrency($summaryPemesanan) }}</h3>
                    <p>Summary Pemesanan</p>
                </div>
                <div class="icon">
                    <i class="fa fa-money"></i>
                </div>
                <a href="{{ route('admin.pemesanan.index') }}" class="small-box-footer">
                    More info <i class="fa fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>

        <div class="col-lg-6 col-xs-6">

            <div class="small-box bg-black">
                <div class="inner">
                    <h3 id="pelunasan">{{ encodeCurrency($summaryPelunasan) }}</h3>
                    <p>Summary Pelunasan</p>
                </div>
                <div class="icon">
                    <i class="fa fa-money"></i>
                </div>
                <a href="{{ route('admin.pelunasan.index') }}" class="small-box-footer">
                    More info <i class="fa fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>

        <div class="col-lg-6 col-xs-6">

            <div class="small-box bg-red">
                <div class="inner">
                    <h3 id="tukarTambahKurang">{{ encodeCurrency($summaryTukarTambahKurang) }}</h3>
                    <p>Summary Tukar Tambah/Kurang</p>
                </div>
                <div class="icon">
                    <i class="fa fa-money"></i>
                </div>
                <a href="{{ route("admin.tukarTambahKurang.index") }}" class="small-box-footer">
                    More info <i class="fa fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>

    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Dashboard
                </div>

                <div class="panel-body">
                    @if(session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    You are logged in!
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@section('scripts')
<script>
    $('#daterange').daterangepicker()
    $('#daterange').on('apply.daterangepicker', function(ev, picker) {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            type:'GET',
            url:"{{ route('admin.home') }}",
            data:{from:picker.startDate.format('YYYY-MM-DD'), to:picker.endDate.format('YYYY-MM-DD')},
            success:function(data){
                $('#penjualan').text(data.summaryPenjualan)
                $('#pembelian').text(data.summaryPembelian)
                $('#pemesanan').text(data.summaryPemesanan)
                $('#tukarTambahKurang').text(data.summaryTukarTambahKurang)
                $('#pelunasan').text(data.summaryPelunasan)
            }
        });
    });
</script>
@endsection