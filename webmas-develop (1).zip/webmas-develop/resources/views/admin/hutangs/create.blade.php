@extends('layouts.admin')
@section('content')
<div class="content">

    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading" style="display: flex; justify-content: space-between; align-items: center">
                    <div>{{ trans('global.create') }} {{ trans('cruds.hutang.title_singular') }}</div>
                    <div>
                        <a class="btn btn-danger" href="{{ route('admin.hutangs.index') }}">
                            {{ trans('global.back') }} {{ trans('cruds.hutang.title_singular') }}
                        </a>
                    </div>
                </div>
                <div class="panel-body">
                    <form method="POST" action="{{ route("admin.hutangs.store") }}" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group {{ $errors->has('karyawan_id') ? 'has-error' : '' }}">
                            <label class="required" for="karyawan_id">Karyawan</label>
                            <select class="form-control select2" name="karyawan_id" id="karyawan_id" required>
                                @foreach($karyawans as $id => $entry)
                                    <option value="{{ $id }}" {{ old('karyawan_id') == $id ? 'selected' : '' }}>{{ $entry }}</option>
                                @endforeach
                            </select>
                            @if($errors->has('karyawan_id'))
                                <span class="help-block" role="alert">{{ $errors->first('karyawan_id') }}</span>
                            @endif
                            <span class="help-block">{{ trans('cruds.hutang.fields.user_helper') }}</span>
                        </div>
                        <div class="form-group {{ $errors->has('jenis_hutang') ? 'has-error' : '' }}">
                            <label>{{ trans('cruds.hutang.fields.jenis_hutang') }}</label>
                            <select class="form-control select2" name="jenis_hutang" id="jenis_hutang">
                                <option value disabled {{ old('jenis_hutang', null) === null ? 'selected' : '' }}>{{ trans('global.pleaseSelect') }}</option>
                                @foreach(App\Models\Hutang::JENIS_HUTANG_SELECT as $key => $label)
                                    <option value="{{ $key }}" {{ old('jenis_hutang', '') === (string) $key ? 'selected' : '' }}>{{ $label }}</option>
                                @endforeach
                            </select>
                            @if($errors->has('jenis_hutang'))
                                <span class="help-block" role="alert">{{ $errors->first('jenis_hutang') }}</span>
                            @endif
                            <span class="help-block">{{ trans('cruds.hutang.fields.jenis_hutang_helper') }}</span>
                        </div>
                        <livewire:form-hutang-karyawan :jenis_barangs="$jenis_barangs"/>
                        <div class="form-group">
                            <button class="btn btn-danger" type="submit">
                                {{ trans('global.save') }}
                            </button>
                        </div>
                    </form>
                </div>
            </div>



        </div>
    </div>
</div>
@endsection