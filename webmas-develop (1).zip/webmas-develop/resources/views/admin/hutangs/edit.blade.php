@extends('layouts.admin')
@section('content')
<div class="content">

    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading" style="display: flex; justify-content: space-between; align-items: center">
                    <div>{{ trans('global.edit') }} {{ trans('cruds.hutang.title_singular') }}</div>
                    <div>
                        <a class="btn btn-danger" href="{{ route('admin.hutangs.index') }}">
                            {{ trans('global.back') }} {{ trans('cruds.hutang.title_singular') }}
                        </a>
                    </div>
                </div>
                <div class="panel-body">
                    <form method="POST" action="{{ route("admin.hutangs.update", [$hutang->id]) }}" enctype="multipart/form-data">
                        @method('PUT')
                        @csrf
                        <div class="form-group {{ $errors->has('karyawan_id') ? 'has-error' : '' }}">
                            <label class="required" for="karyawan_id">Karyawan</label>
                            <select class="form-control select2" name="karyawan_id" id="karyawan_id" required>
                                @foreach($karyawans as $id => $entry)
                                    <option value="{{ $id }}" {{ (old('karyawan_id') ? old('karyawan_id') : $hutang->karyawan->id ?? '') == $id ? 'selected' : '' }}>{{ $entry }}</option>
                                @endforeach
                            </select>
                            @if($errors->has('karyawan_id'))
                                <span class="help-block" role="alert">{{ $errors->first('karyawan_id') }}</span>
                            @endif
                            <span class="help-block">{{ trans('cruds.hutang.fields.user_helper') }}</span>
                        </div>
                        <div class="form-group {{ $errors->has('jenis_hutang') ? 'has-error' : '' }}">
                            <label>{{ trans('cruds.hutang.fields.jenis_hutang') }}</label>
                            <select class="form-control select2" name="jenis_hutang" id="jenis_hutang">
                                <option value disabled {{ old('jenis_hutang', null) === null ? 'selected' : '' }}>{{ trans('global.pleaseSelect') }}</option>
                                @foreach(App\Models\Hutang::JENIS_HUTANG_SELECT as $key => $label)
                                    <option value="{{ $key }}" {{ old('jenis_hutang', $hutang->jenis_hutang) === (string) $key ? 'selected' : '' }}>{{ $label }}</option>
                                @endforeach
                            </select>
                            @if($errors->has('jenis_hutang'))
                                <span class="help-block" role="alert">{{ $errors->first('jenis_hutang') }}</span>
                            @endif
                            <span class="help-block">{{ trans('cruds.hutang.fields.jenis_hutang_helper') }}</span>
                        </div>
                        <div class="form-group {{ $errors->has('jenis_barang') ? 'has-error' : '' }}">
                            <label class="required" for="jenis_barang_id">{{ trans('cruds.hutang.fields.jenis_barang') }}</label>
                            <select class="form-control select2" name="jenis_barang_id" id="jenis_barang_id" required>
                                @foreach($jenis_barangs as $id => $entry)
                                    <option value="{{ $id }}" {{ (old('jenis_barang_id') ? old('jenis_barang_id') : $hutang->jenis_barang->id ?? '') == $id ? 'selected' : '' }}>{{ $entry }}</option>
                                @endforeach
                            </select>
                            @if($errors->has('jenis_barang'))
                                <span class="help-block" role="alert">{{ $errors->first('jenis_barang') }}</span>
                            @endif
                            <span class="help-block">{{ trans('cruds.hutang.fields.jenis_barang_helper') }}</span>
                        </div>
                        <div class="form-group {{ $errors->has('jumlah_hutang') ? 'has-error' : '' }}">
                            <label class="required" for="jumlah_hutang">{{ trans('cruds.hutang.fields.jumlah_hutang') }}</label>
                            <input class="form-control" type-currency="IDR" type="text" name="jumlah_hutang" id="jumlah_hutang" value="{{ old('jumlah_hutang', encodeCurrency($hutang->jumlah_hutang)) }}" required>
                            @if($errors->has('jumlah_hutang'))
                                <span class="help-block" role="alert">{{ $errors->first('jumlah_hutang') }}</span>
                            @endif
                            <span class="help-block">{{ trans('cruds.hutang.fields.jumlah_hutang_helper') }}</span>
                        </div>
                        <div class="form-group {{ $errors->has('nominal_cicilan') ? 'has-error' : '' }}">
                            <label class="required" for="nominal_cicilan">{{ trans('cruds.hutang.fields.nominal_cicilan') }}</label>
                            <input class="form-control" type-currency="IDR" type="text" name="nominal_cicilan" id="nominal_cicilan" value="{{ old('nominal_cicilan', encodeCurrency($hutang->nominal_cicilan)) }}" required>
                            @if($errors->has('nominal_cicilan'))
                                <span class="help-block" role="alert">{{ $errors->first('nominal_cicilan') }}</span>
                            @endif
                            <span class="help-block">{{ trans('cruds.hutang.fields.nominal_cicilan_helper') }}</span>
                        </div>
                        <div class="form-group {{ $errors->has('lama_cicilan') ? 'has-error' : '' }}">
                            <label class="required" for="lama_cicilan">{{ trans('cruds.hutang.fields.lama_cicilan') }}</label>
                            <input class="form-control" type="number" name="lama_cicilan" id="lama_cicilan" value="{{ old('lama_cicilan', $hutang->lama_cicilan) }}" step="1" required>
                            @if($errors->has('lama_cicilan'))
                                <span class="help-block" role="alert">{{ $errors->first('lama_cicilan') }}</span>
                            @endif
                            <span class="help-block">{{ trans('cruds.hutang.fields.lama_cicilan_helper') }}</span>
                        </div>
                        <div class="form-group">
                            <button class="btn btn-danger" type="submit">
                                {{ trans('global.save') }}
                            </button>
                        </div>
                    </form>
                </div>
            </div>



        </div>
    </div>
</div>
@endsection