@extends('layouts.admin')
@section('content')
<div class="content">

    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    {{ trans('global.show') }} {{ trans('cruds.hutang.title') }}
                </div>
                <div class="panel-body">
                    <div class="form-group">
                        <div class="form-group">
                            <a class="btn btn-default" href="{{ route('admin.hutangs.index') }}">
                                {{ trans('global.back_to_list') }}
                            </a>
                        </div>
                        <table class="table table-bordered table-striped">
                            <tbody>
                                <tr>
                                    <th>
                                        {{ trans('cruds.hutang.fields.id') }}
                                    </th>
                                    <td>
                                        {{ $hutang->id }}
                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        {{ trans('cruds.hutang.fields.user') }}
                                    </th>
                                    <td>
                                        {{ $hutang->karyawan->name ?? '' }}
                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        {{ trans('cruds.hutang.fields.jenis_hutang') }}
                                    </th>
                                    <td>
                                        {{ App\Models\Hutang::JENIS_HUTANG_SELECT[$hutang->jenis_hutang] ?? '' }}
                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        {{ trans('cruds.hutang.fields.jenis_barang') }}
                                    </th>
                                    <td>
                                        {{ $hutang->jenis_barang->jenis ?? '' }}
                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        {{ trans('cruds.hutang.fields.jumlah_hutang') }}
                                    </th>
                                    <td>
                                        {{ $hutang->jumlah_hutang }}
                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        {{ trans('cruds.hutang.fields.nominal_cicilan') }}
                                    </th>
                                    <td>
                                        {{ $hutang->nominal_cicilan }}
                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        {{ trans('cruds.hutang.fields.lama_cicilan') }}
                                    </th>
                                    <td>
                                        {{ $hutang->lama_cicilan }}
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <div class="form-group">
                            <a class="btn btn-default" href="{{ route('admin.hutangs.index') }}">
                                {{ trans('global.back_to_list') }}
                            </a>
                        </div>
                    </div>
                </div>
            </div>



        </div>
    </div>
</div>
@endsection