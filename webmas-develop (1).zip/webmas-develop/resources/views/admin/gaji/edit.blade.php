@extends('layouts.admin')
@section('content')
    <livewire:edit-gaji-karyawan :karyawan-gaji="$gaji"/>
@endsection