@extends('layouts.admin')
@section('content')
  <livewire:create-gaji-karyawan/>
@endsection