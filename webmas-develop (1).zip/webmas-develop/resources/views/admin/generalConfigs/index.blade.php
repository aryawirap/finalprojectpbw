@extends('layouts.admin')
@section('content')
<div class="content">
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading" style="display: flex; justify-content: space-between; align-items: center">
                    <div>{{ trans('global.edit') }} {{ trans('cruds.generalConfig.title_singular') }}</div>
                </div>
                <div class="panel-body">
                    <form method="POST" action="{{ route("admin.general-configs.update",1) }}" enctype="multipart/form-data">
                        @csrf
                        @method('PUT')
                        <div class="form-group {{ $errors->has('website_name') ? 'has-error' : '' }}">
                            <label class="required" for="website_name">{{ trans('cruds.generalConfig.fields.name') }}</label>
                            <input class="form-control" type="text" name="website_name" id="website_name" value="{{ old('website_name', $data->website_name) }}" required>
                            @if($errors->has('website_name'))
                                <span class="help-block" role="alert">{{ $errors->first('website_name') }}</span>
                            @endif
                        </div>
                        <div class="form-group {{ $errors->has('value') ? 'has-error' : '' }}">
                            <label class="required" for="logo">Logo</label>
                            @if(!empty($data->logo))
                            <img style="display: block; margin-bottom: 10px" src="{{ asset($data->logo) }}" width="150"/>
                            @endif
                            <input class="form-control" type="file" name="logo" id="logo" value="{{ old('logo', '') }}">
                            @if($errors->has('logo'))
                                <span class="help-block" role="alert">{{ $errors->first('logo') }}</span>
                            @endif
                        </div>
                        <div class="form-group">
                            <button class="btn btn-danger" type="submit">
                                {{ trans('global.save') }}
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection