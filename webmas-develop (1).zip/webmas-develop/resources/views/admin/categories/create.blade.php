@extends('layouts.admin')
@section('content')
<div class="content">

    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading" style="display: flex; justify-content: space-between; align-items: center">
                    <div>{{ trans('global.create') }} {{ trans('cruds.category.title_singular') }}</div>
                    <div>
                        <a class="btn btn-danger" href="{{ route('admin.categories.index') }}">
                            {{ trans('global.back') }} {{ trans('cruds.category.title_singular') }}
                        </a>
                    </div>
                </div>
                <div class="panel-body">
                    <form method="POST" action="{{ route("admin.categories.store") }}" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group {{ $errors->has('type_emas') ? 'has-error' : '' }}">
                            <label class="required" for="type_emas">{{ trans('cruds.category.fields.type_emas') }}</label>
                            <input class="form-control" type="text" name="type_emas" id="type_emas" value="{{ old('type_emas', '') }}" required>
                            @if($errors->has('type_emas'))
                                <span class="help-block" role="alert">{{ $errors->first('type_emas') }}</span>
                            @endif
                            <span class="help-block">{{ trans('cruds.category.fields.type_emas_helper') }}</span>
                        </div>
                        <div class="form-group">
                            <button class="btn btn-danger" type="submit">
                                {{ trans('global.save') }}
                            </button>
                        </div>
                    </form>
                </div>
            </div>



        </div>
    </div>
</div>
@endsection