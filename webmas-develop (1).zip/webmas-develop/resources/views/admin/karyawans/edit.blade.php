@extends('layouts.admin')
@section('content')
<div class="content">

    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading" style="display: flex; justify-content: space-between; align-items: center">
                    <div>{{ trans('global.edit') }} {{ trans('cruds.karyawan.title_singular') }}</div>
                    <div>
                        <a class="btn btn-danger" href="{{ route('admin.karyawans.index') }}">
                            {{ trans('global.back') }} {{ trans('cruds.karyawan.title_singular') }}
                        </a>
                    </div>
                </div>
                <div class="panel-body">
                    <form method="POST" action="{{ route("admin.karyawans.update", [$karyawan->id]) }}" enctype="multipart/form-data">
                        @method('PUT')
                        @csrf
                        <div class="form-group {{ $errors->has('name') ? 'has-error' : '' }}">
                            <label class="required" for="name">Nama</label>
                            <input class="form-control" type="text" name="name" id="name" value="{{ old('name', $karyawan->name) }}" required>
                            @if($errors->has('name'))
                                <span class="help-block" role="alert">{{ $errors->first('name') }}</span>
                            @endif
                            <span class="help-block">{{ trans('cruds.user.fields.name_helper') }}</span>
                        </div>
                        <div class="form-group {{ $errors->has('alamat') ? 'has-error' : '' }}">
                            <label for="alamat">{{ trans('cruds.karyawan.fields.alamat') }}</label>
                            <textarea class="form-control ckeditor" name="alamat" id="alamat">{!! old('alamat', $karyawan->alamat) !!}</textarea>
                            @if($errors->has('alamat'))
                                <span class="help-block" role="alert">{{ $errors->first('alamat') }}</span>
                            @endif
                            <span class="help-block">{{ trans('cruds.karyawan.fields.alamat_helper') }}</span>
                        </div>
                        <div class="form-group {{ $errors->has('bagian') ? 'has-error' : '' }}">
                            <label class="required" for="bagian">{{ trans('cruds.karyawan.fields.bagian') }}</label>
                            <input class="form-control" type="text" name="bagian" id="bagian" value="{{ old('bagian', $karyawan->bagian) }}" required>
                            @if($errors->has('bagian'))
                                <span class="help-block" role="alert">{{ $errors->first('bagian') }}</span>
                            @endif
                            <span class="help-block">{{ trans('cruds.karyawan.fields.bagian_helper') }}</span>
                        </div>
                        <div class="form-group {{ $errors->has('gaji') ? 'has-error' : '' }}">
                            <label class="required" for="gaji">{{ trans('cruds.karyawan.fields.gaji') }}</label>
                            <input class="form-control" type="text" type-currency="IDR" name="gaji" id="gaji" value="{{ old('gaji', encodeCurrency($karyawan->gaji)) }}" required>
                            @if($errors->has('gaji'))
                                <span class="help-block" role="alert">{{ $errors->first('gaji') }}</span>
                            @endif
                            <span class="help-block">{{ trans('cruds.karyawan.fields.gaji_helper') }}</span>
                        </div>
                        <div class="form-group {{ $errors->has('tanggal_masuk') ? 'has-error' : '' }}">
                            <label class="required" for="tanggal_masuk">{{ trans('cruds.karyawan.fields.tanggal_masuk') }}</label>
                            <input class="form-control date" type="text" name="tanggal_masuk" id="tanggal_masuk" value="{{ old('tanggal_masuk', $karyawan->tanggal_masuk) }}" required>
                            @if($errors->has('tanggal_masuk'))
                                <span class="help-block" role="alert">{{ $errors->first('tanggal_masuk') }}</span>
                            @endif
                            <span class="help-block">{{ trans('cruds.karyawan.fields.tanggal_masuk_helper') }}</span>
                        </div>
                        <div class="form-group {{ $errors->has('tanggal_keluar') ? 'has-error' : '' }}">
                            <label for="tanggal_keluar">{{ trans('cruds.karyawan.fields.tanggal_keluar') }}</label>
                            <input class="form-control date" type="text" name="tanggal_keluar" id="tanggal_keluar" value="{{ old('tanggal_keluar', $karyawan->tanggal_keluar) }}">
                            @if($errors->has('tanggal_keluar'))
                                <span class="help-block" role="alert">{{ $errors->first('tanggal_keluar') }}</span>
                            @endif
                            <span class="help-block">{{ trans('cruds.karyawan.fields.tanggal_keluar_helper') }}</span>
                        </div>
                        <div class="form-group">
                            <button class="btn btn-danger" type="submit">
                                {{ trans('global.save') }}
                            </button>
                        </div>
                    </form>
                </div>
            </div>



        </div>
    </div>
</div>
@endsection

@section('scripts')
<script>
    $(document).ready(function () {
  function SimpleUploadAdapter(editor) {
    editor.plugins.get('FileRepository').createUploadAdapter = function(loader) {
      return {
        upload: function() {
          return loader.file
            .then(function (file) {
              return new Promise(function(resolve, reject) {
                // Init request
                var xhr = new XMLHttpRequest();
                xhr.open('POST', '{{ route('admin.karyawans.storeCKEditorImages') }}', true);
                xhr.setRequestHeader('x-csrf-token', window._token);
                xhr.setRequestHeader('Accept', 'application/json');
                xhr.responseType = 'json';

                // Init listeners
                var genericErrorText = `Couldn't upload file: ${ file.name }.`;
                xhr.addEventListener('error', function() { reject(genericErrorText) });
                xhr.addEventListener('abort', function() { reject() });
                xhr.addEventListener('load', function() {
                  var response = xhr.response;

                  if (!response || xhr.status !== 201) {
                    return reject(response && response.message ? `${genericErrorText}\n${xhr.status} ${response.message}` : `${genericErrorText}\n ${xhr.status} ${xhr.statusText}`);
                  }

                  $('form').append('<input type="hidden" name="ck-media[]" value="' + response.id + '">');

                  resolve({ default: response.url });
                });

                if (xhr.upload) {
                  xhr.upload.addEventListener('progress', function(e) {
                    if (e.lengthComputable) {
                      loader.uploadTotal = e.total;
                      loader.uploaded = e.loaded;
                    }
                  });
                }

                // Send request
                var data = new FormData();
                data.append('upload', file);
                data.append('crud_id', '{{ $karyawan->id ?? 0 }}');
                xhr.send(data);
              });
            })
        }
      };
    }
  }

  var allEditors = document.querySelectorAll('.ckeditor');
  for (var i = 0; i < allEditors.length; ++i) {
    ClassicEditor.create(
      allEditors[i], {
        extraPlugins: [SimpleUploadAdapter]
      }
    );
  }
});
</script>

@endsection