@extends('layouts.admin')
@section('content')
<div class="content">

    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    {{ trans('global.show') }} {{ trans('cruds.karyawan.title') }}
                </div>
                <div class="panel-body">
                    <div class="form-group">
                        <div class="form-group">
                            <a class="btn btn-default" href="{{ route('admin.karyawans.index') }}">
                                {{ trans('global.back_to_list') }}
                            </a>
                        </div>
                        <table class="table table-bordered table-striped">
                            <tbody>
                                <tr>
                                    <th>
                                        {{ trans('cruds.karyawan.fields.id') }}
                                    </th>
                                    <td>
                                        {{ $karyawan->id }}
                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        {{ trans('cruds.karyawan.fields.user') }}
                                    </th>
                                    <td>
                                        {{ $karyawan->name ?? '' }}
                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        {{ trans('cruds.karyawan.fields.alamat') }}
                                    </th>
                                    <td>
                                        {!! $karyawan->alamat !!}
                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        {{ trans('cruds.karyawan.fields.bagian') }}
                                    </th>
                                    <td>
                                        {{ $karyawan->bagian }}
                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        {{ trans('cruds.karyawan.fields.gaji') }}
                                    </th>
                                    <td>
                                        {{ $karyawan->gaji }}
                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        {{ trans('cruds.karyawan.fields.tanggal_masuk') }}
                                    </th>
                                    <td>
                                        {{ $karyawan->tanggal_masuk }}
                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        {{ trans('cruds.karyawan.fields.tanggal_keluar') }}
                                    </th>
                                    <td>
                                        {{ $karyawan->tanggal_keluar }}
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <div class="form-group">
                            <a class="btn btn-default" href="{{ route('admin.karyawans.index') }}">
                                {{ trans('global.back_to_list') }}
                            </a>
                        </div>
                    </div>
                </div>
            </div>



        </div>
    </div>
</div>
@endsection