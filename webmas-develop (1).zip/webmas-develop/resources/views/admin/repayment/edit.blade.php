@extends('layouts.admin')
@section('content')
<div class="content">
    <livewire:edit-pelunasan :pelunasanData="$pelunasan"/>
</div>
@endsection