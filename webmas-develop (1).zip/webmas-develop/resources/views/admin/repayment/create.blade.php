@extends('layouts.admin')
@section('content')
<div class="content">
    <livewire:create-pelunasan/>
</div>
@endsection