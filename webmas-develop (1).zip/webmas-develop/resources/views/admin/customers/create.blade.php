@extends('layouts.admin')
@section('content')
<div class="content">

    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading" style="display: flex; justify-content: space-between; align-items: center">
                    <div>{{ trans('global.create') }} {{ trans('cruds.customer.title_singular') }}</div>
                    <div>
                        <a class="btn btn-danger" href="{{ route('admin.customers.index') }}">
                            {{ trans('global.back') }} {{ trans('cruds.customer.title_singular') }}
                        </a>
                    </div>
                </div>
                <div class="panel-body">
                    <form method="POST" action="{{ route("admin.customers.store") }}" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group {{ $errors->has('nama') ? 'has-error' : '' }}">
                            <label for="nama">{{ trans('cruds.customer.fields.nama') }}</label>
                            <input class="form-control" type="text" name="nama" id="nama" value="{{ old('nama', '') }}">
                            @if($errors->has('nama'))
                                <span class="help-block" role="alert">{{ $errors->first('nama') }}</span>
                            @endif
                            <span class="help-block">{{ trans('cruds.customer.fields.nama_helper') }}</span>
                        </div>
                        <div class="form-group {{ $errors->has('email') ? 'has-error' : '' }}">
                            <label for="email">{{ trans('cruds.customer.fields.email') }}</label>
                            <input class="form-control" type="text" name="email" id="email" value="{{ old('email', '') }}">
                            @if($errors->has('email'))
                                <span class="help-block" role="alert">{{ $errors->first('email') }}</span>
                            @endif
                            <span class="help-block">{{ trans('cruds.customer.fields.email_helper') }}</span>
                        </div>
                        <div class="form-group {{ $errors->has('nomor_hp') ? 'has-error' : '' }}">
                            <label for="nomor_hp">{{ trans('cruds.customer.fields.nomor_hp') }}</label>
                            <input class="form-control" type="text" name="nomor_hp" id="nomor_hp" value="{{ old('nomor_hp', '') }}">
                            @if($errors->has('nomor_hp'))
                                <span class="help-block" role="alert">{{ $errors->first('nomor_hp') }}</span>
                            @endif
                            <span class="help-block">{{ trans('cruds.customer.fields.nomor_hp_helper') }}</span>
                        </div>
                        <div class="form-group">
                            <button class="btn btn-danger" type="submit">
                                {{ trans('global.save') }}
                            </button>
                        </div>
                    </form>
                </div>
            </div>



        </div>
    </div>
</div>
@endsection