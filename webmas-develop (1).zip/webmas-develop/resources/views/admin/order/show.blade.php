@extends('layouts.admin')
@section('content')
<div class="content">

    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    {{ trans('global.show') }} {{ trans('cruds.sale.title') }}
                </div>
                <div class="panel-body">
                    <div class="form-group">
                        <div class="form-group">
                            <a class="btn btn-default" href="{{ route('admin.sales.index') }}">
                                {{ trans('global.back_to_list') }}
                            </a>
                        </div>
                        <table class="table table-bordered table-striped">
                            <tbody>
                                <tr>
                                    <th>
                                        {{ trans('cruds.sale.fields.id') }}
                                    </th>
                                    <td>
                                        {{ $sale->id }}
                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        {{ trans('cruds.sale.fields.no_trx') }}
                                    </th>
                                    <td>
                                        {{ $sale->no_trx }}
                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        {{ trans('cruds.sale.fields.nama_customer') }}
                                    </th>
                                    <td>
                                        {{ $sale->nama_customer }}
                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        {{ trans('cruds.sale.fields.nomor_hp') }}
                                    </th>
                                    <td>
                                        {{ $sale->nomor_hp }}
                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        {{ trans('cruds.sale.fields.total_kuitansi') }}
                                    </th>
                                    <td>
                                        {{ $sale->total_kuitansi }}
                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        {{ trans('cruds.sale.fields.grand_total') }}
                                    </th>
                                    <td>
                                        {{ $sale->grand_total }}
                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        {{ trans('cruds.sale.fields.metode_pembayaran') }}
                                    </th>
                                    <td>
                                        @foreach($sale->metode_pembayarans as $key => $metode_pembayaran)
                                            <span class="label label-info">{{ $metode_pembayaran->nama_metode }}</span>
                                        @endforeach
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <div class="form-group">
                            <a class="btn btn-default" href="{{ route('admin.sales.index') }}">
                                {{ trans('global.back_to_list') }}
                            </a>
                        </div>
                    </div>
                </div>
            </div>



        </div>
    </div>
</div>
@endsection