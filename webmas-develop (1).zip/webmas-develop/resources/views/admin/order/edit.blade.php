@extends('layouts.admin')
@section('content')
<div class="content">
    <livewire:edit-pemesanan :pemesananData="$pemesanan"/>
</div>
@endsection