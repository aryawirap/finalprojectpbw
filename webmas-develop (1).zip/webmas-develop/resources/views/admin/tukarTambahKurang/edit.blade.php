@extends('layouts.admin')
@section('content')
    <div class="content">
        <livewire:edit-tukar-tambah-kurang :tukarTambahKurangData="$tukarTambahKurang"/>
    </div>
@endsection