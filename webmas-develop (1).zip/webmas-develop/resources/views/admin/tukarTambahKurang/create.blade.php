@extends('layouts.admin')
@section('content')
    <div class="content">
        <livewire:create-tukar-tambah-kurang/>
    </div>
@endsection