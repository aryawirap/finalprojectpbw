@extends('layouts.admin')
@section('content')
    <div class="content">
        <div style="margin-bottom: 10px;" class="row">
            <div class="col-lg-12">
                <div style="display: flex; justify-content: space-between; align-items: center; align-content: center">
                    <button class="btn btn-success" id="btnExportClick" type="button">Export</button>
                    <div class="form-group">
                        <div class="input-group">
                            <div class="input-group-addon">
                                <i class="fa fa-calendar"></i>
                            </div>
                            <input type="text" name="date" class="form-control pull-right" id="daterange">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-4 col-xs-12">

                <div class="small-box bg-aqua">
                    <div class="inner">
                        <h3 id="berangkas">{{ encodeCurrency($summaryBerangkas) }}</h3>
                        <p>Summary Berangkas</p>
                    </div>
                    <div class="icon">
                        <i class="fa fa-money"></i>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-xs-12">

                <div class="small-box bg-green">
                    <div class="inner">
                        <h3 id="uangMasuk">{{ encodeCurrency($summaryUangMasuk) }}</h3>
                        <p>Summary Uang Masuk</p>
                    </div>
                    <div class="icon">
                        <i class="fa fa-money"></i>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-xs-12">

                <div class="small-box bg-yellow">
                    <div class="inner">
                        <h3 id="uangKeluar">{{ encodeCurrency($summaryUangKeluar) }}</h3>
                        <p>Summary Uang Keluar</p>
                    </div>
                    <div class="icon">
                        <i class="fa fa-money"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        {{ trans('cruds.CashOpname.title_singular') }}
                    </div>
                    <div class="panel-body">
                        <table class="table table-bordered table-sm">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Tanggal</th>
                                    <th>Type</th>
                                    <th>Total</th>
                                    <th width="10%">Action</th>
                                </tr>
                            </thead>
                            <tbody id="tbl_cashOpname">
                                @foreach($listData as $data)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>{{ date('d-m-Y') }}</td>
                                        <td>{{ $data['name'] }}</td>
                                        <td>{{ encodeCurrency($data['amount']) }}</td>
                                        <td>
                                            @if($data['name'] === 'Penjualan')
                                            <a href="{{ route('admin.sales.index',['from' => date('d-m-Y'),'to' => date('d-m-Y')]) }}" class="btn btn-primary">Detail</a>
                                            @elseif($data['name'] === 'Pembelian')
                                            <a href="{{ route('admin.pembelian.index',['from' => date('d-m-Y'),'to' => date('d-m-Y')]) }}" class="btn btn-primary">Detail</a>
                                            @elseif($data['name'] === 'Pemesanan')
                                            <a href="{{ route('admin.pemesanan.index',['from' => date('d-m-Y'),'to' => date('d-m-Y')]) }}" class="btn btn-primary">Detail</a>
                                            @elseif($data['name'] === 'Pelunasan')
                                                <a href="{{ route('admin.pelunasan.index',['from' => date('d-m-Y'),'to' => date('d-m-Y')]) }}" class="btn btn-primary">Detail</a>
                                            @elseif($data['name'] === 'Form pengurangan' || $data['name'] === 'Form penambahan')
                                            <a href="{{ route('admin.berangkas.index',['from' => date('d-m-Y'),'to' => date('d-m-Y')]) }}" class="btn btn-primary">Detail</a>
                                            @elseif($data['name'] === 'Tukar Tambah' || $data['name'] === 'Tukar Kurang')
                                                <a href="{{ route('admin.tukarTambahKurang.index',['from' => date('d-m-Y'),'to' => date('d-m-Y')]) }}" class="btn btn-primary">Detail</a>
                                            @endif
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('scripts')
    <script>
        $('#daterange').daterangepicker()
        $('#btnExportClick').on('click',function (){
            const dateFilter = $('#daterange').data('daterangepicker')
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type:'GET',
                url:"{{ route('admin.cashOpname.index') }}",
                data:{from:dateFilter.startDate.format('YYYY-MM-DD'), to:dateFilter.endDate.format('YYYY-MM-DD'), type:'export'},
                xhrFields: {
                    responseType: 'blob'
                },
                success:function(data){
                    console.log(data)
                    var blob = new Blob([data]);
                    var link = document.createElement('a');
                    link.href = window.URL.createObjectURL(blob);
                    link.download = `cashOpnameData-${dateFilter.startDate.format('YYYY-MM-DD')}-${dateFilter.endDate.format('YYYY-MM-DD')}.pdf`;
                    link.click();
                }
            });
        })
        $('#daterange').on('apply.daterangepicker', function(ev, picker) {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type:'GET',
                url:"{{ route('admin.cashOpname.index') }}",
                data:{from:picker.startDate.format('YYYY-MM-DD'), to:picker.endDate.format('YYYY-MM-DD')},
                success:function(data){
                    $('#uangMasuk').text(data.summaryUangMasuk)
                    $('#uangKeluar').text(data.summaryUangKeluar)
                    $('#berangkas').text(data.summaryBerangkas)

                    let from = picker.startDate.format('YYYY-MM-DD');
                    let to = picker.endDate.format('YYYY-MM-DD');
                    let listData = data.data;
                    let appd = ``

                    listData.forEach((e,index) => {
                        let tanggal = e.tanggal;
                        let act = ''
                        if(e.name === 'Penjualan'){
                            act = `<a href="{{ route('admin.sales.index') }}?from=${from}&to=${to}" class="btn btn-primary">Detail</a>`
                        } else if(e.name === 'Pembelian'){
                            act = `<a href="{{ route('admin.pembelian.index') }}?from=${from}&to=${to}" class="btn btn-primary">Detail</a>`
                        }else if(e.name === 'Pemesanan'){
                            act = `<a href="{{ route('admin.pemesanan.index') }}?from=${from}&to=${to}" class="btn btn-primary">Detail</a>`
                        }else if(e.name === 'Pelunasan'){
                            act = `<a href="{{ route('admin.pelunasan.index') }}?from=${from}&to=${to}" class="btn btn-primary">Detail</a>`
                        }else if(e.name === 'Form pengurangan' || e.name === 'Form penambahan'){
                            act = `<a href="{{ route('admin.berangkas.index') }}?from=${from}&to=${to}" class="btn btn-primary">Detail</a>`
                        }else if(e.name === 'Tukar Tambah' || e.name === 'Tukar Kurang'){
                            act = `<a href="{{ route('admin.tukarTambahKurang.index') }}?from=${from}&to=${to}" class="btn btn-primary">Detail</a>`
                        }

                        appd += `<tr>
                            <td>${index+1}</td>
                            <td>${tanggal}</td>
                            <td>${e.name}</td>
                            <td>${e.amount}</td>
                            <td>
                                ${act}
                            </td>
                        </tr>`
                    })
                    $("#tbl_cashOpname").html(appd)
                }
            });
        });
    </script>
@endsection