@extends('layouts.admin')
@section('content')
<div class="content">
    <livewire:edit-pembelian :pembelianData="$pembelian"/>
</div>
@endsection