@extends('layouts.admin')
@section('content')
<div class="content">
    <livewire:create-pembelian/>
</div>
@endsection