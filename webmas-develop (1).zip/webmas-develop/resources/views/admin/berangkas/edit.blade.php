@extends('layouts.admin')
@section('content')
    <div class="content">

        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading" style="display: flex; justify-content: space-between; align-items: center">
                        <div>{{ trans('global.edit') }} {{ trans('cruds.Berangkas.title_singular') }}</div>
                        <div>
                            <a class="btn btn-danger" href="{{ route('admin.berangkas.index') }}">
                                {{ trans('global.back') }} {{ trans('cruds.Berangkas.title_singular') }}
                            </a>
                        </div>
                    </div>
                    <div class="panel-body">
                        <form method="POST" action="{{ route("admin.berangkas.update", $berangka->id) }}" enctype="multipart/form-data">
                            @csrf
                            @method("PUT")
                            <div class="form-group {{ $errors->has('tanggal') ? 'has-error' : '' }}">
                                <label class="required" for="tanggal">{{ trans('cruds.Berangkas.fields.tanggal') }}</label>
                                <input class="form-control" type="date" name="tanggal" id="tanggal" value="{{ old('tanggal', $berangka->tanggal) }}" required>
                                @if($errors->has('tanggal'))
                                    <span class="help-block" role="alert">{{ $errors->first('tanggal') }}</span>
                                @endif
                                <span class="help-block">{{ trans('cruds.Berangkas.fields.tanggal_helper') }}</span>
                            </div>
                            <div class="form-group {{ $errors->has('type_berangkas') ? 'has-error' : '' }}">
                                <label class="required" for="type_berangkas">{{ trans('cruds.Berangkas.fields.type_berangkas') }}</label>
                                <select class="form-control" name="type_berangkas" id="type_berangkas" required>>
                                    <option value="">- Pilih -</option>
                                    <option @selected(old('type_berangkas', $berangka->type_berangkas) == "1") value="1">Berangkas</option>
                                    <option @selected(old('type_berangkas', $berangka->type_berangkas) == "2") value="2">Uang Masuk</option>
                                    <option @selected(old('type_berangkas', $berangka->type_berangkas) == "3") value="3">Uang Keluar</option>
                                </select>
                                @if($errors->has('type_berangkas'))
                                    <span class="help-block" role="alert">{{ $errors->first('type_berangkas') }}</span>
                                @endif
                                <span class="help-block">{{ trans('cruds.Berangkas.fields.type_berangkas_helper') }}</span>
                            </div>
                            <div class="form-group {{ $errors->has('type') ? 'has-error' : '' }}">
                                <label class="required" for="type">{{ trans('cruds.Berangkas.fields.type') }}</label>
                                <select class="form-control" name="type" id="type" required>>
                                    <option value="">- Pilih -</option>
                                    <option @selected(old('type', $berangka->type) == "1") value="1">Pengurangan</option>
                                    <option @selected(old('type', $berangka->type) == "2") value="2">Penambahan</option>
                                </select>
                                @if($errors->has('type'))
                                    <span class="help-block" role="alert">{{ $errors->first('type') }}</span>
                                @endif
                                <span class="help-block">{{ trans('cruds.Berangkas.fields.type_helper') }}</span>
                            </div>
                            <div class="form-group {{ $errors->has('jumlah') ? 'has-error' : '' }}">
                                <label class="required" for="jumlah">{{ trans('cruds.Berangkas.fields.jumlah') }}</label>
                                <input class="form-control" type="text"  type-currency="IDR" name="jumlah" id="jumlah" value="{{ old('jumlah', encodeCurrency($berangka->jumlah)) }}" required>
                                @if($errors->has('jumlah'))
                                    <span class="help-block" role="alert">{{ $errors->first('jumlah') }}</span>
                                @endif
                                <span class="help-block">{{ trans('cruds.Berangkas.fields.jumlah_helper') }}</span>
                            </div>

                            <div class="form-group {{ $errors->has('keterangan') ? 'has-error' : '' }}">
                                <label class="required" for="keterangan">{{ trans('cruds.Berangkas.fields.keterangan') }}</label>
                                <textarea class="form-control" rows="5" cols="10" id="keterangan" name="keterangan">{{ old('keterangan', $berangka->keterangan) }}</textarea>
                                @if($errors->has('keterangan'))
                                    <span class="help-block" role="alert">{{ $errors->first('keterangan') }}</span>
                                @endif
                                <span class="help-block">{{ trans('cruds.Berangkas.fields.keterangan_helper') }}</span>
                            </div>

                            <div class="form-group">
                                <button class="btn btn-danger" type="submit">
                                    {{ trans('global.save') }}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>



            </div>
        </div>
    </div>
@endsection