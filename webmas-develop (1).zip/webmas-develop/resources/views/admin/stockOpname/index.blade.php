@extends('layouts.admin')
@section('content')
    <div class="content">
        <div class="row">
            @if(session()->get("success"))
                <div class="col-lg-12">
                    <div class="alert alert-info alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ session()->get("success") }}</strong>
                    </div>
                </div>
            @endif
            <div class="col-lg-12">
                <div style="display: flex; justify-content: space-between; align-items: center; align-content: center">
                    <button class="btn btn-success" id="btnExportClick" type="button">Export</button>
                    <div class="form-group">
                        <div class="input-group">
                            <div class="input-group-addon">
                                <i class="fa fa-calendar"></i>
                            </div>
                            <input type="text" name="date" class="form-control pull-right" id="daterange">
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <div style="display: flex; justify-content: space-between; align-items: center">
                            <div>{{ trans('cruds.StockOpname.title_singular') }} {{ trans('global.list') }}</div>
                            <div>
                                <form method="POST" action="{{ route("admin.stockOpname.syncStock") }}">
                                    @csrf
                                    <label>
                                        <input type="hidden" name="tanggal" value="{{ date("Y-m-d") }}"/>
                                    </label>
                                    <button type="submit" class="btn btn-md btn-success" style="margin-bottom: 10px">Synchronize stock Opname {{ date("Y-m-d") }}</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="panel-body">
                        <table class=" table table-bordered table-striped table-hover ajaxTable datatable datatable-Karyawan">
                            <thead>
                            <tr>
                                <th>
                                    {{ trans('cruds.StockOpname.fields.tanggal') }}
                                </th>
                                <th>
                                    Nama barang
                                </th>
                                <th>
                                    {{ trans('cruds.StockOpname.fields.stock_awal') }}
                                </th>
                                <th>
                                    Stock Keluar
                                </th>
                                <th>
                                    Penambahan
                                </th>
                                <th>
                                    Total
                                </th>
                                <th>
                                    &nbsp;
                                </th>
                            </tr>
                            <tr>
                                <td>
                                    <input class="search" type="text" placeholder="{{ trans('global.search') }}">
                                </td>
                                <td>
                                    <input class="search" type="text" placeholder="{{ trans('global.search') }}">
                                </td>
                                <td>
                                </td>
                                <td>

                                </td>
                                <td>

                                </td>
                                <td>

                                </td>
                                <td>
                                </td>
                            </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('scripts')
    @parent
    <script>
        $(function () {
            let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
            @can('stockOpname_delete')
            let deleteButtonTrans = '{{ trans('global.datatables.delete') }}';
            let deleteButton = {
                text: deleteButtonTrans,
                url: "{{ route('admin.karyawans.massDestroy') }}",
                className: 'btn-danger',
                action: function (e, dt, node, config) {
                    var ids = $.map(dt.rows({ selected: true }).data(), function (entry) {
                        return entry.id
                    });

                    if (ids.length === 0) {
                        alert('{{ trans('global.datatables.zero_selected') }}')

                        return
                    }

                    if (confirm('{{ trans('global.areYouSure') }}')) {
                        $.ajax({
                            headers: {'x-csrf-token': _token},
                            method: 'POST',
                            url: config.url,
                            data: { ids: ids, _method: 'DELETE' }})
                            .done(function () { location.reload() })
                    }
                }
            }
            dtButtons.push(deleteButton)
            @endcan
            const newBtn = dtButtons.map(obj => {
                if(obj.exportOptions != undefined){
                    obj.exportOptions.columns = [0, 1, 2, 3, 4, 5]
                }
                return obj
            }).filter(e => e.extend !== 'colvis' && e.extend !== 'selectAll' && e.extend !== 'selectNone')

            let dtOverrideGlobals = {
                buttons: newBtn,
                columnDefs: [{
                    orderable: false,
                    searchable: false,
                    targets: -1
                }],
                processing: true,
                serverSide: true,
                retrieve: true,
                aaSorting: [],
                ajax: "{{ route('admin.stockOpname.index') }}",
                columns: [
                    { data: 'tanggal', name: 'tanggal' },
                    { data: 'stock_id', name: 'stock_id' },
                    { data: 'stock_awal', name: 'stock_awal' },
                    { data: 'stockKeluar', name: 'stockKeluar', searchable:false },
                    { data: 'penambahan', name: 'penambahan', searchable:false },
                    { data: 'total', name: 'total', searchable:false },
                    { data: 'actions', name: '{{ trans('global.actions') }}' }
                ],
                orderCellsTop: true,
                order: [[ 1, 'desc' ]],
                pageLength: 100,
            };
            let table = $('.datatable-Karyawan').DataTable(dtOverrideGlobals);
            $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
                $($.fn.dataTable.tables(true)).DataTable()
                    .columns.adjust();
            });

            let visibleColumnsIndexes = null;
            $('.datatable thead').on('input', '.search', function () {
                let strict = $(this).attr('strict') || false
                let value = strict && this.value ? "^" + this.value + "$" : this.value

                let index = $(this).parent().index()
                if (visibleColumnsIndexes !== null) {
                    index = visibleColumnsIndexes[index]
                }

                table
                    .column(index)
                    .search(value, strict)
                    .draw()
            });
        });


        $('#daterange').daterangepicker()
        $('#btnExportClick').on('click',function (){
            const dateFilter = $('#daterange').data('daterangepicker')
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type:'GET',
                url:"{{ route('admin.stockOpname.index') }}",
                data:{from:dateFilter.startDate.format('YYYY-MM-DD'), to:dateFilter.endDate.format('YYYY-MM-DD'), type:'export'},
                xhrFields: {
                    responseType: 'blob'
                },
                success:function(data){
                    console.log(data)
                    var blob = new Blob([data]);
                    var link = document.createElement('a');
                    link.href = window.URL.createObjectURL(blob);
                    link.download = `stockOpnameData-${dateFilter.startDate.format('YYYY-MM-DD')}-${dateFilter.endDate.format('YYYY-MM-DD')}.pdf`;
                    link.click();
                }
            });
        })
    </script>
@endsection