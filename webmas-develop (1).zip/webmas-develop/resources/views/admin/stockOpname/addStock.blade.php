@extends('layouts.admin')
@section('content')
    <div class="content">

        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        {{ trans('global.create') }} {{ trans('cruds.stock.title') }} {{ \Carbon\Carbon::createFromFormat("Y-m-d", $tgl)->format("d F Y") }}
                    </div>
                    <div class="panel-body">
                        <div class="form-group">
                            <div class="form-group">
                                <a class="btn btn-default" href="{{ route('admin.stockOpname.index') }}">
                                    {{ trans('global.back_to_list') }}
                                </a>
                            </div>
                            <form action="{{ route("admin.stockOpname.store") }}" method="POST">
                                @csrf
                                <div class="form-group">
                                    <label class="required" for="jumlah">
                                        Jumlah
                                    </label>
                                    <input type="number" id="jumlah" name="jumlah" placeholder="Masukan jumlah penambahan" class="form-control" required/>
                                    <input type="hidden" id="tgl" name="tgl" value="{{ $tgl }}" class="form-control" required/>
                                    <input type="hidden" id="StockOpnameId" name="StockOpnameId" value="{{ $stockOpname->id }}" class="form-control" required/>
                                </div>
                                <div class="form-group">
                                    <label class="required" for="catatan">
                                        Catatan
                                    </label>
                                    <textarea class="form-control" placeholder="Catatan" name="catatan" id="catatan"></textarea>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary">Tambah</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection