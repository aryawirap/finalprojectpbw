@extends('layouts.admin')
@section('content')
    <div class="content">

        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        {{ trans('global.show') }} {{ trans('cruds.StockOpname.title') }}
                    </div>
                    <div class="panel-body">
                        <div class="form-group">
                            <div class="form-group">
                                <a class="btn btn-default" href="{{ route('admin.stockOpname.index') }}">
                                    {{ trans('global.back_to_list') }}
                                </a>
                            </div>
                            <table class="table table-bordered table-striped">
                                <tr>
                                    <th>Type</th>
                                    <th>Jumlah</th>
                                    <th>Penjualan</th>
                                    <th>Catatan</th>
                                    <th>Created</th>
                                    <th>Act</th>
                                </tr>
                                @forelse($stockOpname->stockOpnameDetail as $row)
                                    <tr>
                                        <td>{{ $row->type == 1 ? 'Pengurangan' : 'Penambahan' }}</td>
                                        <td>{{ $row->jumlah }}</td>
                                        <td>
                                            @if($row->penjualan_id)
                                                <a href="{{ route('admin.sales.invoice',$row->penjualan_id) }}" target="_blank">Invoice</a>
                                            @else
                                                -
                                            @endif
                                        </td>
                                        <td>{{ $row->catatan }}</td>
                                        <td>{{ $row->created_at->format("d F Y, H:i:s") }}</td>
                                        <td>
                                            @if($row->type == 2)
                                                <form action="{{ route("admin.stockOpname.deleteStock", $row->id) }}" method="POST">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button class="btn btn-danger btn-sm">Hapus</button>
                                                </form>
                                            @else
                                                -
                                            @endif
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="5" style="text-align: center">Tidak terdapat history</td>
                                    </tr>
                                @endforelse
                            </table>
                            <div class="form-group">
                                <a class="btn btn-default" href="{{ route('admin.stockOpname.index') }}">
                                    {{ trans('global.back_to_list') }}
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection