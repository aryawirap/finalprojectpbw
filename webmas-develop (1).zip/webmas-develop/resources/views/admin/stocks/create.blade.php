@extends('layouts.admin')
@section('content')
<div class="content">

    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading" style="display: flex; justify-content: space-between; align-items: center">
                    <div>{{ trans('global.create') }} {{ trans('cruds.stock.title_singular') }}</div>
                    <div>
                        <a class="btn btn-danger" href="{{ route('admin.stocks.index') }}">
                            {{ trans('global.back') }} {{ trans('cruds.stock.title_singular') }}
                        </a>
                    </div>
                </div>
                <div class="panel-body">
                    <form method="POST" action="{{ route("admin.stocks.store") }}" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group {{ $errors->has('nama_barang') ? 'has-error' : '' }}">
                            <label class="required" for="nama_barang">{{ trans('cruds.stock.fields.nama_barang') }}</label>
                            <input class="form-control" type="text" name="nama_barang" id="nama_barang" value="{{ old('nama_barang', '') }}" required>
                            @if($errors->has('nama_barang'))
                                <span class="help-block" role="alert">{{ $errors->first('nama_barang') }}</span>
                            @endif
                            <span class="help-block">{{ trans('cruds.stock.fields.nama_barang_helper') }}</span>
                        </div>
                        <div class="form-group {{ $errors->has('category') ? 'has-error' : '' }}">
                            <label for="category_id">{{ trans('cruds.stock.fields.category') }}</label>
                            <select class="form-control select2" name="category_id" id="category_id">
                                @foreach($categories as $id => $entry)
                                    <option value="{{ $id }}" {{ old('category_id') == $id ? 'selected' : '' }}>{{ $entry }}</option>
                                @endforeach
                            </select>
                            @if($errors->has('category'))
                                <span class="help-block" role="alert">{{ $errors->first('category') }}</span>
                            @endif
                            <span class="help-block">{{ trans('cruds.stock.fields.category_helper') }}</span>
                        </div>
                        <div class="form-group {{ $errors->has('jumlah_product') ? 'has-error' : '' }}">
                            <label class="required" for="jumlah_product">{{ trans('cruds.stock.fields.jumlah_product') }}</label>
                            <input class="form-control" type="number" name="jumlah_product" id="jumlah_product" value="{{ old('jumlah_product', '') }}" step="1" required>
                            @if($errors->has('jumlah_product'))
                                <span class="help-block" role="alert">{{ $errors->first('jumlah_product') }}</span>
                            @endif
                            <span class="help-block">{{ trans('cruds.stock.fields.jumlah_product_helper') }}</span>
                        </div>
                        <div class="form-group {{ $errors->has('berat') ? 'has-error' : '' }}">
                            <label for="berat">{{ trans('cruds.stock.fields.berat') }}</label>
                            <input class="form-control" type="number" name="berat" id="berat" value="{{ old('berat', '') }}" step="0.01">
                            @if($errors->has('berat'))
                                <span class="help-block" role="alert">{{ $errors->first('berat') }}</span>
                            @endif
                            <span class="help-block">{{ trans('cruds.stock.fields.berat_helper') }}</span>
                        </div>
                        <div class="form-group {{ $errors->has('karat') ? 'has-error' : '' }}">
                            <label for="karat">{{ trans('cruds.stock.fields.karat') }}</label>
                            <input class="form-control" type="number" name="karat" id="karat" value="{{ old('karat', '') }}" step="0.01">
                            @if($errors->has('karat'))
                                <span class="help-block" role="alert">{{ $errors->first('karat') }}</span>
                            @endif
                            <span class="help-block">{{ trans('cruds.stock.fields.karat_helper') }}</span>
                        </div>
                        <div class="form-group {{ $errors->has('kadar') ? 'has-error' : '' }}">
                            <label for="kadar">{{ trans('cruds.stock.fields.kadar') }}</label>
                            <input class="form-control" type="number" name="kadar" id="kadar" value="{{ old('kadar', '') }}" step="0.01">
                            @if($errors->has('kadar'))
                                <span class="help-block" role="alert">{{ $errors->first('kadar') }}</span>
                            @endif
                            <span class="help-block">{{ trans('cruds.stock.fields.kadar_helper') }}</span>
                        </div>
                        <div class="form-group {{ $errors->has('image') ? 'has-error' : '' }}">
                            <label for="image">{{ trans('cruds.metodePembayaran.fields.logo') }}</label>
                            <div class="needsclick dropzone" id="logo-dropzone">
                            </div>
                            @if($errors->has('image'))
                                <span class="help-block" role="alert">{{ $errors->first('image') }}</span>
                            @endif
                            <span class="help-block">{{ trans('cruds.metodePembayaran.fields.logo_helper') }}</span>
                        </div>
                        <div class="form-group">
                            <button class="btn btn-danger" type="submit">
                                {{ trans('global.save') }}
                            </button>
                        </div>
                    </form>
                </div>
            </div>



        </div>
    </div>
</div>
@endsection

@section('scripts')
    <script>
        Dropzone.options.logoDropzone = {
            url: '{{ route('admin.stocks.storeMedia') }}',
            maxFilesize: 2, // MB
            acceptedFiles: '.jpeg,.jpg,.png,.gif',
            maxFiles: 1,
            addRemoveLinks: true,
            headers: {
                'X-CSRF-TOKEN': "{{ csrf_token() }}"
            },
            params: {
                size: 2,
                width: 4096,
                height: 4096
            },
            success: function (file, response) {
                $('form').find('input[name="image"]').remove()
                $('form').append('<input type="hidden" name="image" value="' + response.name + '">')
            },
            removedfile: function (file) {
                file.previewElement.remove()
                if (file.status !== 'error') {
                    $('form').find('input[name="image"]').remove()
                    this.options.maxFiles = this.options.maxFiles + 1
                }
            },
            init: function () {
                @if(isset($metodePembayaran) && $metodePembayaran->logo)
                    var file = {!! json_encode($metodePembayaran->logo) !!}
                    this.options.addedfile.call(this, file)
                    this.options.thumbnail.call(this, file, file.preview ?? file.preview_url)
                    file.previewElement.classList.add('dz-complete')
                    $('form').append('<input type="hidden" name="image" value="' + file.file_name + '">')
                    this.options.maxFiles = this.options.maxFiles - 1
                @endif
            },
            error: function (file, response) {
                if ($.type(response) === 'string') {
                    var message = response //dropzone sends it's own error messages in string
                } else {
                    var message = response.errors.file
                }
                file.previewElement.classList.add('dz-error')
                _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
                _results = []
                for (_i = 0, _len = _ref.length; _i < _len; _i++) {
                    node = _ref[_i]
                    _results.push(node.textContent = message)
                }

                return _results
            }
        }

    </script>
@endsection