@extends('layouts.admin')
@section('content')
<div class="content">
    <livewire:create-penjualan/>
</div>
@endsection