@extends('layouts.admin')
@section('content')
<div class="content">
    <livewire:edit-penjualan :penjualanData="$sale"/>
</div>
@endsection