@extends('layouts.admin')
@section('content')
<div class="content">

    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading" style="display: flex; justify-content: space-between; align-items: center">
                    <div>{{ trans('global.edit') }} {{ trans('cruds.jenisBarangHutang.title_singular') }}</div>
                    <div>
                        <a class="btn btn-danger" href="{{ route('admin.jenis-barang-hutangs.index') }}">
                            {{ trans('global.back') }} {{ trans('cruds.jenisBarangHutang.title_singular') }}
                        </a>
                    </div>
                </div>
                <div class="panel-body">
                    <form method="POST" action="{{ route("admin.jenis-barang-hutangs.update", [$jenisBarangHutang->id]) }}" enctype="multipart/form-data">
                        @method('PUT')
                        @csrf
                        <div class="form-group {{ $errors->has('jenis') ? 'has-error' : '' }}">
                            <label class="required" for="jenis">{{ trans('cruds.jenisBarangHutang.fields.jenis') }}</label>
                            <input class="form-control" type="text" name="jenis" id="jenis" value="{{ old('jenis', $jenisBarangHutang->jenis) }}" required>
                            @if($errors->has('jenis'))
                                <span class="help-block" role="alert">{{ $errors->first('jenis') }}</span>
                            @endif
                            <span class="help-block">{{ trans('cruds.jenisBarangHutang.fields.jenis_helper') }}</span>
                        </div>
                        <div class="form-group">
                            <button class="btn btn-danger" type="submit">
                                {{ trans('global.save') }}
                            </button>
                        </div>
                    </form>
                </div>
            </div>



        </div>
    </div>
</div>
@endsection