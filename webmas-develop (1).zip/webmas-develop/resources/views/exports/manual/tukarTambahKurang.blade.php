
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
</head>


<style>
    @page { margin: 0px;font-size:10px; }
    body { margin: 0px; }
    table, th, td {
        border: 1px transparent;
        /*border-color:#fff;*/
    }
</style>
<body>

<section style="height:100%">
    @for($i = 1; $i <= $tukarTambahKurang->tukarTambahKurangItems->where('type','2')->groupBy("noKuitansi")->count(); $i++)
        <div class="wrapper-page" style="min-height:50%;">
            <!--Header-->
            <div style="width:100%; height: 138.85228346px;">
                <table style="width: 100%;padding-right: 13.1px;padding-left: 13.1px;padding-top: 9.1px;padding-bottom: 6.1px;">
                    <tr>
                        <td width="35%"><span style="font-size: 12pt;margin-left: 87.6pt">{{$tukarTambahKurang->noTrx}}</span></td>
                        <td width="25%" rowspan="4" style="text-align: center;">
                            <div style="width:153.4pt;height:61.3pt"></div>
                        </td>
                        <td width="25%" height="10px" valign="top" style="padding-top: 2px">
                        </td>
                    </tr>
                    <tr>
                        <td width="35%" style="padding-top: 20.1px">
                            <img src="data:image/png;base64,{{ DNS1D::getBarcodePNG($tukarTambahKurang->noTrx, 'C128', 1.3) }}" height="30pt" alt="barcode"   />
                        </td>
                        <td width="25%" rowspan="2" valign="top">
                            <span style="font-size: 8pt; font-weight: bold;margin-left: 30.6pt">{{ $tukarTambahKurang->type == 1 ?  $tukarTambahKurang->created_at->format("d F Y") :  $tukarTambahKurang->tanggalPenjualan->format("d F Y") }} </span><br><span style="font-size: 8pt; font-weight: bold;margin-left: 68.9pt">{{ $tukarTambahKurang->customer->nama }}</span>
                        </td>
                    </tr>
                    <tr>
                        <td width="35%"><span style="font-size: 7.9pt;font-weight: bold"></span></td>
                    </tr>
                    <tr>
                        <td valign="bottom" width="35%"><span style="font-size: 7.9pt;font-weight: bold"></span></td>
                        <td width="25%"><span style="font-size: 7.9pt;font-weight: bold"></span></td>
                    </tr>
                </table>
            </div>
            <!--End Header-->
            <!--Body-->
            <div style="margin-top: 15.4px;padding-right: 28.4pt;padding-left: 23.4px;">
                <div style="height: 25pt"></div>
                <table style="width: 100%;">
                    @if($i == 1 && $tukarTambahKurang->type == 1)
                        <tr>
                            <td width="41pt" style="text-align:center;height: 30px"></td>
                            <td width="224pt"></td>
                            <td width="50pt" style="text-align:center;">
                                {{--                            <span>{{ $tukarTambahKurang->tukarTambahKurangItems->where("type","1")->sum("berat") }}gr</span>--}}
                                {{--                            <hr style="width: 80%">--}}
                                {{--                            <span>{{ $tukarTambahKurang->tukarTambahKurangItems->where("type","1")->sum("kadar") }}k</span>--}}
                            </td>
                            <td width="70.3pt">
                                <p style="text-align:left;margin-left: 43px;margin-right: 5px">
                                    {{ encodeCurrencyWithOutPrefix($tukarTambahKurang->tukarTambahKurangItems->where("type","1")->sum("hargaPerGram")) }}
                                    <span style="float: right">HL</span>
                                </p>
                            </td>
                            <td width="108pt" style="text-align:right"><span style="margin-right: 5px">{{ encodeCurrencyWithOutPrefix($tukarTambahKurang->tukarTambahKurangItems->where("type","1")->sum("total")) }}</span></td>
                        </tr>
                    @endif
                    
                    <!--Content-->
                    @foreach($tukarTambahKurang->tukarTambahKurangItems->where("type", "2")->where("noKuitansi", $i) as $row)
                        <tr>
                            <td width="41pt" style="text-align: center">{{ $loop->iteration }}</td>
                            <td width="224pt" style="text-align: start;margin-left: 5px;margin-right: 5px"><span style="margin-left: 10px">{{ $row->namaBarang }} @if(!empty($row->varian)){{$row->varian}}@endif</span></td>
                            <td width="50pt" style="text-align:center;margin-left:3px;">
                                <span>{{ $row->berat }}gr</span>
                                <hr style="width: 80%">
                                <span>{{ $row->kadar }}k</span>
                            </td>

                            <td width="70.3pt" style="text-align:left">
                                <span style="margin-left: 40px">{{ encodeCurrencyWithOutPrefix($row->hargaPerGram) }}</span>
                            </td>
                            <td width="108pt" style="text-align:right"><span style="margin-right: 5px">{{ encodeCurrencyWithOutPrefix($row->total - $row->potongan) }}</span></td>
                        </tr>
                    @endforeach
                    <!--End Content-->

                    @if($tukarTambahKurang->tukarTambahKurangItems->where("type","1")->count() <= ($i === 1 ? 6 : 7) )
                        <tr>
                            <td style="text-align:center;height: {{ (($i === 1 ? 6 : 7) - $tukarTambahKurang->tukarTambahKurangItems->where("type", "2")->count()) * 30 }}"></td>
                            <td></td>
                            <td style="text-align:center;">
                                <span></span>
                                <span></span>
                            </td>
                            <td style="text-align:center"></td>
                            <td style="text-align:center"></td>
                        </tr>
                    @endif
                    @if($i == 1)
                        <tr>
                            <td></td>
                            <td><span  style="margin-left: 5px">{{ $tukarTambahKurang->type == 1 ? '+' : '-' }}{{ $tukarTambahKurang->tukarTambahKurangItems->where("type", "2")->where("noKuitansi", $i)->sum("berat") - $tukarTambahKurang->tukarTambahKurangItems->where("type", "1")->where("noKuitansi", $i)->sum("berat")  }}gr</span></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                    @endif
                </table>
            </div>
            <!--End Body-->
            <!--Footer-->
            <div class="border-none" style="padding-right: 28pt;padding-left: 20.4px;margin-top:7px">
                <table style="width:100%;">
                    <tr>
                        <td width="30%">Metode Pembayaran :
                            @if($tukarTambahKurang->payment_type == 1)
                                {{ $tukarTambahKurang->metodePembayarans->first()->nama_metode }}
                            @else
                                @foreach($tukarTambahKurang->metodePembayarans as $metode)
                                    {{ $metode->nama_metode }} @if (!$loop->last)+@endif
                                @endforeach
                            @endif

                        </td>
                        <td colspan="2" rowspan="2" style="text-align:center;width:5%"></td>
                        <td width="22.5%" style="text-align:right"><div style="padding:5px;padding-top:11px">{{ encodeCurrencyWithOutPrefix($tukarTambahKurang->tukarTambahKurangItems->where("type", "2")->where("noKuitansi", $i)->sum("potongan")) }}</div></td>
                    </tr>
                    <tr>
                        <td width="30%" style="text-align:start;width:40%">
                        </td>
                        <td width="22.5%" style="text-align:right;vertical-align:top;">
                            <div style="padding:5px;padding-top:14px">
                                
                                @if($tukarTambahKurang->type == 1)
                                    {{ encodeCurrencyWithOutPrefix($tukarTambahKurang->tukarTambahKurangItems->where("type", "2")->where("noKuitansi", $i)->sum("total") + ($i === 1 ? $tukarTambahKurang->tukarTambahKurangItems->where("type","1")->sum("total") : 0))  }}
                                @else
                                    {{ encodeCurrencyWithOutPrefix($tukarTambahKurang->tukarTambahKurangItems->where("type", "2")->where("noKuitansi", $i)->sum("total") - ($i === 1 ? $tukarTambahKurang->tukarTambahKurangItems->where("type","1")->sum("total") : 0))  }}
                                @endif
                            </div>
                        </td>
                    </tr>
                </table>
            </div>
            <!--End Footer-->
        </div>
    @endfor
</section>

</body>
</html>