<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>

    <style>
        @page { margin: 5px;font-size:5px; }
        body { margin: 5px; }

        td{
            font-size: 8px;
        }

        .border-none table {
            border:none;
            border-collapse: collapse;
        }

        .border-none th {
            border:none;
            border-collapse: collapse;
        }

        .border-none td {
            border:none;
            border-collapse: collapse;
        }

        table, th, td {
            border-left: 1px solid;
            border-right: 1px solid;
            border-color: transparent;
        }
        tr:last-child {
            border-bottom: 1px solid transparent;
        }

        .border-none tr:last-child {
            border-bottom: none;
        }

        tr:first-child {
            border-top: 1px solid transparent;
        }

        .border-none tr:first-child {
            border-top: none;
        }

        .wrapper-page {
            z-index: 1;
            position: relative;
            border-bottom: 1px dotted;
            margin-top: 3px;
            page-break-inside: avoid;
        }

        .wrapper-page:last-child {
            page-break-inside: avoid;
            border-bottom: none;
        }
    </style>
</head>
<body>

<section style="width: 100%">
    @for($i = 1; $i <= $pemesanan->total_kuitansi; $i++)
        <div style="clear: top;height: 32%;margin-top: 0.53cm" class="wrapper-page">
            <div>
                <div style="padding: 0.43cm 0.44cm;border-radius:20px;border:1px solid transparent;margin-bottom:0.45cm;margin-left: 4.9cm;">
                    <table style="width:100%;">
                        <tr>
                            <td style="font-size: 19.8pt"></td>
                            <td style="font-size: 9.7pt" width="2.29ccm"></td>
                            <td style="font-size: 9.7pt"  width="8px"></td>
                            <td style="text-align: left;width: 100px;font-size: 7.7pt; height: 17px">{{ $pemesanan->customer->nama }}</td>
                            <td style="font-size: 9.7pt" width="50px"></td>
                            <td style="font-size: 9.7pt" width="8px"></td>
                            <td style="font-size: 7.7pt" valign="bottom">
                                <div style="padding-bottom: 0">
                                    <span>{{ $pemesanan->created_at->format("d/m/Y") }}</span>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td width="35%">
                                <img src="data:image/png;base64,{{ DNS1D::getBarcodePNG($pemesanan->noTrx, 'C128', 1) }}" height="30" alt="barcode"   />
                            </td>
                            <td style="font-size: 9.7pt"></td>
                            <td style="font-size: 9.7pt"></td>
                            <td style="font-size: 7.7pt">{{ $pemesanan->customer->nomor_hp }}</td>
                            <td style="font-size: 9.7pt"></td>
                            <td style="font-size: 9.7pt"></td>
                            <td style="font-size: 7.7pt;" valign="bottom">
                                <div style="padding-bottom: 2px">
                                    <span>{{ $pemesanan->created_at->format("d/m/Y") }}</span>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td style="font-size: 6.8pt">{{ $pemesanan->noTrx }}</td>
                            <td style="font-size: 9.7pt"></td>
                            <td style="font-size: 9.7pt"></td>
                            <td style="font-size: 7.7pt">{{ $pemesanan->created_at->format("d/m/Y") }}</td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                    </table>
                </div>

                <div style="padding: 0 4px;margin-left: 4cm;">
                <table style="width:96%;">
                    <thead>
                    <tr>
                        <td style="width: 1.99cm;height: 0.57cm"></td>
                        <td style="width: 6.4cm;"></td>
                        <td style="width: 1.8cm"></td>
                        <td style="width: 2.25cm"></td>
                        <td style="width: 2.92cm"></td>
                    </tr>
                    </thead>
                    <tbody>
                    @php
                        $dp = 0;
                        $ongkos = 0;
                    @endphp

                    @foreach($pemesanan->pemesananItems->where("no", $i) as $row)
                        @php
                            $dp += $row->payment;
                            $ongkos += $row->ongkos;
                        @endphp
                        <tr>
                            <td style="text-align:center">{{ $loop->iteration }}</td>
                            <td><span style="margin-left: 5px">{{ $row->nama_barang }} @if(!empty($row->varian)){{$row->varian}} @endif</span></td>
                            <td style="text-align:center;">
                                <span>{{ $row->berat }}</span>
                                <hr style="width: 50%">
                                <span>{{ $row->kadar }}k</span>
                            </td>
                            <td style="text-align:center">{{ encodeCurrency($row->harga_pergram) }}</td>
                            <td style="text-align:center">{{ encodeCurrency($row->total) }}</td>
                        </tr>
                    @endforeach

                    @if($pemesanan->pemesananItems->where("no", $i)->count() <= ($i === 1 ? 5 : 6) )
                        <tr>
                            <td style="width: 1.99cm;height: {{ (($i === 1 ? 5 : 6) - $pemesanan->pemesananItems->where("no", $i)->count()) * 0.51 }}cm"></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                    @endif

                    <tr>
                        <td colspan="4" style="text-align:right;padding-right:10px;border-top: 1px solid transparent"></td>
                        <td style="border-top: 1px solid transparent;text-align: center">{{ encodeCurrency($ongkos) }}</td>
                    </tr>
                    </tbody>
                </table>
                </div>
                <div style="margin-left: 3.6cm;margin-right: 0.8cm">
                    <table style="width:100%;padding: 0 4px;margin-top: 0.17cm">
                        <thead>
                        <tr>
                            <td height="12.5" width="69.5%" style="padding-right: 50px;vertical-align: center">

                            </td>
                            <td width="13%" style="text-align:end;padding-right:10px"></td>
                            <td style="text-align: center" height="0.58cm"><div>{{ encodeCurrency($pemesanan->pemesananItems->where("no",$i)->sum("total")) }}</div></td>
                        </tr>
                        <tr>
                            <td height="12.5" width="69.5%" style="padding-right: 50px;vertical-align: center">

                            </td>
                            <td width="13%" style="text-align:end;padding-right:10px"></td>
                            <td style="text-align: center;" height="0.58cm"><div>{{ encodeCurrency($dp) }}</div></td>
                        </tr>

                        <tr>
                            <td height="12.5" width="69.5%" style="padding-right: 50px;vertical-align: center">

                            </td>
                            <td width="13%" style="text-align:end;padding-right:10px"></td>
                            <td style="text-align: center" height="0.58cm"><div>{{ encodeCurrency($pemesanan->pemesananItems->where("no",$i)->sum("total") - $dp ) }}</div></td>
                        </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    @endfor
</section>
</body>
</html>
