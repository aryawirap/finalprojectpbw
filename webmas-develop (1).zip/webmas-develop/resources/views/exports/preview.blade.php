@extends('layouts.admin')
@section('content')
    <div class="content">
        <div class="row">
            <div class="col-lg-12" style="margin-bottom: 10px">
                <a href="{{ route("admin.$path.index") }}" class="btn btn-danger">Kembali</a>
            </div>
            <div class="col-lg-12">
                <iframe src ="{{ asset($invoice->pdfPath) }}" width="100%" height="1000px"></iframe>
            </div>
        </div>
    </div>
@endsection