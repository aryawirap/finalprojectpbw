<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <style>
        table, td, th {
            border: 1px solid;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }
    </style>
</head>
<body>
@php
    $dateFrom=date_create($from);
    $dateTo=date_create($to);
    $diff=date_diff($dateFrom,$dateTo);
@endphp
@if($diff->format("%a") == '0')
    <h2 style="text-align: center">Stock Opname tanggal {{ date_format($dateFrom,"d-m-Y") }}</h2>
    <table class="table table-bordered table-sm">
        <tbody>

        @foreach($category as $c)
            <tr>
                <td width="30%" rowspan="2" style="text-align: left">{{ $c->type_emas }}</td>
                @foreach(\Illuminate\Support\Facades\DB::select("SELECT id, berat FROM stocks WHERE category_id = {$c->id}") as $d)
                    <td>{{ $d->berat }}</td>
                @endforeach
            </tr>
            <tr>
                @foreach(\Illuminate\Support\Facades\DB::select("SELECT id, berat FROM stocks WHERE category_id = {$c->id}") as $d)
                    @forelse(\Illuminate\Support\Facades\DB::table("stock_opnames")->where("tanggal", $from)->where("stock_id", $d->id)->get() as $e)
                        <td>
                            @php
                                $pengurangan = \Illuminate\Support\Facades\DB::select("SELECT SUM(jumlah) as totalPengurangan FROM stock_opname_details WHERE stock_opname_id = {$e->id} AND type = '1'")[0]->totalPengurangan;

                                $penambahan = \Illuminate\Support\Facades\DB::select("SELECT SUM(jumlah) as totalPenambahan FROM stock_opname_details WHERE stock_opname_id = {$e->id} AND type = '2'")[0]->totalPenambahan;
                                echo ($e->stock_awal + $penambahan - $pengurangan);
                            @endphp
                        </td>
                    @empty
                        <td>0</td>
                    @endforelse
                @endforeach
            </tr>
        @endforeach
        </tbody>
    </table>
@else
    @for($i = 1; $i <= $diff->format("%a"); $i++)
        @php
            $sqlDate = date("Y-m-d",strtotime($dateFrom->format("Y-m-d")."+ $i days"));
        @endphp
        <h2 style="text-align: center">Stock Opname tanggal {{ date_format(date_create($sqlDate),"d-m-Y") }}</h2>
        <table class="table table-bordered table-sm">
            <tbody>

            @foreach($category as $c)
                <tr>
                    <td width="30%" rowspan="2" style="text-align: left">{{ $c->type_emas }}</td>
                    @foreach(\Illuminate\Support\Facades\DB::select("SELECT id, berat FROM stocks WHERE category_id = {$c->id}") as $d)
                        <td>{{ $d->berat }}</td>
                    @endforeach
                </tr>
                <tr>
                    @foreach(\Illuminate\Support\Facades\DB::select("SELECT id, berat FROM stocks WHERE category_id = {$c->id}") as $d)
                        @forelse(\Illuminate\Support\Facades\DB::table("stock_opnames")->where("tanggal", $sqlDate)->where("stock_id", $d->id)->get() as $e)
                            <td>
                                @php
                                    $pengurangan = \Illuminate\Support\Facades\DB::select("SELECT SUM(jumlah) as totalPengurangan FROM stock_opname_details WHERE stock_opname_id = {$e->id} AND type = '1' AND deleted_at IS NULL")[0]->totalPengurangan;

                                    $penambahan = \Illuminate\Support\Facades\DB::select("SELECT SUM(jumlah) as totalPenambahan FROM stock_opname_details WHERE stock_opname_id = {$e->id} AND type = '2' AND deleted_at IS NULL")[0]->totalPenambahan;
                                    echo ($e->stock_awal + $penambahan - $pengurangan);
                                @endphp
                            </td>
                        @empty
                            <td>0</td>
                        @endforelse
                    @endforeach
                </tr>
            @endforeach
            </tbody>
        </table>
    @endfor
@endif
</body>
</html>