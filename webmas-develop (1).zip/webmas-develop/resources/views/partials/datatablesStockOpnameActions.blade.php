@can($detailGate)
    <a class="btn btn-xs btn-warning" href="{{ route('admin.' . $crudRoutePart . '.show', $row->id) }}">
        Detail
    </a>
@endcan
@can($addStockGate)
    <a class="btn btn-xs btn-info" href="{{ route('admin.' . $crudRoutePart . '.addStock', ['stockOpname' => $row->id, 'tgl' => $row->tanggal]) }}">
       Tambah
    </a>
@endcan