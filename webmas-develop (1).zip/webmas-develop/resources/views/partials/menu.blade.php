<aside class="main-sidebar">
    <section class="sidebar" style="height: auto;">
        <ul class="sidebar-menu tree" data-widget="tree">
            <li>
                <a href="{{ route("admin.home") }}">
                    <i class="fas fa-fw fa-tachometer-alt">

                    </i>
                    {{ trans('global.dashboard') }}
                </a>
            </li>
            @can('transaksi_access')
                <li class="treeview">
                    <a href="#">
                        <i class="fa-fw fas fa-shopping-cart">

                        </i>
                        <span>{{ trans('cruds.transaksi.title') }}</span>
                        <span class="pull-right-container"><i class="fa fa-fw fa-angle-left pull-right"></i></span>
                    </a>
                    <ul class="treeview-menu">
                        @can('sale_access')
                            <li class="{{ request()->is("admin/sales") || request()->is("admin/sales/*")  || request()->is("admin/sales/*")? "active" : "" }}">
                                <a href="{{ route("admin.sales.index") }}">
                                    <i class="fa-fw fas fa-book">

                                    </i>
                                    <span>{{ trans('cruds.sale.title') }}</span>

                                </a>
                            </li>
                        @endcan
                        @can('pembelian_access')
                            <li class="{{ request()->is("admin/pembelian") || request()->is("admin/pembelian/*") ? "active" : "" }}">
                                <a href="{{ route("admin.pembelian.index") }}">
                                    <i class="fa-fw fas fa-book">

                                    </i>
                                    <span>{{ trans('cruds.pembelian.title') }}</span>

                                </a>
                            </li>
                        @endcan
                        @can('pelunasan_access')
                            <li class="{{ request()->is("admin/pelunasan") || request()->is("admin/pelunasan/*") ? "active" : "" }}">
                                <a href="{{ route("admin.pelunasan.index") }}">
                                    <i class="fa-fw fas fa-book">

                                    </i>
                                    <span>{{ trans('cruds.pelunasan.title') }}</span>

                                </a>
                            </li>
                        @endcan
                        @can('pemesanan_access')
                            <li class="{{ request()->is("admin/pemesanan") || request()->is("admin/pemesanan/*") ? "active" : "" }}">
                                <a href="{{ route("admin.pemesanan.index") }}">
                                    <i class="fa-fw fas fa-book">

                                    </i>
                                    <span>{{ trans('cruds.pemesanan.title') }}</span>

                                </a>
                            </li>
                        @endcan
                        @can('tukar_tambah_kurang_access')
                            <li class="{{ request()->is("admin/tukarTambahKurang") || request()->is("admin/tukarTambahKurang/*") ? "active" : "" }}">
                                <a href="{{ route("admin.tukarTambahKurang.index") }}">
                                    <i class="fa-fw fas fa-book">

                                    </i>
                                    <span>{{ trans('cruds.tukarTambahKurang.title') }}</span>

                                </a>
                            </li>
                        @endcan
                    </ul>
                </li>
            @endcan
            @can('master_karyawan_access')
                <li class="treeview">
                    <a href="#">
                        <i class="fa-fw fas fa-book">

                        </i>
                        <span>{{ trans('cruds.Masterkarwayan.title') }}</span>
                        <span class="pull-right-container"><i class="fa fa-fw fa-angle-left pull-right"></i></span>
                    </a>
                    <ul class="treeview-menu">
                        @can('karyawan_access')
                            <li class="{{ request()->is("admin/karyawans") || request()->is("admin/karyawans/*") ? "active" : "" }}">
                                <a href="{{ route("admin.karyawans.index") }}">
                                    <i class="fa-fw fas fa-users">

                                    </i>
                                    <span>{{ trans('cruds.karyawan.title') }}</span>

                                </a>
                            </li>
                        @endcan
                        @can('gaji_access')
                            <li class="{{  request()->is("admin/gaji") || request()->is("admin/gaji/*") ? "active" : "" }}">
                                <a href="{{ route("admin.gaji.index") }}">
                                    <i class="fa-fw fas fa-money">

                                    </i>
                                    <span>{{ trans('cruds.karyawanGaji.title') }}</span>

                                </a>
                            </li>
                        @endcan
                        @can('jenis_barang_hutang_access')
                            <li class="{{ request()->is("admin/jenis-barang-hutangs") || request()->is("admin/jenis-barang-hutangs/*") ? "active" : "" }}">
                                <a href="{{ route("admin.jenis-barang-hutangs.index") }}">
                                    <i class="fa-fw fas fa-ambulance">

                                    </i>
                                    <span>{{ trans('cruds.jenisBarangHutang.title') }}</span>

                                </a>
                            </li>
                        @endcan
                        @can('hutang_access')
                            <li class="{{ request()->is("admin/hutangs") || request()->is("admin/hutangs/*") ? "active" : "" }}">
                                <a href="{{ route("admin.hutangs.index") }}">
                                    <i class="fa-fw fas fa-cogs">

                                    </i>
                                    <span>{{ trans('cruds.hutang.title') }}</span>

                                </a>
                            </li>
                        @endcan
                    </ul>
                </li>
            @endcan
            @can('finance_access')
                <li class="treeview">
                    <a href="#">
                        <i class="fa-fw fas fa-money">
                        </i>
                        <span>{{ trans('cruds.Finance.title') }}</span>
                        <span class="pull-right-container"><i class="fa fa-fw fa-angle-left pull-right"></i></span>
                    </a>
                    <ul class="treeview-menu">
                        @can('stockOpname_access')
                        <li class="{{ request()->is("admin/stockOpname") || request()->is("admin/stockOpname/*") ? "active" : "" }}">
                            <a href="{{ route("admin.stockOpname.index") }}">
                                <i class="fa-fw fas fa-book">

                                </i>
                                <span>Stock Opname</span>

                            </a>
                        </li>
                        @endcan
                        @can('hutang_access')
                            <li class="{{ request()->is("admin/cashOpname") || request()->is("admin/cashOpname/*") ? "active" : "" }}">
                                <a href="{{ route("admin.cashOpname.index") }}">
                                    <i class="fa-fw fas fa-book">

                                    </i>
                                    <span>{{ trans('cruds.CashOpname.title') }}</span>

                                </a>
                            </li>
                        @endcan
                        @can('berangkas_access')
                            <li class="{{ request()->is("admin/berangkas") || request()->is("admin/berangkas/*") ? "active" : "" }}">
                                <a href="{{ route("admin.berangkas.index") }}">
                                    <i class="fa-fw fas fa-book">

                                    </i>
                                    <span>{{ trans('cruds.Berangkas.title') }}</span>

                                </a>
                            </li>
                        @endcan
                    </ul>
                </li>
            @endcan
            @can('master_data_access')
                <li class="treeview">
                    <a href="#">
                        <i class="fa-fw fas fa-book">

                        </i>
                        <span>{{ trans('cruds.masterData.title') }}</span>
                        <span class="pull-right-container"><i class="fa fa-fw fa-angle-left pull-right"></i></span>
                    </a>
                    <ul class="treeview-menu">
                        @can('category_access')
                            <li class="{{ request()->is("admin/categories") || request()->is("admin/categories/*") ? "active" : "" }}">
                                <a href="{{ route("admin.categories.index") }}">
                                    <i class="fa-fw fas fa-align-justify">

                                    </i>
                                    <span>{{ trans('cruds.category.title') }}</span>

                                </a>
                            </li>
                        @endcan
                        @can('stock_access')
                            <li class="{{ request()->is("admin/stocks") || request()->is("admin/stocks/*") ? "active" : "" }}">
                                <a href="{{ route("admin.stocks.index") }}">
                                    <i class="fa-fw fas fa-boxes">

                                    </i>
                                    <span>{{ trans('cruds.stock.title') }}</span>

                                </a>
                            </li>
                        @endcan
                        @can('customer_access')
                            <li class="{{ request()->is("admin/customers") || request()->is("admin/customers/*") ? "active" : "" }}">
                                <a href="{{ route("admin.customers.index") }}">
                                    <i class="fa-fw fas fa-users">

                                    </i>
                                    <span>{{ trans('cruds.customer.title') }}</span>

                                </a>
                            </li>
                        @endcan
                        @can('general_config_access')
                            <li class="{{ request()->is("admin/general-configs") || request()->is("admin/general-configs/*") ? "active" : "" }}">
                                <a href="{{ route("admin.general-configs.index") }}">
                                    <i class="fa-fw fas fa-cogs">

                                    </i>
                                    <span>{{ trans('cruds.generalConfig.title') }}</span>

                                </a>
                            </li>
                        @endcan
                        @can('metode_pembayaran_access')
                            <li class="{{ request()->is("admin/metode-pembayarans") || request()->is("admin/metode-pembayarans/*") ? "active" : "" }}">
                                <a href="{{ route("admin.metode-pembayarans.index") }}">
                                    <i class="fa-fw far fa-credit-card">

                                    </i>
                                    <span>{{ trans('cruds.metodePembayaran.title') }}</span>

                                </a>
                            </li>
                        @endcan
                    </ul>
                </li>
            @endcan
            @can('user_management_access')
                <li class="treeview">
                    <a href="#">
                        <i class="fa-fw fas fa-users">

                        </i>
                        <span>{{ trans('cruds.userManagement.title') }}</span>
                        <span class="pull-right-container"><i class="fa fa-fw fa-angle-left pull-right"></i></span>
                    </a>
                    <ul class="treeview-menu">
                        @can('permission_access')
                            <li class="{{ request()->is("admin/permissions") || request()->is("admin/permissions/*") ? "active" : "" }}">
                                <a href="{{ route("admin.permissions.index") }}">
                                    <i class="fa-fw fas fa-unlock-alt">

                                    </i>
                                    <span>{{ trans('cruds.permission.title') }}</span>

                                </a>
                            </li>
                        @endcan
                        @can('role_access')
                            <li class="{{ request()->is("admin/roles") || request()->is("admin/roles/*") ? "active" : "" }}">
                                <a href="{{ route("admin.roles.index") }}">
                                    <i class="fa-fw fas fa-briefcase">

                                    </i>
                                    <span>{{ trans('cruds.role.title') }}</span>

                                </a>
                            </li>
                        @endcan
                        @can('user_access')
                            <li class="{{ request()->is("admin/users") || request()->is("admin/users/*") ? "active" : "" }}">
                                <a href="{{ route("admin.users.index") }}">
                                    <i class="fa-fw fas fa-user">

                                    </i>
                                    <span>{{ trans('cruds.user.title') }}</span>

                                </a>
                            </li>
                        @endcan
                        @can('audit_log_access')
                            <li class="{{ request()->is("admin/audit-logs") || request()->is("admin/audit-logs/*") ? "active" : "" }}">
                                <a href="{{ route("admin.audit-logs.index") }}">
                                    <i class="fa-fw fas fa-file-alt">

                                    </i>
                                    <span>{{ trans('cruds.auditLog.title') }}</span>

                                </a>
                            </li>
                        @endcan
                    </ul>
                </li>
            @endcan
            @if(file_exists(app_path('Http/Controllers/Auth/ChangePasswordController.php')))
                @can('profile_password_edit')
                    <li class="{{ request()->is('profile/password') || request()->is('profile/password/*') ? 'active' : '' }}">
                        <a href="{{ route('profile.password.edit') }}">
                            <i class="fa-fw fas fa-key">
                            </i>
                            {{ trans('global.change_password') }}
                        </a>
                    </li>
                @endcan
            @endif
            <li>
                <a href="#" onclick="event.preventDefault(); document.getElementById('logoutform').submit();">
                    <i class="fas fa-fw fa-sign-out-alt">

                    </i>
                    {{ trans('global.logout') }}
                </a>
            </li>
        </ul>
    </section>
</aside>