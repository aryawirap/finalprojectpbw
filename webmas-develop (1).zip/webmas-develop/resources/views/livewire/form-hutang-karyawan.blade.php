<div>

    <button wire:click.prevent="otherJenisBarang" type="button" class="btn btn-xs {{ $jenisBarangSwitch === false ? "btn-success" : "btn-danger" }} pull-right">{{ $jenisBarangSwitch === false ? "+" : "-" }}</button>

    <div class="form-group {{ $errors->has('jenis_barang') ? 'has-error' : '' }}">
        <label class="required" for="jenis_barang_id">{{ trans('cruds.hutang.fields.jenis_barang') }}</label>
        @if($jenisBarangSwitch === false)
        <div wire:ignore>
            <select data-pharaonic="select2" name="jenis_barang_id" data-placeholder="Silahkan pilih" id="input-jenisBarang" style="width: 100%" data-component-id="1">
                @foreach($jenis_barangs as $id => $entry)
                    <option value="{{ $id }}" {{ old('jenis_barang_id') == $id ? 'selected' : '' }}>{{ $entry }}</option>
                @endforeach
            </select>
        </div>
        @if($errors->has('jenis_barang_id'))
            <span class="help-block" role="alert">{{ $errors->first('jenis_barang_id') }}</span>
        @endif
        <span class="help-block">{{ trans('cruds.hutang.fields.jenis_barang_helper') }}</span>
        @else
            <input class="form-control" type="text" name="jenis_barang" id="jenis_barang" placeholder="Masukan jenis barang" value="{{ old('jenis_barang', '') }}" required>
            @if($errors->has('jenis_barang'))
                <span class="help-block" role="alert">{{ $errors->first('jenis_barang') }}</span>
            @endif
            <span class="help-block">{{ trans('cruds.hutang.fields.jenis_barang_helper') }}</span>
        @endif
    </div>
    <input type="hidden" name="create" wire:model="jenisBarangSwitch">
    <div class="form-group {{ $errors->has('jumlah_hutang') ? 'has-error' : '' }}">
        <label class="required" for="jumlah_hutang">{{ trans('cruds.hutang.fields.jumlah_hutang') }}</label>
        <input wire:model="jumlah_hutang" type-currency="IDR" class="form-control" type="text" name="jumlah_hutang" id="jumlah_hutang" value="{{ old('jumlah_hutang', '') }}" required>
        @if($errors->has('jumlah_hutang'))
            <span class="help-block" role="alert">{{ $errors->first('jumlah_hutang') }}</span>
        @endif
        <span class="help-block">{{ trans('cruds.hutang.fields.jumlah_hutang_helper') }}</span>
    </div>
    <div class="form-group {{ $errors->has('lama_cicilan') ? 'has-error' : '' }}">
        <label class="required" for="lama_cicilan">{{ trans('cruds.hutang.fields.lama_cicilan') }}</label>
        <input wire:model="lamaCicilan" class="form-control" type="number" name="lama_cicilan" id="lama_cicilan" value="{{ old('lama_cicilan', '') }}" step="1" required>
        @if($errors->has('lama_cicilan'))
            <span class="help-block" role="alert">{{ $errors->first('lama_cicilan') }}</span>
        @endif
        <span class="help-block">{{ trans('cruds.hutang.fields.lama_cicilan_helper') }}</span>
    </div>
    <div class="form-group {{ $errors->has('nominal_cicilan') ? 'has-error' : '' }}">
        <label class="required" for="nominal_cicilan">{{ trans('cruds.hutang.fields.nominal_cicilan') }}</label>
        <input readonly class="form-control" type="text" name="nominal_cicilan" id="nominal_cicilan" value="{{ old('nominal_cicilan', 'Rp '. number_format($cicilanPerbulan,0,'.','.')) }}" required>
        @if($errors->has('nominal_cicilan'))
            <span class="help-block" role="alert">{{ $errors->first('nominal_cicilan') }}</span>
        @endif
        <span class="help-block">{{ trans('cruds.hutang.fields.nominal_cicilan_helper') }}</span>
    </div>
</div>

<script>

    document.addEventListener("DOMContentLoaded", () => {
        Livewire.hook('element.updated', (el, component) => {
            document.querySelectorAll('input[type-currency="IDR"]').forEach((element) => {
                element.addEventListener('keyup', function(e) {
                    let cursorPostion = this.selectionStart;
                    let value = parseInt(this.value.replace(/[^,\d]/g, ''));
                    let originalLenght = this.value.length;
                    if (isNaN(value)) {
                        this.value = "";
                    } else {
                        this.value = value.toLocaleString('id-ID', {
                            currency: 'IDR',
                            style: 'currency',
                            minimumFractionDigits: 0
                        });
                        cursorPostion = this.value.length - originalLenght + cursorPostion;
                        this.setSelectionRange(cursorPostion, cursorPostion);
                    }
                });
            });
        })
        Livewire.hook('element.removed', (el, component) => {
            document.querySelectorAll('input[type-currency="IDR"]').forEach((element) => {
                element.addEventListener('keyup', function(e) {
                    let cursorPostion = this.selectionStart;
                    let value = parseInt(this.value.replace(/[^,\d]/g, ''));
                    let originalLenght = this.value.length;
                    if (isNaN(value)) {
                        this.value = "";
                    } else {
                        this.value = value.toLocaleString('id-ID', {
                            currency: 'IDR',
                            style: 'currency',
                            minimumFractionDigits: 0
                        });
                        cursorPostion = this.value.length - originalLenght + cursorPostion;
                        this.setSelectionRange(cursorPostion, cursorPostion);
                    }
                });
            });
        })
    });
</script>