<div>
    <input wire:model="total" class="form-control" type="text" required placeholder="Total" disabled>
</div>
