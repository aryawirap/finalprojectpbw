<div>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    {{ trans('global.edit') }} {{ trans('cruds.tukarTambahKurang.title_singular') }}
                </div>
                <div class="panel-body">
                    <form method="POST" action="{{ route("admin.tukarTambahKurang.store") }}" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group {{ $errors->has('customerId') ? 'has-error' : '' }}">
                            <label class="required" for="customerId">Data customer</label>

                            @if(!$createCustomer)
                                <button type="button" class="btn btn-xs btn-success pull-right" wire:click.prevent="$set('createCustomer',true)">
                                    <i class="fa fa-plus"></i>
                                </button>
                            @else
                                <button type="button" class="btn btn-xs btn-danger pull-right" wire:click.prevent="$set('createCustomer',false)">
                                    <i class="fa fa-times"></i>
                                </button>
                            @endif

                            @if($createCustomer)
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label class="required" for="nama_customer">Nama</label>
                                            <input wire:model="customer.nama" class="form-control" type="text" placeholder="masukan nama" required/>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label class="required" for="email">Email</label>
                                            <input wire:model="customer.email" class="form-control" type="email" name="email" id="email" placeholder="masukan email customer">
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="form-group">
                                            <label class="required" for="phone">Phone</label>
                                            <input wire:model="customer.phone" class="form-control" type="tel" name="phone" id="phone" placeholder="masukan nomor" required>
                                        </div>
                                    </div>
                                </div>
                            @else
                                <select required class="form-control" style="width: 100%" wire:model="customer.id">
                                    <option value="">- Pilih -</option>
                                    @foreach($customerList as $id => $customerd)
                                        <option value="{{ $id }}">{{ $customerd }}</option>
                                    @endforeach
                                </select>
                            @endif
                        </div>

                        <div class="form-group">
                            <label>Type</label>
                            <select required class="form-control" style="width: 100%" wire:model="typetukarTambah">
                                <option value="1">Tukar Tambah</option>
                                <option value="2">Tukar Kurang</option>
                            </select>
                        </div>

                        <div class="form-group {{ $errors->has('total_kuitansi') ? 'has-error' : '' }}">
                            <label class="required" for="total_kuitansi">{{ trans('cruds.sale.fields.total_kuitansi') }} lama</label>
                            <input class="form-control" type="number" disabled wire:model="totalKuitansi" name="total_kuitansi" id="total_kuitansi" value="{{ old('total_kuitansi', '1') }}" min="1" step="1" required>
                            @if($errors->has('total_kuitansi'))
                                <span class="help-block" role="alert">{{ $errors->first('total_kuitansi') }}</span>
                            @endif
                            <span class="help-block">{{ trans('cruds.sale.fields.total_kuitansi_helper') }}</span>
                        </div>


                        <div class="form-group {{ $errors->has('total_kuitansi') ? 'has-error' : '' }}">
                            <label class="required" for="total_kuitansi">{{ trans('cruds.sale.fields.total_kuitansi') }}</label>
                            <input class="form-control" type="number" wire:model="trxKuitansi" name="total_kuitansi" id="total_kuitansi" value="{{ old('total_kuitansi', '1') }}" min="1" step="1" required>
                            @if($errors->has('total_kuitansi'))
                                <span class="help-block" role="alert">{{ $errors->first('total_kuitansi') }}</span>
                            @endif
                            <span class="help-block">{{ trans('cruds.sale.fields.total_kuitansi_helper') }}</span>
                        </div>

                        <div class="form-group {{ $errors->has('grand_total') ? 'has-error' : '' }}">
                            <label class="required" for="grand_total">{{ trans('cruds.sale.fields.grand_total') }}</label>
                            <input class="form-control" type="text" name="grand_total" id="grand_total" value="Rp. {{ number_format($grandTotal) }}" disabled required>
                        </div>

                        <div class="form-group {{ $errors->has('total') ? 'has-error' : '' }}">
                            <label class="required" for="grand_total">Total {{ $typetukarTambah == 1 ? 'uang yang diterima' : 'uang yang dibayarkan' }}</label>
                            <input class="form-control" type="text" name="total" id="total" value="Rp. {{ number_format($grandTotalTukarTambah) }}" disabled required>
                        </div>

                        <div class="form-group">
                            <label class="required" for="alasan">Alasan</label>
                            <textarea wire:model="alasan" class="form-control" placeholder="Alasan perubahan data" required></textarea>
                        </div>

                        <div class="form-group">
                            <label for="alasan">Catatan</label>
                            <textarea wire:model="catatan" class="form-control" id="alasan" placeholder="Catatan internal"></textarea>
                        </div>

                        <div class="form-group">
                            <a href="{{ route("admin.tukarTambahKurang.index") }}" type="button" class="btn btn-danger">
                                Kembali
                            </a>
                            @if($grandTotal == 0 || $customer["nama"] === "" || $alasan === "" || $grandTotalTukarTambah <= 0)
                                <button type="button" class="btn btn-default pull-right" data-toggle="modal" data-target="#preview-modal" disabled>
                                    Preview
                                </button>
                            @else
                                <button type="button" class="btn btn-info pull-right" data-toggle="modal" data-target="#preview-modal">
                                    Preview
                                </button>
                            @endif
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-lg-12">

            <div class="row">
                <div class="col-lg-12">
                    <h3 style="margin-top: 0px;padding-top: 0px;margin-bottom: 12px">Data {{ $typetukarTambah == 1 ? 'tukar tambah' : 'tukar kurang' }}</h3>
                </div>
                @for($i = 1; $i <= $totalKuitansi; $i++)
                    <div class="col-lg-12">
                        <div class="box box-default" style="border: 1px solid grey">
                            <div class="box-header">
                                <div style="display: flex;align-items: center;justify-content: space-between">
                                    <div>
                                        <h3 class="box-title">Barang sebelumnya {{$i}}</h3>
                                    </div>
                                    {{--                                    <div>--}}

                                    {{--                                        @if($totalKuitansi !== 1)--}}
                                    {{--                                            <button type="button" wire:click="removeTrxRow({{$i-1}})" class="btn btn-sm btn-danger"><i class="fa fa-times"></i></button>--}}
                                    {{--                                            <button type="button" wire:click="addRow({{$i-1}})" style="margin-left: 3px" class="btn btn-sm btn-success"><i class="fa fa-plus"></i></button>--}}
                                    {{--                                        @else--}}
                                    {{--                                            <button type="button" wire:click="addRow({{$i-1}})" class="btn btn-sm btn-success"><i class="fa fa-plus"></i></button>--}}
                                    {{--                                        @endif--}}

                                    {{--                                    </div>--}}
                                </div>
                            </div>
                            <div class="box-body table-responsive">
                                <table class="table table-bordered">
                                    <tbody>
                                    <tr>
                                        <th style="width: 10px">#</th>
                                        <th>Jenis</th>
                                        <th>Produk</th>
                                        <th>Varian</th>
                                        <th style="width: 85px">Berat</th>
                                        <th style="width: 85px">Karat</th>
                                        <th>Harga/Grm</th>
                                        <th>Harga Sekarang</th>
                                        <th>potongan</th>
                                        <th>Total</th>
                                        <th>Upload</th>
                                        {{--                                        <th>Act</th>--}}
                                    </tr>
                                    @if(!empty($trx))
                                        @foreach($trx[$i-1]["items"] as $index => $row)
                                            <tr>
                                                <td>{{ $loop->iteration }}</td>
                                                <td>
                                                    <select wire:model.lazy="trx.{{ $i-1 }}.items.{{$index}}.jenis_id" class="form-control" name="jenis_emas.{{$i}}.{{ $index }}" id="jenis_emas.{{$i}}.{{ $index }}" required>
                                                        <option value="">- pilih -</option>
                                                        @foreach($jenis_emas as $id => $jenis)
                                                            <option value="{{ $id }}">{{ $jenis }}</option>
                                                        @endforeach
                                                    </select>
                                                </td>
                                                <td>
                                                    <livewire:list-product
                                                            :kwitansi="$i-1"
                                                            :index="$index"
                                                            :selected="$row['produk_id']"
                                                            :category="$row['jenis_id']"
                                                            :wire:key="'list-product-'.$row['jenis_id'] . '-in-'.$index . '-kwi-'. ($i-1)"/>
                                                </td>
                                                <td style="width: 85px">
                                                    <input wire:model="trx.{{ $i - 1 }}.items.{{$index}}.varian" class="form-control" type="text" name="varian.{{ $i - 1 }}.{{ $index }}" id="varian.{{ $i - 1 }}.{{ $index }}" placeholder="masukan varian">
                                                </td>
                                                <td style="width: 85px">
                                                    <input wire:model="trx.{{ $i-1 }}.items.{{$index}}.berat" class="form-control" type="number" name="berat.{{$i}}.{{ $index }}" id="berat.{{$i}}.{{ $index }}" step="0.01" required placeholder="masukan berat" disabled>
                                                </td>
                                                <td style="width: 85px">
                                                    <input wire:model="trx.{{ $i-1 }}.items.{{$index}}.kadar" class="form-control" type="number" name="kadar.{{$i}}.{{ $index }}" id="kadar.{{$i}}.{{ $index }}" value="" step="0.01" required placeholder="masukan karat" disabled>
                                                </td>
                                                <td>
                                                    <input wire:model="trx.{{ $i-1 }}.items.{{$index}}.harga" class="form-control" type-currency="IDR" type="text" name="hargaPerGrm.{{$i}}.{{ $index }}" id="hargaPerGrm.{{$i}}.{{ $index }}" value="0" step="0.01" required placeholder="masukan harga" disabled>
                                                </td>
                                                <td>
                                                    <input wire:model="trx.{{ $i-1 }}.items.{{$index}}.harga_sekarang" type-currency="IDR" class="form-control" type="text" name="harga_sekarang.{{$i}}.{{ $index }}" id="harga_sekarang.{{$i}}.{{ $index }}" value="0" step="0.01" required placeholder="masukan harga">
                                                </td>
                                                <td>
                                                    <input wire:model="trx.{{ $i-1 }}.items.{{$index}}.potongan" type-currency="IDR" class="form-control" type="text" name="potongan.{{$i}}.{{ $index }}" id="potongan.{{$i}}.{{ $index }}" value="0" step="0" required placeholder="total potongan">
                                                </td>
                                                <td>
                                                    <livewire:total-item-kuitansi
                                                            :kwitansi="$i-1"
                                                            :index="$index"
                                                            :berat="$row['berat']"
                                                            :harga="$row['harga']"
                                                            :harga_sekarang="$row['harga_sekarang']"
                                                            :potongan="$row['potongan']"
                                                            :wire:key="'NEW_EDIT_TOTAL'.rand().($i-1). '-index-'. $index"
                                                    />
                                                </td>
                                                <td>
                                                    @if(url(str_replace('public','storage', $trx[$i-1]['items'][$index]['uploaded'])) !== "" && $trx[$i-1]['items'][$index]['uploaded'] !== null)
                                                        <a target="_blank" href="{{ url(str_replace('public','storage', $trx[$i-1]['items'][$index]['uploaded'])) }}">
                                                            <img width="50" height="50" src="{{ url(str_replace('public','storage', $trx[$i-1]['items'][$index]['uploaded'])) ?? "#" }}"/>
                                                        </a>
                                                    @else
                                                        -
                                                    @endif
                                                </td>
                                                {{--                                                <td>--}}
                                                {{--                                                    <button type="button" wire:click="deleteRow({{$i}}, {{$index}})" class="btn btn-sm btn-danger"><i class="fa fa-times"></i></button>--}}
                                                {{--                                                </td>--}}
                                            </tr>
                                        @endforeach
                                    @endif
                                    </tbody>
                                </table>

                                <div class="form-group" style="margin-top: 15px">
                                    <label class="required" for="sub_total.{{ $i-1 }}">Sub total</label>
                                    <livewire:sub-total-kuitansi :trxList="$trx" :kwitansi="$i-1" wire:key="sub-total-{{rand()}}-kwitansi-{{$i-1}}"/>
                                </div>
                            </div>
                        </div>
                    </div>
                @endfor
            </div>

            <div class="row">
                <div class="col-lg-12">
                    <h3 style="margin-top: 0px;padding-top: 0px;margin-bottom: 12px">Data penjualan</h3>
                </div>
                @for($i = 1; $i <= $trxKuitansi; $i++)
                    <div class="col-lg-12">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="box box-default" style="border: 1px solid grey">
                                    <div class="box-header">
                                        <div style="display: flex; justify-content: space-between;align-items: center">
                                            <h3 class="box-title">Kuitansi {{ $typetukarTambah == 1 ? 'tukar tambah' : 'tukar kurang' }} {{ $i }}</h3>
                                            <div>
                                                @if($trxKuitansi !== 1)
                                                    <button type="button" wire:click="removeTrxRow({{$i-1}})" class="btn btn-sm btn-danger"><i class="fa fa-times"></i></button>
                                                    <button type="button" wire:click="addRow({{$i-1}},'invoice')" style="margin-left: 3px" class="btn btn-sm btn-success"><i class="fa fa-plus"></i></button>
                                                @else
                                                    <button type="button" wire:click="addRow({{$i-1}},'invoice')" class="btn btn-sm btn-success"><i class="fa fa-plus"></i></button>
                                                @endif
                                            </div>

                                        </div>
                                    </div>
                                    <div class="box-body table-responsive">
                                        <table class="table table-bordered">
                                            <thead>
                                            <tr>
                                                <th style="width: 10px">#</th>
                                                <th>Jenis</th>
                                                <th>Produk</th>
                                                <th>Varian</th>
                                                <th style="width: 85px">Berat</th>
                                                <th style="width: 85px">Karat</th>
                                                <th>Harga/Grm</th>
                                                <th>Ongkos</th>
                                                <th>Total</th>
                                                <th>Upload</th>
                                                <th>Act</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            @if(!empty($invoiceTukarTambahKurangData))
                                                @foreach($invoiceTukarTambahKurangData[$i-1]["items"] as $index => $row)
                                                    <tr>
                                                        <td>{{ $loop->iteration }}</td>
                                                        <td>
                                                            <select wire:model.lazy="invoiceTukarTambahKurangData.{{ $i - 1 }}.items.{{$index}}.jenis_id" class="form-control" name="jenis_emas.{{ $i - 1 }}.{{ $index }}" id="jenis_emas.{{ $i - 1 }}.{{ $index }}" required>
                                                                <option value="">- pilih -</option>
                                                                @foreach($jenis_emas as $id => $jenis)
                                                                    <option value="{{ $id }}">{{ $jenis }}</option>
                                                                @endforeach
                                                            </select>
                                                            @error("invoiceTukarTambahKurangData.".($i-1).".items.".$index.".jenis_id") <span class="error">{{ $message }}</span> @enderror
                                                        </td>
                                                        <td>
                                                            <livewire:list-product
                                                                    :from="2"
                                                                    :kwitansi="$i-1"
                                                                    :index="$index"
                                                                    :selected="$row['produk_id']"
                                                                    :category="$row['jenis_id']"
                                                                    :wire:key="'Newlist-product-'.$row['jenis_id'] . '-in-'.$index . '-kwi-'. ($i-1)"/>
                                                            @error("invoiceTukarTambahKurangData.".($i-1).".items.".$index.".produk_id") <span class="error">{{ $message }}</span> @enderror
                                                        </td>
                                                        <td style="width: 85px">
                                                            <input wire:model="invoiceTukarTambahKurangData.{{ $i - 1 }}.items.{{$index}}.varian" class="form-control" type="text" name="varian.{{ $i - 1 }}.{{ $index }}" id="varian.{{ $i - 1 }}.{{ $index }}" placeholder="masukan varian">
                                                        </td>
                                                        <td style="width: 85px">
                                                            <input wire:model="invoiceTukarTambahKurangData.{{ $i - 1 }}.items.{{$index}}.berat" class="form-control" type="number" name="berat.{{ $i - 1 }}.{{ $index }}" id="berat.{{ $i - 1 }}.{{ $index }}" step="0.01" required placeholder="masukan berat">
                                                            @error("invoiceTukarTambahKurangData.".($i-1).".items.".$index.".berat") <span class="error">{{ $message }}</span> @enderror
                                                        </td>
                                                        <td style="width: 85px">
                                                            <input wire:model="invoiceTukarTambahKurangData.{{ $i - 1 }}.items.{{$index}}.kadar" class="form-control" type="number" name="kadar.{{ $i - 1 }}.{{ $index }}" id="kadar.{{ $i - 1 }}.{{ $index }}" value="" step="0.01" required placeholder="masukan kadar">
                                                            @error("invoiceTukarTambahKurangData.".($i-1).".items.".$index.".kadar") <span class="error">{{ $message }}</span> @enderror
                                                        </td>
                                                        <td>
                                                            <input wire:model="invoiceTukarTambahKurangData.{{ $i - 1 }}.items.{{$index}}.harga" class="form-control" type-currency="IDR" type="text" name="hargaPerGrm.{{ $i - 1 }}.{{ $index }}" id="hargaPerGrm.{{ $i - 1 }}.{{ $index }}" value="0" step="0.01" required placeholder="masukan harga">
                                                            @error("invoiceTukarTambahKurangData.".($i-1).".items.".$index.".harga") <span class="error">{{ $message }}</span> @enderror
                                                        </td>
                                                        <td>
                                                            <input wire:model="invoiceTukarTambahKurangData.{{ $i - 1 }}.items.{{$index}}.ongkos" class="form-control" type-currency="IDR" type="text" name="ongkos.{{ $i - 1 }}.{{ $index }}" id="ongkos.{{ $i - 1 }}.{{ $index }}" value="0" step="0" required placeholder="total ongkos">
                                                            @error("invoiceTukarTambahKurangData.".($i-1).".items.".$index.".ongkos") <span class="error">{{ $message }}</span> @enderror
                                                        </td>
                                                        <td>
                                                            <livewire:total-item-kwitansi
                                                                    :kwitansi="$i-1"
                                                                    :index="$index"
                                                                    :berat="$row['berat']"
                                                                    :harga="$row['harga']"
                                                                    :ongkos="$row['ongkos']"
                                                                    :wire:key="'NEW_EDIT_TOTAL'.rand().($i-1).'-index-'. $index"
                                                            />
                                                        </td>
                                                        <td>
                                                            <input class="form-control" type="file" name="image.{{ $i-1 }}.{{ $index }}" id="image.{{ $i - 1 }}.{{ $index }}">
                                                            @error("invoiceTukarTambahKurangData.".($i-1).".items.".$index.".uploaded") <span class="error">{{ $message }}</span> @enderror
                                                        </td>
                                                        <td>
                                                            <button type="button" wire:click="deleteRow({{ $i-1 }}, {{$index}}, 'invoice')" class="btn btn-sm btn-danger"><i class="fa fa-times"></i></button>
                                                        </td>
                                                    </tr>
                                                @endforeach
                                            @endif
                                            </tbody>
                                        </table>
                                        <div class="form-group" style="margin-top: 15px">
                                            <label class="required" for="sub_total.{{ $i - 1 }}">Sub total</label>
                                            <livewire:sub-total-kwitansi :type="2" :trxList="$invoiceTukarTambahKurangData" :kwitansi="$i-1" wire:key="new-sub-total-{{rand()}}-kwitansi-{{ $i - 1 }}"/>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                @endfor
            </div>
        </div>

        <div class="modal fade" id="preview-modal" wire:ignore.self>
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title">Preview data</h4>
                    </div>
                    <div class="modal-body">
                        <h4>Rincian {{ $typetukarTambah == 1 ? 'tukar tambah' : 'tukar kurang' }}</h4>
                        <table class="table table-bordered">
                            <tbody>
                            <tr>
                                <th>Nama customer</th>
                                <td>{{ $customer["nama"] }} <br/> {{ $customer["email"] }} <br/> {{ $customer["phone"] }}</td>
                            </tr>
                            <tr>
                                <th>Jumlah kuitansi</th>
                                <td>{{ $totalKuitansi }}</td>
                            </tr>
                            <tr>
                                <th>Total pembelian</th>
                                <td style="color: green">Rp. {{ number_format($grandTotal) }}</td>
                            </tr>
                            @if($from == 1)
                                <tr>
                                    <th>Total {{ $typetukarTambah == 1 ? 'uang yang diterima' : 'uang yang dibayarkan' }}</th>
                                    <td style="color: green">Rp. {{ number_format($grandTotalTukarTambah) }}</td>
                                </tr>
                            @endif
                            </tbody>
                        </table>

                        <div class="form-group">
                            <label class="required" for="tipe_pembayaran">Tipe pembayaran</label>
                            <div class="form-check">
                                <input class="form-check-input" wire:model="type_pembayaran" value="1" type="radio" name="flexRadioDefault" id="flexRadioDefault1">
                                <label class="form-check-label" for="flexRadioDefault1">
                                    Single
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" wire:model="type_pembayaran" value="2" type="radio" name="flexRadioDefault" id="flexRadioDefault2">
                                <label class="form-check-label" for="flexRadioDefault2">
                                    Multi
                                </label>
                            </div>
                        </div>

                        @if($type_pembayaran == 1)
                            <div class="form-group">
                                <label>Metode pembayaran <span class="text-danger">*</span></label>
                                <select class="form-control" wire:model="list_metode_pembayarans.0.metode_pembayaran_id" required>
                                    <option value="">- Pilih -</option>
                                    @foreach($metode_pembayarans as $metode_pembayaran)
                                        <option value="{{ $metode_pembayaran->id }}" {{ in_array($id, old('metode_pembayarans', [])) ? 'selected' : '' }}>{{ $metode_pembayaran->nama_metode }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <div class="form-group">
                                    <label>Jumlah <span class="text-danger">*</span></label>
                                    <input readonly value="{{ encodeCurrency($grandTotalTukarTambah) }}" class="form-control" name="totalPembayaran"/>
                                </div>
                            </div>
                        @elseif($type_pembayaran == 2)
                            <div class="row">
                                <div class="col-lg-6">
                                    <h4>List pembayaran</h4>
                                    <h4 style="padding-bottom: 0;margin-bottom: 0" class="text-success">Sisa Rp.{{ number_format($tempSisaPembayaran) }}</h4>
                                </div>
                                <div class="col-lg-6">
                                    <button class="btn btn-success pull-right" type="button" wire:click="onClickCreateMetodePembayaran">+</button>
                                </div>
                            </div>
                            <hr/>
                            <div class="row">
                                @foreach($list_metode_pembayarans as $index => $multi)
                                    <div class="col-lg-6">
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="form-group">
                                                    <div style="margin-bottom: 10px">
                                                        <label>Metode pembayaran <span class="text-danger">*</span></label>
                                                        @if($index != 0)
                                                            <button class="btn btn-sm btn-danger pull-right" wire:click="onClickRemoveMetodePembayaran({{ $index }})" type="button">-</button>
                                                        @endif
                                                    </div>
                                                    <select class="form-control" wire:model="list_metode_pembayarans.{{ $index }}.metode_pembayaran_id" required>
                                                        <option value="">- Pilih -</option>
                                                        @foreach($payment_list as $list)
                                                            <option {{ $list['used'] ? 'disabled' : '' }} value="{{ $list['id'] }}" {{ in_array($list['id'], old('metode_pembayarans', [])) ? 'selected' : '' }}>{{ $list['name'] }}</option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="form-group">
                                                    <label>Jumlah <span class="text-danger">*</span></label>
                                                    <input type="text" type-currency="IDR" wire:model="list_metode_pembayarans.{{ $index }}.amount" placeholder="Masukan jumlah" class="form-control" required/>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        @endif

                        <hr/>
                        <h4>Rincian items {{ $typetukarTambah == 1 ? 'tukar tambah' : 'tukar kurang' }}</h4>
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                <tr>
                                    <td>No</td>
                                    <td>Jenis produk</td>
                                    <td>Produk</td>
                                    <td>Varian</td>
                                    <th style="width: 85px">Berat</th>
                                    <th style="width: 85px">Karat</th>
                                    <th>Harga/Grm</th>
                                    <th>Ongkos</th>
                                    <td>Total</td>
                                </tr>
                                </thead>
                                <tbody>
                                @if(!empty($invoiceTukarTambahKurangData))
                                    @foreach($invoiceTukarTambahKurangData[0]["items"] as $index => $row)
                                        <tr  style="background-color: #eee">
                                            <td>
                                                {{ $loop->iteration }}
                                            </td>
                                            <td>
                                                <select wire:model.lazy="trx.0.items.{{$index}}.jenis_id" class="form-control select2Livewire" name="jenis_emas.preview.0.{{ $index }}" id="jenis_emas.preview.0.{{ $index }}" required disabled>
                                                    <option value="">- pilih -</option>
                                                    @foreach($jenis_emas as $id => $jenis)
                                                        <option value="{{ $id }}">{{ $jenis }}</option>
                                                    @endforeach
                                                </select>
                                            </td>
                                            <td>
                                                {{  $row['nama_produk'] }}
                                            </td>
                                            <td>
                                                {{  $row['varian'] }}
                                            </td>
                                            <td>
                                                {{  $row['berat'] }}
                                            </td>
                                            <td>
                                                {{  $row['kadar'] }}
                                            </td>
                                            <td>
                                                {{  $row['harga'] }}
                                            </td>
                                            <td>
                                                {{ $row['ongkos'] }}
                                            </td>
                                            <td>
                                                {{
                                                encodeCurrency(
                                                    (
                                                        (float) $row['berat'] *
                                                        (float) decodeCurrency($row['harga'])
                                                    ) +
                                                    (float) decodeCurrency($row['ongkos'])
                                                ) }}
                                            </td>
                                        </tr>
                                    @endforeach
                                @endif
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Tutup</button>
                        @if($type_pembayaran == 2)
                            <button wire:click="save" type="button" {{$list_metode_pembayarans[0]['metode_pembayaran_id'] !== '' && $list_metode_pembayarans[0]['amount'] != 0 && $tempSisaPembayaran == 0? '' : 'disabled'}} class="btn btn-success" wire:loading.attr="disabled">Simpan</button>
                        @else
                            <button wire:click="save" type="button" {{$list_metode_pembayarans[0]['metode_pembayaran_id'] !== '' ? '' : 'disabled'}} class="btn btn-success" wire:loading.attr="disabled">Simpan</button>
                        @endif
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>


<script>

    document.addEventListener("DOMContentLoaded", () => {
        Livewire.hook('element.updated', (el, component) => {
            document.querySelectorAll('input[type-currency="IDR"]').forEach((element) => {
                element.addEventListener('keyup', function(e) {
                    let cursorPostion = this.selectionStart;
                    let value = parseInt(this.value.replace(/[^,\d]/g, ''));
                    let originalLenght = this.value.length;
                    if (isNaN(value)) {
                        this.value = "";
                    } else {
                        this.value = value.toLocaleString('id-ID', {
                            currency: 'IDR',
                            style: 'currency',
                            minimumFractionDigits: 0
                        });
                        cursorPostion = this.value.length - originalLenght + cursorPostion;
                        this.setSelectionRange(cursorPostion, cursorPostion);
                    }
                });
            });
        })
        Livewire.hook('element.removed', (el, component) => {
            document.querySelectorAll('input[type-currency="IDR"]').forEach((element) => {
                element.addEventListener('keyup', function(e) {
                    let cursorPostion = this.selectionStart;
                    let value = parseInt(this.value.replace(/[^,\d]/g, ''));
                    let originalLenght = this.value.length;
                    if (isNaN(value)) {
                        this.value = "";
                    } else {
                        this.value = value.toLocaleString('id-ID', {
                            currency: 'IDR',
                            style: 'currency',
                            minimumFractionDigits: 0
                        });
                        cursorPostion = this.value.length - originalLenght + cursorPostion;
                        this.setSelectionRange(cursorPostion, cursorPostion);
                    }
                });
            });
        })
    });
</script>