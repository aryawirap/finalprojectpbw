<div>
    <div class="content">

        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading" style="display: flex; justify-content: space-between; align-items: center">
                        <div>{{ trans('global.create') }} {{ trans('cruds.karyawanGaji.title_singular') }}</div>
                        <div>
                            <a class="btn btn-danger" href="{{ route('admin.gaji.index') }}">
                                {{ trans('global.back') }} {{ trans('cruds.karyawanGaji.title_singular') }}
                            </a>
                        </div>
                    </div>
                    <div class="panel-body">
                        <form>
                            @csrf
                            <div class="form-group {{ $errors->has('karyawan_id') ? 'has-error' : '' }}">
                                <label class="required">{{ trans('cruds.karyawanGaji.fields.karyawan_id') }}</label>
                                <select class="form-control" wire:model="karyawan_id" name="karyawan_id" id="karyawan_id" required>
                                    <option value="">{{ trans('global.pleaseSelect') }}</option>
                                    @foreach($karyawans as $key => $label)
                                        <option value="{{ $key }}" {{ old('type', '') === (string) $key ? 'selected' : '' }}>{{ $label }}</option>
                                    @endforeach
                                </select>
                                @if($errors->has('karyawan_id'))
                                    <span class="help-block" role="alert">{{ $errors->first('karyawan_id') }}</span>
                                @endif
                                <span class="help-block">{{ trans('cruds.karyawanGaji.fields.karyawan_id_helper') }}</span>
                            </div>

                            <div class="form-group {{ $errors->has('gaji') ? 'has-error' : '' }}">
                                <label class="required" for="gaji">{{ trans('cruds.karyawanGaji.fields.gaji') }}</label>
                                <input wire:model="gaji" type-currency="IDR" class="form-control" type="text" name="gaji" id="gaji" value="{{ old('gaji', '') }}" required>
                                @if($errors->has('gaji'))
                                    <span class="help-block" role="alert">{{ $errors->first('gaji') }}</span>
                                @endif
                                <span class="help-block">{{ trans('cruds.karyawanGaji.fields.gaji_helper') }}</span>
                            </div>

                            <table class=" table table-bordered table-striped">
                                <thead>
                                <tr>
                                    <th width="10">

                                    </th>
                                    <th>
                                        {{ trans('cruds.hutang.fields.jenis_hutang') }}
                                    </th>
                                    <th>
                                        {{ trans('cruds.hutang.fields.jenis_barang') }}
                                    </th>
                                    <th>
                                        {{ trans('cruds.hutang.fields.jumlah_hutang') }}
                                    </th>
                                    <th>
                                        {{ trans('cruds.hutang.fields.nominal_cicilan') }}
                                    </th>
                                    <th>
                                        {{ trans('cruds.hutang.fields.lama_cicilan') }}
                                    </th>
                                    <th>
                                        Sudah dibayarkan
                                    </th>
                                    <th>
                                        Created
                                    </th>
                                </tr>
                                @forelse($listHutang as $index => $row)
                                <tr>
                                    <td>
                                        <input wire:model="listSelectedHutang.{{ $row->id }}" type="checkbox"/>
                                    </td>
                                    <td>
                                        {{ $row->jenis_hutang == 1 ? 'Cicilan' : 'Kas Bon' }}
                                    </td>
                                    <td>
                                        {{ $row->jenis_barang->jenis }}
                                    </td>
                                    <td>
                                        {{ encodeCurrency($row->jumlah_hutang) }}
                                    </td>
                                    <td>
                                        {{ encodeCurrency($row->nominal_cicilan) }}
                                    </td>
                                    <td>
                                        {{ $row->lama_cicilan }}
                                    </td>
                                    <td>
                                        {{ encodeCurrency($row->sudahDibayar) }}
                                    </td>
                                    <td>
                                        {{ $row->created_at->format("d-m-Y H:i:s") }}
                                    </td>
                                </tr>
                                @empty
                                    <tr>
                                        <td style="text-align: center" colspan="9">- Tidak ada data hutang -</td>
                                    </tr>
                                @endforelse

                                </thead>
                            </table>

                            <div class="form-group {{ $errors->has('potongan') ? 'has-error' : '' }}">
                                <label class="required" for="potongan">{{ trans('cruds.karyawanGaji.fields.potongan') }}</label>
                                <input wire:model="potongan" readonly class="form-control" type="text" name="potongan" id="potongan" value="{{ old('potongan', '') }}" required>
                            </div>

                            <div class="form-group {{ $errors->has('totalGajian') ? 'has-error' : '' }}">
                                <label class="required" for="totalGajian">{{ trans('cruds.karyawanGaji.fields.totalGajian') }}</label>
                                <input wire:model="gajiBersih" readonly class="form-control" type="text" name="totalGajian" id="totalGajian" value="{{ old('totalGajian', '') }}" required>
                            </div>

                            <div class="form-group">
                                <button class="btn btn-danger" wire:click.prevent="save" wire:loading.attr="disabled">
                                    {{ trans('global.save') }}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>



            </div>
        </div>
    </div>
</div>
