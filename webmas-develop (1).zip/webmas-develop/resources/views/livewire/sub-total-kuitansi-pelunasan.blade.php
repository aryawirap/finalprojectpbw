<div>
    <input class="form-control" disabled required value="Rp. {{ number_format($subTotal) }}">
</div>
