<div>
    <select wire:model="selected" class="form-control" required @disabled($disabled !== false)>
        <option value="">- pilih -</option>
        @foreach($products as $index => $product)
            <option value="{{$index}}">{{$product}}</option>
        @endforeach
    </select>
</div>

