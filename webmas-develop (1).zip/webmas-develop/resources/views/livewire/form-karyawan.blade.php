<div>

    @if($type === 'create')
    @else

    @endif

    {{--  role selected not admin  --}}
    @if($roleSelected === "2" && $karyawan == null)
        <div class="form-group {{ $errors->has('alamat') ? 'has-error' : '' }}">
            <label for="alamat">{{ trans('cruds.karyawan.fields.alamat') }}</label>
            <textarea class="form-control ckeditor" name="alamat" id="alamat">{!! old('alamat') !!}</textarea>
            @if($errors->has('alamat'))
                <span class="help-block" role="alert">{{ $errors->first('alamat') }}</span>
            @endif
            <span class="help-block">{{ trans('cruds.karyawan.fields.alamat_helper') }}</span>
        </div>
        <div class="form-group {{ $errors->has('bagian') ? 'has-error' : '' }}">
            <label class="required" for="bagian">{{ trans('cruds.karyawan.fields.bagian') }}</label>
            <input class="form-control" type="text" name="bagian" id="bagian" value="{{ old('bagian', '') }}" required>
            @if($errors->has('bagian'))
                <span class="help-block" role="alert">{{ $errors->first('bagian') }}</span>
            @endif
            <span class="help-block">{{ trans('cruds.karyawan.fields.bagian_helper') }}</span>
        </div>
        <div class="form-group {{ $errors->has('gaji') ? 'has-error' : '' }}">
            <label class="required" for="gaji">{{ trans('cruds.karyawan.fields.gaji') }}</label>
            <input class="form-control" type="number" name="gaji" id="gaji" value="{{ old('gaji', '') }}" step="0.01" required>
            @if($errors->has('gaji'))
                <span class="help-block" role="alert">{{ $errors->first('gaji') }}</span>
            @endif
            <span class="help-block">{{ trans('cruds.karyawan.fields.gaji_helper') }}</span>
        </div>
        <div class="form-group {{ $errors->has('tanggal_masuk') ? 'has-error' : '' }}">
            <label class="required" for="tanggal_masuk">{{ trans('cruds.karyawan.fields.tanggal_masuk') }}</label>
            <input class="form-control date" type="date" name="tanggal_masuk" id="tanggal_masuk" value="{{ old('tanggal_masuk') }}" required>
            @if($errors->has('tanggal_masuk'))
                <span class="help-block" role="alert">{{ $errors->first('tanggal_masuk') }}</span>
            @endif
            <span class="help-block">{{ trans('cruds.karyawan.fields.tanggal_masuk_helper') }}</span>
        </div>
        <div class="form-group {{ $errors->has('tanggal_keluar') ? 'has-error' : '' }}">
            <label for="tanggal_keluar">{{ trans('cruds.karyawan.fields.tanggal_keluar') }}</label>
            <input class="form-control date" type="date" name="tanggal_keluar" id="tanggal_keluar" value="{{ old('tanggal_keluar') }}">
            @if($errors->has('tanggal_keluar'))
                <span class="help-block" role="alert">{{ $errors->first('tanggal_keluar') }}</span>
            @endif
            <span class="help-block">{{ trans('cruds.karyawan.fields.tanggal_keluar_helper') }}</span>
        </div>
    @endif

    @if($roleSelected === "2" && $type === "edit" && $karyawan !== null) {{--  role selected not admin and edit form  --}}
        <div class="form-group {{ $errors->has('alamat') ? 'has-error' : '' }}">
            <label for="alamat">{{ trans('cruds.karyawan.fields.alamat') }}</label>
            <textarea class="form-control ckeditor" name="alamat" id="alamat">{!! old('alamat', $karyawan->alamat) !!}</textarea>
            @if($errors->has('alamat'))
                <span class="help-block" role="alert">{{ $errors->first('alamat') }}</span>
            @endif
            <span class="help-block">{{ trans('cruds.karyawan.fields.alamat_helper') }}</span>
        </div>
        <div class="form-group {{ $errors->has('bagian') ? 'has-error' : '' }}">
            <label class="required" for="bagian">{{ trans('cruds.karyawan.fields.bagian') }}</label>
            <input class="form-control" type="text" name="bagian" id="bagian" value="{{ old('bagian', $karyawan->bagian) }}" required>
            @if($errors->has('bagian'))
                <span class="help-block" role="alert">{{ $errors->first('bagian') }}</span>
            @endif
            <span class="help-block">{{ trans('cruds.karyawan.fields.bagian_helper') }}</span>
        </div>
        <div class="form-group {{ $errors->has('gaji') ? 'has-error' : '' }}">
            <label class="required" for="gaji">{{ trans('cruds.karyawan.fields.gaji') }}</label>
            <input class="form-control" type="number" name="gaji" id="gaji" value="{{ old('gaji', $karyawan->gaji) }}" step="0.01" required>
            @if($errors->has('gaji'))
                <span class="help-block" role="alert">{{ $errors->first('gaji') }}</span>
            @endif
            <span class="help-block">{{ trans('cruds.karyawan.fields.gaji_helper') }}</span>
        </div>
        <div class="form-group {{ $errors->has('tanggal_masuk') ? 'has-error' : '' }}">
            <label class="required" for="tanggal_masuk">{{ trans('cruds.karyawan.fields.tanggal_masuk') }}</label>
            <input class="form-control date" type="date" name="tanggal_masuk" id="tanggal_masuk" value="{{ old('tanggal_masuk', $karyawan->tanggal_masuk) }}" required>
            @if($errors->has('tanggal_masuk'))
                <span class="help-block" role="alert">{{ $errors->first('tanggal_masuk') }}</span>
            @endif
            <span class="help-block">{{ trans('cruds.karyawan.fields.tanggal_masuk_helper') }}</span>
        </div>
        <div class="form-group {{ $errors->has('tanggal_keluar') ? 'has-error' : '' }}">
            <label for="tanggal_keluar">{{ trans('cruds.karyawan.fields.tanggal_keluar') }}</label>
            <input class="form-control date" type="date" name="tanggal_keluar" id="tanggal_keluar" value="{{ old('tanggal_keluar', $karyawan->tanggal_keluar) }}">
            @if($errors->has('tanggal_keluar'))
                <span class="help-block" role="alert">{{ $errors->first('tanggal_keluar') }}</span>
            @endif
            <span class="help-block">{{ trans('cruds.karyawan.fields.tanggal_keluar_helper') }}</span>
        </div>
    @else
    @endif


</div>
