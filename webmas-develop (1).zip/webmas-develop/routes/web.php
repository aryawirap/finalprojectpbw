<?php
Route::redirect('/', '/login');
Route::get('/home', [\App\Http\Controllers\Admin\HomeController::class,'index']);

Auth::routes(['register' => false]);

Route::group(['prefix' => 'admin', 'as' => 'admin.', 'namespace' => 'Admin', 'middleware' => ['auth']], function () {
    Route::get('/', 'HomeController@index')->name('home');
    // Permissions
    Route::delete('permissions/destroy', 'PermissionsController@massDestroy')->name('permissions.massDestroy');
    Route::resource('permissions', 'PermissionsController');

    // Roles
    Route::delete('roles/destroy', 'RolesController@massDestroy')->name('roles.massDestroy');
    Route::resource('roles', 'RolesController');

    // Users
    Route::delete('users/destroy', 'UsersController@massDestroy')->name('users.massDestroy');
    Route::resource('users', 'UsersController');

    // Category
    Route::delete('categories/destroy', 'CategoryController@massDestroy')->name('categories.massDestroy');
    Route::resource('categories', 'CategoryController');

    // Stock
    Route::delete('stocks/destroy', 'StockController@massDestroy')->name('stocks.massDestroy');
    Route::post('stocks/media', 'StockController@storeMedia')->name('stocks.storeMedia');
    Route::post('stocks/ckmedia', 'StockController@storeCKEditorImages')->name('stocks.storeCKEditorImages');
    Route::resource('stocks', 'StockController');

    // General Config
    Route::delete('general-configs/destroy', 'GeneralConfigController@massDestroy')->name('general-configs.massDestroy');
    Route::resource('general-configs', 'GeneralConfigController');

    // Audit Logs
    Route::resource('audit-logs', 'AuditLogsController', ['except' => ['create', 'store', 'edit', 'update', 'destroy']]);

    // Sale
    Route::delete('sales/destroy', 'SaleController@massDestroy')->name('sales.massDestroy');
    Route::get('sales/{sale}/invoice', 'SaleController@invoice')->name('sales.invoice');
    Route::resource('sales', 'SaleController');

    // Metode Pembayaran
    Route::delete('metode-pembayarans/destroy', 'MetodePembayaranController@massDestroy')->name('metode-pembayarans.massDestroy');
    Route::post('metode-pembayarans/media', 'MetodePembayaranController@storeMedia')->name('metode-pembayarans.storeMedia');
    Route::post('metode-pembayarans/ckmedia', 'MetodePembayaranController@storeCKEditorImages')->name('metode-pembayarans.storeCKEditorImages');
    Route::resource('metode-pembayarans', 'MetodePembayaranController');

    // Customer
    Route::delete('customers/destroy', 'CustomerController@massDestroy')->name('customers.massDestroy');
    Route::resource('customers', 'CustomerController');

    // Karyawan
    Route::delete('karyawans/destroy', 'KaryawanController@massDestroy')->name('karyawans.massDestroy');
    Route::post('karyawans/media', 'KaryawanController@storeMedia')->name('karyawans.storeMedia');
    Route::post('karyawans/ckmedia', 'KaryawanController@storeCKEditorImages')->name('karyawans.storeCKEditorImages');
    Route::resource('karyawans', 'KaryawanController');

    // Jenis Barang Hutang
    Route::delete('jenis-barang-hutangs/destroy', 'JenisBarangHutangController@massDestroy')->name('jenis-barang-hutangs.massDestroy');
    Route::resource('jenis-barang-hutangs', 'JenisBarangHutangController');

    // Hutang
    Route::delete('hutangs/destroy', 'HutangController@massDestroy')->name('hutangs.massDestroy');
    Route::resource('hutangs', 'HutangController');

    // Pembelian
    Route::delete('pembelian/destroy', 'PembelianController@massDestroy')->name('pembelian.massDestroy');
    Route::get('pembelian/{pembelian}/invoice', 'PembelianController@invoice')->name('pembelian.invoice');
    Route::resource('pembelian', 'PembelianController');
    
    // Pemesanan
    Route::delete('pemesanan/destroy', 'PemesananController@massDestroy')->name('pemesanan.massDestroy');
    Route::get('pemesanan/{pemesanan}/invoice', 'PemesananController@invoice')->name('pemesanan.invoice');
    Route::resource('pemesanan', 'PemesananController');
    
    // Pelunasan
    Route::delete('pelunasan/destroy', 'PelunasanController@massDestroy')->name('pelunasan.massDestroy');
    Route::get('pelunasan/{pelunasan}/invoice', 'PelunasanController@invoice')->name('pelunasan.invoice');
    Route::resource('pelunasan', 'PelunasanController');

    // Tukar Tambah/Kurang
    Route::delete('tukarTambahKurang/destroy', 'TukarTambahKurangController@massDestroy')->name('tukarTambahKurang.massDestroy');
    Route::get('tukarTambahKurang/{tukarTambahKurang}/invoice', 'TukarTambahKurangController@invoice')->name('tukarTambahKurang.invoice');
    Route::resource('tukarTambahKurang', 'TukarTambahKurangController');

    // Berangkas
    Route::delete('berangkas/destroy', 'BerangkasController@massDestroy')->name('berangkas.massDestroy');
    Route::resource('berangkas', 'BerangkasController');

    // Cash Opname
    Route::resource('cashOpname', 'CashOpnameController');

    // stock Opname
    Route::delete('stockOpname/{stockOpnameDetail}/deleteStock', 'StockOpnamesController@deleteStock')->name('stockOpname.deleteStock');
    Route::get('stockOpname/{stockOpname}/{tgl}/addStock', 'StockOpnamesController@addStock')->name('stockOpname.addStock');
    Route::post('stockOpname/syncStockOpname', 'StockOpnamesController@syncStockOpname')->name('stockOpname.syncStock');
    Route::resource('stockOpname', 'StockOpnamesController')->except(['edit','update','destroy']);

    // gaji
    Route::resource('gaji', 'KaryawanGajisController');
});

Route::group(['prefix' => 'profile', 'as' => 'profile.', 'namespace' => 'Auth', 'middleware' => ['auth']], function () {
    // Change password
    if (file_exists(app_path('Http/Controllers/Auth/ChangePasswordController.php'))) {
        Route::get('password', 'ChangePasswordController@edit')->name('password.edit');
        Route::post('password', 'ChangePasswordController@update')->name('password.update');
        Route::post('profile', 'ChangePasswordController@updateProfile')->name('password.updateProfile');
        Route::post('profile/destroy', 'ChangePasswordController@destroy')->name('password.destroyProfile');
    }
});
