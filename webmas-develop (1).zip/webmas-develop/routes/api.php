<?php

Route::group(['prefix' => 'v1', 'as' => 'api.', 'namespace' => 'Api\V1\Admin', 'middleware' => ['auth:sanctum']], function () {
    // Category
    Route::apiResource('categories', 'CategoryApiController');

    // Stock
    Route::apiResource('stocks', 'StockApiController');

    // General Config
    Route::apiResource('general-configs', 'GeneralConfigApiController');

    // Sale
    Route::apiResource('sales', 'SaleApiController');

    // Metode Pembayaran
    Route::post('metode-pembayarans/media', 'MetodePembayaranApiController@storeMedia')->name('metode-pembayarans.storeMedia');
    Route::apiResource('metode-pembayarans', 'MetodePembayaranApiController');

    // Customer
    Route::apiResource('customers', 'CustomerApiController');

    // Karyawan
    Route::post('karyawans/media', 'KaryawanApiController@storeMedia')->name('karyawans.storeMedia');
    Route::apiResource('karyawans', 'KaryawanApiController');

    // Jenis Barang Hutang
    Route::apiResource('jenis-barang-hutangs', 'JenisBarangHutangApiController');

    // Hutang
    Route::apiResource('hutangs', 'HutangApiController');
});
