<?php

namespace App\Models;

use App\Traits\Auditable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Penjualan extends Model
{
    use HasFactory;
    use Auditable;
    use SoftDeletes;

    public $table = 'penjualans';
    protected $fillable = [
        "noTrx",
        "totalKuitansi",
        "customer_id",
        "grandTotal",
        "status",
        "type",
        "payment_type",
        "from",
        "note",
        "pdfPath"
    ];

    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }

    public function penjualanItems()
    {
        return $this->hasMany(PenjualanItem::class);
    }

    public function comments()
    {
        return $this->morphMany(UpdatedDataReason::class, 'commentable');
    }

    public function metodePembayarans()
    {
        return $this->belongsToMany(MetodePembayaran::class)->withPivot("amount");
    }
}
