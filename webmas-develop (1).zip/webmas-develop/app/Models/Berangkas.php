<?php

namespace App\Models;

use App\Traits\Auditable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Berangkas extends Model
{
    use HasFactory;
    use Auditable;
    public $table = 'berangkas';

    protected $fillable = ['tanggal','type_berangkas','type','keterangan','jumlah','model_id'];

    public function scopeGetPengurangan($query)
    {
        return $query->where('type', 1);
    }

    public function scopeGetPenambahan($query)
    {
        return $query->where('type', 2);
    }

}
