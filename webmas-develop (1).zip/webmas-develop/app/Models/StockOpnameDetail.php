<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class StockOpnameDetail extends Model
{
    use SoftDeletes;
    protected $fillable = [
        "stock_opname_id",
        "penjualan_id",
        "catatan",
        "type",
        "jumlah",
    ];

    public function stockOpname()
    {
        return $this->belongsTo(StockOpname::class);
    }

    public function penjualan()
    {
        return $this->belongsTo(Penjualan::class);
    }
}