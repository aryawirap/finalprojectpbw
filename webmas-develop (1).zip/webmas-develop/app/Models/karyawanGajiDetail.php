<?php

namespace App\Models;

use App\Traits\Auditable;
use Illuminate\Database\Eloquent\Model;

class karyawanGajiDetail extends Model
{
    use Auditable;
    protected $table = 'karyawan_gaji_details';
    protected $fillable = [
        'karyawan_gaji_id',
        'hutang_id',
        'nominal'
    ];

    public function karyawanGaji()
    {
        return $this->belongsTo(KaryawanGaji::class);
    }
}