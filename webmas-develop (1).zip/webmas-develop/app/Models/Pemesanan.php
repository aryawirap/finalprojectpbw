<?php

namespace App\Models;

use App\Traits\Auditable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Pemesanan extends Model
{
    use Auditable;
    use HasFactory;
    use SoftDeletes;

    public $table = 'tb_pemesanan';

    protected $dates = [
        'created_at',
        'updated_at',
    ];

    protected $fillable = [
        'noTrx',
        'customer_id',
        'total_kuitansi',
        'grand_total',
        'status',
        'payment',
        'selesai_pesanan',
        'type',
        'sisa_pelunasan',
        'payment_type',
        'created_at',
        'updated_at',
        'note',
        "pdfPath"
    ];

    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }

    public function pemesananItems()
    {
        return $this->hasMany(PemesananItem::class);
    }

    public function comments()
    {
        return $this->morphMany(UpdatedDataReason::class, 'commentable');
    }

    public function metodePembayarans()
    {
        return $this->belongsToMany(MetodePembayaran::class)->withPivot("amount");
    }
}
