<?php

namespace App\Models;

use \DateTimeInterface;
use App\Traits\Auditable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PembelianItem extends Model
{
    use Auditable;
    use HasFactory;

    public $table = 'tb_pembelian_item';

    public $timestamps = false;

    protected $fillable = [
        'pembelian_id',
        'category_id',
        'stock_id',
        'no',
        'jenis_emas',
        'nama_barang',
        'berat',
        'kadar',
        'harga_pergram',
        'harga_sekarang',
        'potongan',
        'total',
        'images',
        'varian'
    ];

    protected function serializeDate(DateTimeInterface $date)
    {
        return $date->format('Y-m-d H:i:s');
    }
}
