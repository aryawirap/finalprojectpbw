<?php

namespace App\Models;

use \DateTimeInterface;
use App\Traits\Auditable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PemesananItem extends Model
{
    use Auditable;
    use HasFactory;

    public $table = 'tb_pemesanan_item';

    public $timestamps = false;

    protected $fillable = [
        'pemesanan_id',
        'category_id',
        'stock_id',
        'no',
        'jenis_emas',
        'nama_barang',
        'berat',
        'kadar',
        'harga_pergram',
        'ongkos',
        'total',
        'payment',
        'selesai_pesanan',
        'images',
        'varian',
    ];

    protected function serializeDate(DateTimeInterface $date)
    {
        return $date->format('Y-m-d H:i:s');
    }
}
