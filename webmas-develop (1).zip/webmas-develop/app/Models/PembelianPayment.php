<?php

namespace App\Models;

use \DateTimeInterface;
use App\Traits\Auditable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PembelianPayment extends Model
{
    use Auditable;
    use HasFactory;

    public $table = 'tb_pembelian_payment';

    protected $fillable = [
        'id_pembelian',
        'type',
        'value',
        'kembalian',
    ];

    public function pembelians()
    {
        return $this->belongsToMany(Pembelian::class);
    }
    
    public function types()
    {
        return $this->belongsToMany(MetodePembayaran::class);
    }

    protected function serializeDate(DateTimeInterface $date)
    {
        return $date->format('Y-m-d H:i:s');
    }
}
