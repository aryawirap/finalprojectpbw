<?php

namespace App\Models;

use App\Traits\Auditable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
class Pelunasan extends Model
{
    use Auditable;
    use HasFactory;

    public $table = 'tb_pelunasan';

    protected $dates = [
        'created_at',
        'updated_at',
    ];

    protected $fillable = [
        'id',
        'pemesanan_id',
        'barkode',
        'tanggal_pelunasan',
        'sisa_pelunasan',
        "noTrx",
        "totalKuitansi",
        "customer_id",
        "grandTotal",
        "status",
        "type",
        "payment_type",
        "from",
        "note",
        "pdfPath"
    ];

    public function pemesanan()
    {
        return $this->belongsTo(Pemesanan::class);
    }

    public function metodePembayarans()
    {
        return $this->belongsToMany(MetodePembayaran::class)->withPivot("amount");
    }

    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }

    public function penjualanItems()
    {
        return $this->hasMany(PenjualanItem::class);
    }

    public function comments()
    {
        return $this->morphMany(UpdatedDataReason::class, 'commentable');
    }

    public function pelunasanItems()
    {
        return $this->hasMany(PelunasanItem::class);
    }
}
