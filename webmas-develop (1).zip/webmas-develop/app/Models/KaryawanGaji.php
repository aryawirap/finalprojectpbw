<?php

namespace App\Models;

use App\Traits\Auditable;
use Illuminate\Database\Eloquent\Model;

class KaryawanGaji extends Model
{
    use Auditable;
    public $table = 'karyawan_gajis';
    protected $fillable = [
        'karyawan_id',
        'gaji',
        'potongan',
        'tanggalGajian',
        'totalGaji'
    ];

    public function detailGaji()
    {
        return $this->hasMany(karyawanGajiDetail::class);
    }

    public function karyawan()
    {
        return $this->belongsTo(Karyawan::class);
    }

    public function berangkas()
    {
        return $this->hasMany(Berangkas::class,"model_id","id");
    }
}