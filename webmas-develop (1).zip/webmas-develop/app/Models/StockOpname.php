<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class StockOpname extends Model
{
    use SoftDeletes;

    public $table = 'stock_opnames';
    protected $fillable = [
        "stock_id",
        "tanggal",
        "stock_awal",
        "status",
    ];

    public function stockOpnameDetail()
    {
        return $this->hasMany(StockOpnameDetail::class);
    }

    public function stock()
    {
        return $this->belongsTo(Stock::class);
    }
}