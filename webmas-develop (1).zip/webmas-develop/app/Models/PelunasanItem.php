<?php

namespace App\Models;

use App\Traits\Auditable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PelunasanItem extends Model
{
    use Auditable;
    use HasFactory;

    public $table = 'tb_pelunasan_item';

    protected $fillable = [
        "noKuitansi",
        "jenisEmas",
        "namaBarang",
        "berat",
        "kadar",
        "hargaPerGram",
        "ongkos",
        "total",
        "image",
        "pelunasan_id",
        "category_id",
        "varian",
    ];
}
