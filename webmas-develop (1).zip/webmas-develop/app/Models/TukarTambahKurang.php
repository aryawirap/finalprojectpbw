<?php

namespace App\Models;

use App\Traits\Auditable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Casts\Attribute;

class TukarTambahKurang extends Model
{
    use Auditable;
    use HasFactory;

    public $table = 'tukar_tambah_kurangs';

    protected $dates = [
        'created_at',
        'updated_at',
    ];

    protected $casts = [
      "tanggalPenjualan" => "datetime"
    ];

    protected $fillable = [
        'noTrx',
        'customer_id',
        'total_kuitansi',
        'grand_total',
        'status',
        'from',
        'nota',
        'note',
        'type',
        'totalPay',
        'payment_type',
        'pdfPath',
        'tanggalPenjualan'
    ];

    public function scopeGetTukarTambah($query)
    {
        return $query->where('type', 1);
    }

    public function scopeGetTukarKurang($query)
    {
        return $query->where('type', 2);
    }

    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }

    public function tukarTambahKurangItems()
    {
        return $this->hasMany(TukarTambahKurangItem::class);
    }

    public function comments()
    {
        return $this->morphMany(UpdatedDataReason::class, 'commentable');
    }

    public function metodePembayarans()
    {
        return $this->belongsToMany(MetodePembayaran::class, "metode_pembayaran_tukarTambahKurang")->withPivot("amount", "return");
    }
}
