<?php

namespace App\Models;

use App\Traits\Auditable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\MetodePembayaran;
class Pembelian extends Model
{
    use Auditable;
    use HasFactory;

    public $table = 'tb_pembelian';

    protected $dates = [
        'created_at',
        'updated_at',
    ];

    protected $fillable = [
        'noTrx',
        'customer_id',
        'total_kuitansi',
        'grand_total',
        'status',
        'from',
        'nota',
        'note',
        'type',
        'payment_type',
        'created_at',
        'updated_at',
        "pdfPath"
    ];

    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }

    public function pembelianItems()
    {
        return $this->hasMany(PembelianItem::class);
    }

    public function comments()
    {
        return $this->morphMany(UpdatedDataReason::class, 'commentable');
    }

    public function metodePembayarans()
    {
        return $this->belongsToMany(MetodePembayaran::class)->withPivot("amount");
    }
}
