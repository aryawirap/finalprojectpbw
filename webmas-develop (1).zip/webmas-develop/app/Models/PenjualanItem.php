<?php

namespace App\Models;

use App\Traits\Auditable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PenjualanItem extends Model
{
    use Auditable;
    use HasFactory;
    protected $fillable = [
        "noKuitansi",
        "jenisEmas",
        "namaBarang",
        "berat",
        "kadar",
        "hargaPerGram",
        "ongkos",
        "total",
        "image",

        "penjualan_id",
        "category_id",
        "stock_id",
        "varian",
    ];
}
