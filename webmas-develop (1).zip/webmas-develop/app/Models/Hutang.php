<?php

namespace App\Models;

use \DateTimeInterface;
use App\Traits\Auditable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Hutang extends Model
{
    use Auditable;
    use HasFactory;

    public const JENIS_HUTANG_SELECT = [
        '1' => 'Cicilan',
        '2' => 'Kas bon',
    ];

    public $table = 'hutangs';

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected $fillable = [
        'karyawan_id',
        'jenis_hutang',
        'jenis_barang_id',
        'jumlah_hutang',
        'nominal_cicilan',
        'lama_cicilan',
        'sudahDibayar',
        'status',
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    public function karyawan()
    {
        return $this->belongsTo(Karyawan::class, 'karyawan_id');
    }

    public function jenis_barang()
    {
        return $this->belongsTo(JenisBarangHutang::class, 'jenis_barang_id');
    }

    protected function serializeDate(DateTimeInterface $date)
    {
        return $date->format('Y-m-d H:i:s');
    }
}
