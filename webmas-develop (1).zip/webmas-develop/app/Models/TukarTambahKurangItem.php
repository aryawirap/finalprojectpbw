<?php

namespace App\Models;

use App\Traits\Auditable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TukarTambahKurangItem extends Model
{
    use Auditable;
    use HasFactory;
    public $table = 'tukar_tambah_kurang_items';

    protected $fillable = [
        "noKuitansi",
        "jenisEmas",
        "namaBarang",
        "berat",
        "kadar",
        "hargaPerGram",
        "hargaPerGramBaru",
        "potongan",
        "total",
        "image",
        "type",
        "totalPay",

        "tukar_tambah_kurang_id",
        "category_id",
        "stock_id",
        "varian",
    ];

    public function tukarTambahInvoice()
    {
        return $this->belongsTo(TukarTambahKurang::class,"tukar_tambah_kurang_id","id");
    }
}