<?php

namespace App\Http\Controllers;

use App\Models\StockOpnameDetail;
use Illuminate\Http\Request;

class StockOpnameDetailsController extends Controller
{
    public function index()
    {

    }

    public function create()
    {
    }

    public function store(Request $request)
    {
    }

    public function show(StockOpnameDetail $stockOpnameDetail)
    {
    }

    public function edit(StockOpnameDetail $stockOpnameDetail)
    {
    }

    public function update(Request $request, StockOpnameDetail $stockOpnameDetail)
    {
    }

    public function destroy(StockOpnameDetail $stockOpnameDetail)
    {
    }
}