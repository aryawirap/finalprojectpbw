<?php

namespace App\Http\Controllers\Traits;

use Illuminate\Http\Request;

trait CurrencyTrait
{
    public function decodeCurrency($value)
    {
        $checkHasSpace = strpos($value," ");
        $formatted = str_replace([".","Rp"],"" ,$value);
        if ($checkHasSpace === false){ // ini untuk create
            return substr($formatted,2, strlen($formatted));
        }else{ // biasanya untuk edit
            return substr($formatted,1, strlen($formatted));
        }
    }

    public function encodeCurrency($value)
    {
        return 'Rp '. number_format($value,0, '.', '.');
    }
}
