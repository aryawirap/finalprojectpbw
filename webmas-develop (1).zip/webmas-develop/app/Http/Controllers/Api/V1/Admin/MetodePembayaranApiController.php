<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\MediaUploadingTrait;
use App\Http\Requests\StoreMetodePembayaranRequest;
use App\Http\Requests\UpdateMetodePembayaranRequest;
use App\Http\Resources\Admin\MetodePembayaranResource;
use App\Models\MetodePembayaran;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class MetodePembayaranApiController extends Controller
{
    use MediaUploadingTrait;

    public function index()
    {
        abort_if(Gate::denies('metode_pembayaran_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return new MetodePembayaranResource(MetodePembayaran::all());
    }

    public function store(StoreMetodePembayaranRequest $request)
    {
        $metodePembayaran = MetodePembayaran::create($request->all());

        if ($request->input('logo', false)) {
            $metodePembayaran->addMedia(storage_path('tmp/uploads/' . basename($request->input('logo'))))->toMediaCollection('logo');
        }

        return (new MetodePembayaranResource($metodePembayaran))
            ->response()
            ->setStatusCode(Response::HTTP_CREATED);
    }

    public function show(MetodePembayaran $metodePembayaran)
    {
        abort_if(Gate::denies('metode_pembayaran_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return new MetodePembayaranResource($metodePembayaran);
    }

    public function update(UpdateMetodePembayaranRequest $request, MetodePembayaran $metodePembayaran)
    {
        $metodePembayaran->update($request->all());

        if ($request->input('logo', false)) {
            if (!$metodePembayaran->logo || $request->input('logo') !== $metodePembayaran->logo->file_name) {
                if ($metodePembayaran->logo) {
                    $metodePembayaran->logo->delete();
                }
                $metodePembayaran->addMedia(storage_path('tmp/uploads/' . basename($request->input('logo'))))->toMediaCollection('logo');
            }
        } elseif ($metodePembayaran->logo) {
            $metodePembayaran->logo->delete();
        }

        return (new MetodePembayaranResource($metodePembayaran))
            ->response()
            ->setStatusCode(Response::HTTP_ACCEPTED);
    }

    public function destroy(MetodePembayaran $metodePembayaran)
    {
        abort_if(Gate::denies('metode_pembayaran_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $metodePembayaran->delete();

        return response(null, Response::HTTP_NO_CONTENT);
    }
}
