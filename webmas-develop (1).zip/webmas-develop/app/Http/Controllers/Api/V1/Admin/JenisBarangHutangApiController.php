<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreJenisBarangHutangRequest;
use App\Http\Requests\UpdateJenisBarangHutangRequest;
use App\Http\Resources\Admin\JenisBarangHutangResource;
use App\Models\JenisBarangHutang;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class JenisBarangHutangApiController extends Controller
{
    public function index()
    {
        abort_if(Gate::denies('jenis_barang_hutang_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return new JenisBarangHutangResource(JenisBarangHutang::all());
    }

    public function store(StoreJenisBarangHutangRequest $request)
    {
        $jenisBarangHutang = JenisBarangHutang::create($request->all());

        return (new JenisBarangHutangResource($jenisBarangHutang))
            ->response()
            ->setStatusCode(Response::HTTP_CREATED);
    }

    public function show(JenisBarangHutang $jenisBarangHutang)
    {
        abort_if(Gate::denies('jenis_barang_hutang_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return new JenisBarangHutangResource($jenisBarangHutang);
    }

    public function update(UpdateJenisBarangHutangRequest $request, JenisBarangHutang $jenisBarangHutang)
    {
        $jenisBarangHutang->update($request->all());

        return (new JenisBarangHutangResource($jenisBarangHutang))
            ->response()
            ->setStatusCode(Response::HTTP_ACCEPTED);
    }

    public function destroy(JenisBarangHutang $jenisBarangHutang)
    {
        abort_if(Gate::denies('jenis_barang_hutang_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $jenisBarangHutang->delete();

        return response(null, Response::HTTP_NO_CONTENT);
    }
}
