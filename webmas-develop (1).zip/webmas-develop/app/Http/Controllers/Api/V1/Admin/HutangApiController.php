<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreHutangRequest;
use App\Http\Requests\UpdateHutangRequest;
use App\Http\Resources\Admin\HutangResource;
use App\Models\Hutang;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class HutangApiController extends Controller
{
    public function index()
    {
        abort_if(Gate::denies('hutang_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return new HutangResource(Hutang::with(['user', 'jenis_barang'])->get());
    }

    public function store(StoreHutangRequest $request)
    {
        $hutang = Hutang::create($request->all());

        return (new HutangResource($hutang))
            ->response()
            ->setStatusCode(Response::HTTP_CREATED);
    }

    public function show(Hutang $hutang)
    {
        abort_if(Gate::denies('hutang_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return new HutangResource($hutang->load(['user', 'jenis_barang']));
    }

    public function update(UpdateHutangRequest $request, Hutang $hutang)
    {
        $hutang->update($request->all());

        return (new HutangResource($hutang))
            ->response()
            ->setStatusCode(Response::HTTP_ACCEPTED);
    }

    public function destroy(Hutang $hutang)
    {
        abort_if(Gate::denies('hutang_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $hutang->delete();

        return response(null, Response::HTTP_NO_CONTENT);
    }
}
