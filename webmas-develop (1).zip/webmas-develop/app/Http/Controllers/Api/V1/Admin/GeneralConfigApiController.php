<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreGeneralConfigRequest;
use App\Http\Requests\UpdateGeneralConfigRequest;
use App\Http\Resources\Admin\GeneralConfigResource;
use App\Models\GeneralConfig;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class GeneralConfigApiController extends Controller
{
    public function index()
    {
        abort_if(Gate::denies('general_config_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return new GeneralConfigResource(GeneralConfig::all());
    }

    public function store(StoreGeneralConfigRequest $request)
    {
        $generalConfig = GeneralConfig::create($request->all());

        return (new GeneralConfigResource($generalConfig))
            ->response()
            ->setStatusCode(Response::HTTP_CREATED);
    }

    public function show(GeneralConfig $generalConfig)
    {
        abort_if(Gate::denies('general_config_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return new GeneralConfigResource($generalConfig);
    }

    public function update(UpdateGeneralConfigRequest $request, GeneralConfig $generalConfig)
    {
        $generalConfig->update($request->all());

        return (new GeneralConfigResource($generalConfig))
            ->response()
            ->setStatusCode(Response::HTTP_ACCEPTED);
    }

    public function destroy(GeneralConfig $generalConfig)
    {
        abort_if(Gate::denies('general_config_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $generalConfig->delete();

        return response(null, Response::HTTP_NO_CONTENT);
    }
}
