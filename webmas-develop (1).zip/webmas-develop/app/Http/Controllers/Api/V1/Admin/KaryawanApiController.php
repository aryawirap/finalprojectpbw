<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\MediaUploadingTrait;
use App\Http\Requests\StoreKaryawanRequest;
use App\Http\Requests\UpdateKaryawanRequest;
use App\Http\Resources\Admin\KaryawanResource;
use App\Models\Karyawan;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class KaryawanApiController extends Controller
{
    use MediaUploadingTrait;

    public function index()
    {
        abort_if(Gate::denies('karyawan_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return new KaryawanResource(Karyawan::with(['user'])->get());
    }

    public function store(StoreKaryawanRequest $request)
    {
        $karyawan = Karyawan::create($request->all());

        return (new KaryawanResource($karyawan))
            ->response()
            ->setStatusCode(Response::HTTP_CREATED);
    }

    public function show(Karyawan $karyawan)
    {
        abort_if(Gate::denies('karyawan_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return new KaryawanResource($karyawan->load(['user']));
    }

    public function update(UpdateKaryawanRequest $request, Karyawan $karyawan)
    {
        $karyawan->update($request->all());

        return (new KaryawanResource($karyawan))
            ->response()
            ->setStatusCode(Response::HTTP_ACCEPTED);
    }

    public function destroy(Karyawan $karyawan)
    {
        abort_if(Gate::denies('karyawan_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $karyawan->delete();

        return response(null, Response::HTTP_NO_CONTENT);
    }
}
