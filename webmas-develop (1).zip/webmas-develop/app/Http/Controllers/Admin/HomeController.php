<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Traits\CurrencyTrait;
use App\Models\Pelunasan;
use App\Models\Pembelian;
use App\Models\Pemesanan;
use App\Models\Penjualan;
use App\Models\TukarTambahKurang;
use Illuminate\Http\Request;

class HomeController
{
    public function index(Request $request)
    {
        if ($request->ajax()) { // summary filter by date range
            $summaryPenjualan = Penjualan::whereBetween("created_at", [$request->get('from') ." 00:00:00", $request->get('to')." 23:59:59"])->sum('grandTotal');
            $summaryPembelian = Pembelian::whereBetween("created_at", [$request->get('from') ." 00:00:00", $request->get('to')." 23:59:59"])->sum('grand_total');
            $summaryPemesanan = Pemesanan::whereBetween("created_at", [$request->get('from') ." 00:00:00", $request->get('to')." 23:59:59"])->sum('grand_total');
            $summaryPelunasan = Pelunasan::whereBetween("created_at", [$request->get('from') ." 00:00:00", $request->get('to')." 23:59:59"])->sum('grandTotal');
            $summaryTukarTambahKurang = TukarTambahKurang::whereBetween("created_at", [$request->get('from') ." 00:00:00", $request->get('to')." 23:59:59"])->sum('grand_total');
            return response()->json(['summaryPenjualan' => encodeCurrency($summaryPenjualan), 'summaryPembelian' => encodeCurrency($summaryPembelian), 'summaryPemesanan' => encodeCurrency($summaryPemesanan), 'summaryTukarTambahKurang' => encodeCurrency($summaryTukarTambahKurang), 'summaryPelunasan' => encodeCurrency($summaryPelunasan)]);
        }else{ // summary harian
            $summaryPenjualan = Penjualan::whereBetween("created_at", [date('Y-m-d') ." 00:00:00", date('Y-m-d')." 23:59:59"])->sum('grandTotal');
            $summaryPembelian = Pembelian::whereBetween("created_at", [date('Y-m-d') ." 00:00:00", date('Y-m-d')." 23:59:59"])->sum('grand_total');
            $summaryPemesanan = Pemesanan::whereBetween("created_at", [date('Y-m-d') ." 00:00:00", date('Y-m-d')." 23:59:59"])->sum('grand_total');
            $summaryPelunasan = Pelunasan::whereBetween("created_at", [date('Y-m-d') ." 00:00:00", date('Y-m-d')." 23:59:59"])->sum('grandTotal');
            $summaryTukarTambahKurang = TukarTambahKurang::whereBetween("created_at", [date('Y-m-d') ." 00:00:00", date('Y-m-d')." 23:59:59"])->sum('grand_total');
        }
        return view('home', compact('summaryPenjualan','summaryPembelian', 'summaryPemesanan', 'summaryTukarTambahKurang', 'summaryPelunasan'));
    }
}
