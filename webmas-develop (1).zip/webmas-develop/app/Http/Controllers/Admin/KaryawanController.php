<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\MediaUploadingTrait;
use App\Http\Requests\MassDestroyKaryawanRequest;
use App\Http\Requests\StoreKaryawanRequest;
use App\Http\Requests\UpdateKaryawanRequest;
use App\Models\Karyawan;
use App\Models\User;
use Gate;
use Illuminate\Http\Request;
use Spatie\MediaLibrary\MediaCollections\Models\Media;
use Symfony\Component\HttpFoundation\Response;
use Yajra\DataTables\Facades\DataTables;

class KaryawanController extends Controller
{
    use MediaUploadingTrait;

    public function index(Request $request)
    {
        abort_if(Gate::denies('karyawan_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        if ($request->ajax()) {
            $query = Karyawan::select(sprintf('%s.*', (new Karyawan())->table));
            $table = Datatables::of($query);

            $table->addColumn('placeholder', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');

            $table->editColumn('actions', function ($row) {
                $viewGate = 'karyawan_show';
                $editGate = 'karyawan_edit';
                $deleteGate = 'karyawan_delete';
                $crudRoutePart = 'karyawans';

                return view('partials.datatablesActions', compact(
                'viewGate',
                'editGate',
                'deleteGate',
                'crudRoutePart',
                'row'
            ));
            });

            $table->editColumn('id', function ($row) {
                return $row->id ? $row->id : '';
            });
            $table->addColumn('name', function ($row) {
                return $row->name ? $row->name : '';
            });

            $table->filterColumn('name', function($query, $keyword) {
                $sql = "name like ?";
                $query->whereRaw($sql, ["%{$keyword}%"]);
            });

            $table->editColumn('email', function ($row) {
                return $row->email ? $row->email : '';
            });
            $table->editColumn('bagian', function ($row) {
                return $row->bagian ? $row->bagian : '';
            });
            $table->editColumn('gaji', function ($row) {
                return $row->gaji ? encodeCurrency($row->gaji) : '';
            });

            $table->rawColumns(['actions', 'placeholder']);

            return $table->make(true);
        }

        return view('admin.karyawans.index');
    }

    public function create()
    {
        abort_if(Gate::denies('karyawan_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        return view('admin.karyawans.create');
    }

    public function store(StoreKaryawanRequest $request)
    {
        $data = $request->all();
        $data['gaji'] = decodeCurrency($request->validated()['gaji']);
        $karyawan = Karyawan::create($data);

        if ($media = $request->input('ck-media', false)) {
            Media::whereIn('id', $media)->update(['model_id' => $karyawan->id]);
        }

        return redirect()->route('admin.karyawans.index');
    }

    public function edit(Karyawan $karyawan)
    {
        abort_if(Gate::denies('karyawan_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        return view('admin.karyawans.edit', compact('karyawan'));
    }

    public function update(UpdateKaryawanRequest $request, Karyawan $karyawan)
    {
        $data = $request->all();
        $data['gaji'] = decodeCurrency($request->validated()['gaji']);
        $karyawan->update($data);

        return redirect()->route('admin.karyawans.index');
    }

    public function show(Karyawan $karyawan)
    {
        abort_if(Gate::denies('karyawan_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        return view('admin.karyawans.show', compact('karyawan'));
    }

    public function destroy(Karyawan $karyawan)
    {
        abort_if(Gate::denies('karyawan_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $karyawan->delete();

        return back();
    }

    public function massDestroy(MassDestroyKaryawanRequest $request)
    {
        Karyawan::whereIn('id', request('ids'))->delete();

        return response(null, Response::HTTP_NO_CONTENT);
    }

    public function storeCKEditorImages(Request $request)
    {
        abort_if(Gate::denies('karyawan_create') && Gate::denies('karyawan_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $model         = new Karyawan();
        $model->id     = $request->input('crud_id', 0);
        $model->exists = true;
        $media         = $model->addMediaFromRequest('upload')->toMediaCollection('ck-media');

        return response()->json(['id' => $media->id, 'url' => $media->getUrl()], Response::HTTP_CREATED);
    }
}
