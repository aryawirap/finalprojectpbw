<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\MassDestroyPemesananRequest;
use App\Models\MetodePembayaran;
use App\Models\Pemesanan;
use Haruncpi\LaravelIdGenerator\IdGenerator;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Symfony\Component\HttpFoundation\Response;
use Yajra\DataTables\Facades\DataTables;
use Gate;
use App\Http\Requests\StorePemesananRequest;
use App\Http\Requests\UpdatePemesananRequest;
use Barryvdh\DomPDF\Facade\Pdf;

class PemesananController extends Controller
{
    private function toDateEntity($date)
    {
        return \Carbon\Carbon::createFromFormat("d-m-Y",$date)->format("Y-m-d");
    }

    public function index(Request $request)
    {
        abort_if(Gate::denies('pemesanan_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        if ($request->ajax()) {
            $query = Pemesanan::with("customer")->select(sprintf('%s.*', (new Pemesanan())->table));
            $query->when($request->get('from') !== null && $request->get('to') !== null, function ($q){
                return $q->whereBetween('created_at', [$this->toDateEntity(request()->get('from')) ." 00:00:00", $this->toDateEntity(request()->get('to'))." 23:59:59"]);
            });
            $table = Datatables::of($query);
            
            $table->addColumn('placeholder', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');
            
            $table->editColumn('actions', function ($row) {
                $editGate = 'pemesanan_edit';
                $deleteGate = 'pemesanan_delete';
                $invoiceGate = 'pemesanan_invoice';
                $crudRoutePart = 'pemesanan';
                
                return view('partials.datatablesActionWithoutShow', compact(
                    'editGate',
                    'deleteGate',
                    'invoiceGate',
                    'crudRoutePart',
                    'row'
                ));
            });
            
            $table->editColumn('id', function ($row) {
                return $row->id ? $row->id : '';
            });
            $table->editColumn('noTrx', function ($row) {
                return $row->noTrx ? $row->noTrx : '';
            });
            $table->editColumn('customer_id', function ($row) {
                return $row->customer ? $row->customer->nama : '';
            });
            $table->editColumn('total_kuitansi', function ($row) {
                return $row->total_kuitansi ? $row->total_kuitansi : '';
            });
            $table->editColumn('grand_total', function ($row) {
                return $row->grand_total ? encodeCurrency($row->grand_total) : '';
            });

            $table->editColumn('created_at', function ($row) {
                 return $row->created_at ? $row->created_at : '';
             });
            // $table->editColumn('from', function ($row) {
            //     return $row->from ? $row->from : '';
            // });
            $table->editColumn('nota', function ($row) {
                return $row->nota ? $row->nota : '';
            });
            $table->rawColumns(['actions', 'placeholder']);
            return $table->make(true);
        }

        $metode_pembayarans = MetodePembayaran::get();

        return view('admin.order.index', compact('metode_pembayarans'));
    }

    public function invoice(Pemesanan $pemesanan)
    {
        $pdf = Pdf::setPaper("folio")->loadView('exports.manual.pemesanan', compact("pemesanan"));
        $name = time() . "-invoice.pdf";
        if ($pemesanan->pdfPath !== null){
            unlink(public_path($pemesanan->pdfPath));
        }
        $pdf->save("invoices/".$name);
        $pemesanan->update([
            'pdfPath' => "invoices/".$name
        ]);
        return view("exports.preview",['invoice' => $pemesanan,'path' => 'pemesanan']);
    }

    public function create()
    {
        abort_if(Gate::denies('pemesanan_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('admin.order.create');
    }

    public function store(StorePemesananRequest $request)
    {
        $sale = Pemesanan::create($request->all());
        $id = IdGenerator::generate(['table' => 'todos', 'length' => 6, 'prefix' => date('Y-m-d')]);
        $sale->metode_pembayarans()->sync($request->input('metode_pembayarans', []));

        return redirect()->route('admin.order.index');
    }

    public function edit(Pemesanan $pemesanan)
    {
        abort_if(Gate::denies('pemesanan_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $metode_pembayarans = MetodePembayaran::pluck('nama_metode', 'id');
        $pemesanan->load("customer", "pemesananItems");

        return view('admin.order.edit', compact('metode_pembayarans', 'pemesanan'));
    }

    public function update(UpdatePemesananRequest $request, Pemesanan $pemesanan)
    {
        $pemesanan->update($request->all());
        $pemesanan->metode_pembayarans()->sync($request->input('metode_pembayarans', []));

        return redirect()->route('admin.order.index');
    }

    public function show(Pemesanan $pemesanan)
    {
        abort_if(Gate::denies('pemesanan_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $pemesanan->load('metode_pembayarans');

        return view('admin.order.show', compact('pemesanan'));
    }

    public function destroy(Pemesanan $pemesanan)
    {
        abort_if(Gate::denies('pemesanan_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $pemesanan->delete();

        return back();
    }

    public function massDestroy(MassDestroyPemesananRequest $request)
    {
        Pemesanan::whereIn('id', request('ids'))->delete();

        return response(null, Response::HTTP_NO_CONTENT);
    }
}
