<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\CurrencyTrait;
use App\Http\Requests\MassDestroyHutangRequest;
use App\Http\Requests\StoreHutangRequest;
use App\Http\Requests\UpdateHutangRequest;
use App\Models\Hutang;
use App\Models\JenisBarangHutang;
use App\Models\Karyawan;
use App\Models\User;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Yajra\DataTables\Facades\DataTables;

class HutangController extends Controller
{
    use CurrencyTrait;
    public function index(Request $request)
    {
        abort_if(Gate::denies('hutang_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        if ($request->ajax()) {
            $query = Hutang::with(['karyawan', 'jenis_barang'])->select(sprintf('%s.*', (new Hutang())->table));
            $table = Datatables::of($query);

            $table->addColumn('placeholder', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');

            $table->editColumn('actions', function ($row) {
                $viewGate = 'hutang_show';
                $editGate = 'hutang_edit';
                $deleteGate = 'hutang_delete';
                $crudRoutePart = 'hutangs';

                return view('partials.datatablesActions', compact(
                'viewGate',
                'editGate',
                'deleteGate',
                'crudRoutePart',
                'row'
            ));
            });

            $table->editColumn('id', function ($row) {
                return $row->id ? $row->id : '';
            });
            $table->addColumn('karyawan_name', function ($row) {
                return $row->karyawan ? $row->karyawan->name : '';
            });

            $table->editColumn('jenis_hutang', function ($row) {
                return $row->jenis_hutang ? Hutang::JENIS_HUTANG_SELECT[$row->jenis_hutang] : '';
            });
            $table->addColumn('jenis_barang_jenis', function ($row) {
                return $row->jenis_barang ? $row->jenis_barang->jenis : '';
            });

            $table->editColumn('jumlah_hutang', function ($row) {
                return $row->jumlah_hutang ? $this->encodeCurrency($row->jumlah_hutang) : '';
            });
            $table->editColumn('nominal_cicilan', function ($row) {
                return $row->nominal_cicilan ? $this->encodeCurrency($row->nominal_cicilan) : '';
            });
            $table->editColumn('lama_cicilan', function ($row) {
                return $row->lama_cicilan ? $row->lama_cicilan : '';
            });

            $table->rawColumns(['actions', 'placeholder', 'jenis_barang']);

            return $table->make(true);
        }

        $karyawans                = Karyawan::get();
        $jenis_barang_hutangs = JenisBarangHutang::get();

        return view('admin.hutangs.index', compact('karyawans', 'jenis_barang_hutangs'));
    }

    public function create()
    {
        abort_if(Gate::denies('hutang_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $karyawans = Karyawan::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $jenis_barangs = JenisBarangHutang::pluck('jenis', 'id')->prepend(trans('global.pleaseSelect'), '');

        return view('admin.hutangs.create', compact('jenis_barangs', 'karyawans'));
    }

    public function store(StoreHutangRequest $request)
    {
        $data = $request->validated();
        $data["nominal_cicilan"] = $this->decodeCurrency($data["nominal_cicilan"]);
        $data["jumlah_hutang"] = $this->decodeCurrency($data["jumlah_hutang"]);

        if(isset($data["jenis_barang"]) !== false){
            $tempJenisHutang = JenisBarangHutang::create(['jenis' => $request->validated("jenis_barang")]);
            $data["jenis_barang_id"] = $tempJenisHutang->id;
        }
        $hutang = Hutang::create($data);

        return redirect()->route('admin.hutangs.index');
    }

    public function edit(Hutang $hutang)
    {
        abort_if(Gate::denies('hutang_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $karyawans = Karyawan::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $jenis_barangs = JenisBarangHutang::pluck('jenis', 'id')->prepend(trans('global.pleaseSelect'), '');

        $hutang->load('karyawan', 'jenis_barang');

        return view('admin.hutangs.edit', compact('hutang', 'jenis_barangs', 'karyawans'));
    }

    public function update(UpdateHutangRequest $request, Hutang $hutang)
    {
        $data = $request->validated();
        $data["nominal_cicilan"] = $this->decodeCurrency($data["nominal_cicilan"]);
        $data["jumlah_hutang"] = $this->decodeCurrency($data["jumlah_hutang"]);

        $hutang->update($data);

        return redirect()->route('admin.hutangs.index');
    }

    public function show(Hutang $hutang)
    {
        abort_if(Gate::denies('hutang_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $hutang->load('karyawan', 'jenis_barang');

        return view('admin.hutangs.show', compact('hutang'));
    }

    public function destroy(Hutang $hutang)
    {
        abort_if(Gate::denies('hutang_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $hutang->delete();

        return back();
    }

    public function massDestroy(MassDestroyHutangRequest $request)
    {
        Hutang::whereIn('id', request('ids'))->delete();

        return response(null, Response::HTTP_NO_CONTENT);
    }
}
