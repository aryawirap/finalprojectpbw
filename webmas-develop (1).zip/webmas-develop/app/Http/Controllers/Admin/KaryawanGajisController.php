<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Hutang;
use App\Models\KaryawanGaji;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Symfony\Component\HttpFoundation\Response;
use Yajra\DataTables\Facades\DataTables;

class KaryawanGajisController extends Controller
{
    public function index(Request $request)
    {
        abort_if(Gate::denies('gaji_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        if ($request->ajax()) {
            $query = KaryawanGaji::with("karyawan")->select(sprintf('%s.*', (new KaryawanGaji())->table));
            $table = DataTables::of($query);
            $table->addColumn('placeholder', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');

            $table->editColumn('actions', function ($row) {
                $viewGate = 'xx_gaji_show'; // jgn ada show
                $editGate = 'gaji_edit';
                $deleteGate = 'gaji_delete';
                $crudRoutePart = 'gaji';

                return view('partials.datatablesActions', compact(
                    'viewGate',
                    'editGate',
                    'deleteGate',
                    'crudRoutePart',
                    'row'
                ));
            });

            $table->editColumn('id', function ($row) {
                return $row->id ? $row->id : '';
            });

            $table->addColumn('karyawan', function (KaryawanGaji $gaji) {
                return $gaji->karyawan ? $gaji->karyawan->name : '';
            });

            $table->editColumn('tanggalGajian', function ($row) {
                return $row->tanggalGajian ? $row->tanggalGajian : '';
            });

            $table->editColumn('gaji', function ($row) {
                return $row->gaji ? encodeCurrency($row->gaji) : encodeCurrency(0);
            });

            $table->editColumn('potongan', function ($row) {
                return $row->potongan ? encodeCurrency($row->potongan) : encodeCurrency(0);
            });

            $table->editColumn('totalGaji', function ($row) {
                return $row->totalGaji ? encodeCurrency($row->totalGaji) : encodeCurrency(0);
            });


            $table->rawColumns(['actions', 'placeholder']);

            return $table->make(true);
        }

        return view("admin.gaji.index");
    }

    public function create()
    {
        return view("admin.gaji.create");
    }

    public function edit(KaryawanGaji $gaji)
    {
        $gaji->load('detailGaji');
        return view("admin.gaji.edit",compact("gaji"));
    }

    public function update(Request $request, KaryawanGaji $karyawanGaji)
    {
    }

    public function destroy(KaryawanGaji $gaji)
    {
        $data = $gaji->load("detailGaji","berangkas");
        foreach ($data->detailGaji as $item){
            $hutang = Hutang::findOrFail($item->hutang_id);
            $hutang->update(['lama_cicilan' => DB::raw('lama_cicilan + 1'), "sudahDibayar" => DB::raw("sudahDibayar - $item->nominal"), 'status' => 1]);
        }
        $gaji->berangkas()->delete();
        $gaji->delete();
        return redirect()->route("admin.gaji.index")->with("success","success delete gaji");
    }
}