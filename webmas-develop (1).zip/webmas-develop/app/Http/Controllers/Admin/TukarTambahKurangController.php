<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\MetodePembayaran;
use App\Models\Pembelian;
use App\Models\PembelianItem;
use App\Models\TukarTambahKurang;
use App\Models\TukarTambahKurangItem;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Symfony\Component\HttpFoundation\Response;
use Yajra\DataTables\Facades\DataTables;

class TukarTambahKurangController extends Controller
{
    private function toDateEntity($date)
    {
        return \Carbon\Carbon::createFromFormat("d-m-Y",$date)->format("Y-m-d");
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        abort_if(Gate::denies('tukar_tambah_kurang_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        if ($request->ajax()) {
            $query = TukarTambahKurang::with("customer")->select(sprintf('%s.*', (new TukarTambahKurang())->table));
            $query->when($request->get('from') !== null && $request->get('to') !== null, function ($q){
                return $q->whereBetween('created_at', [$this->toDateEntity(request()->get('from')) ." 00:00:00", $this->toDateEntity(request()->get('to'))." 23:59:59"]);
            });
            $table = Datatables::of($query);

            $table->addColumn('placeholder', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');

            $table->editColumn('actions', function ($row) {
                $editGate = 'tukarTambahKurang_edit';
                $deleteGate = 'tukarTambahKurang_delete';
                $crudRoutePart = 'tukarTambahKurang';
                $invoiceGate = 'tukarTambahKurang_invoice';

                return view('partials.datatablesActionWithoutShow', compact(
                    'editGate',
                    'deleteGate',
                    'invoiceGate',
                    'crudRoutePart',
                    'row'
                ));
            });

            $table->editColumn('id', function ($row) {
                return $row->id ?: '';
            });
            $table->editColumn('noTrx', function ($row) {
                return $row->noTrx ?: '';
            });
            $table->editColumn('customer_id', function ($row) {
                return $row->customer ? $row->customer->nama : '';
            });
            $table->editColumn('total_kuitansi', function ($row) {
                return $row->total_kuitansi ?: '';
            });
            $table->editColumn('totalPay', function ($row) {
                return $row->totalPay ? encodeCurrency($row->totalPay) : '';
            });
            $table->editColumn('type', function ($row) {
                return $row->type == 1 ? 'Tukar Tambah' : 'Tukar Kurang';
            });
            $table->filterColumn('type', function($query, $keyword) {
                if (strtolower($keyword) == 'Tukar Tambah'){
                    $keyword = '0';
                }else{
                    $keyword = '1';
                }
                $query->where('type', $keyword);
            });
            $table->editColumn('nota', function ($row) {
                return $row->nota ?: '';
            });
            $table->editColumn('created_at', function ($row) {
                return $row->created_at ?: '';
            });
            $table->rawColumns(['actions', 'placeholder']);
            return $table->make(true);
        }

        $tukarTambah = TukarTambahKurangItem::whereHas("tukarTambahInvoice", function($q){ // tukar tambah
            return $q->where("type",1);
        })->where("type",1)->get(['id','berat']);

        $summaryTukarTambah = $this->calculateDataSummaryTukarTambah($tukarTambah);

        $tukarKurang = TukarTambahKurangItem::whereHas("tukarTambahInvoice", function($q){ //  tukar kurang
            return $q->where("type",2);
        })->where("type",1)->get(['id','berat']);

        $summaryTukarKurang = $this->calculateDataSummaryTukarTambah($tukarKurang);

        $metode_pembayarans = MetodePembayaran::get();

        return view('admin.tukarTambahKurang.index', compact('metode_pembayarans', 'summaryTukarTambah', 'summaryTukarKurang'));
    }

    public function invoice(TukarTambahKurang $tukarTambahKurang)
    {
        $pdf = Pdf::setPaper("folio")->loadView('exports.manual.tukarTambahKurang', compact("tukarTambahKurang"));
        $name = time() . "-tukarTambahKurang-invoice.pdf";
        if ($tukarTambahKurang->pdfPath !== null){ // remove old one
            unlink(public_path($tukarTambahKurang->pdfPath));
        }
        $pdf->save("invoices/".$name); // save new one
        $tukarTambahKurang->update([ // update new pdf path
            'pdfPath' => "invoices/".$name
        ]);
        return view("exports.preview",['invoice' => $tukarTambahKurang,'path' => 'tukarTambahKurang']);
    }

    private function calculateDataSummaryTukarTambah(mixed $data)
    {
        $tmpTotalItems = 0;
        $tmpTotalKarat = 0;
        $tmpTotalBerat = 0;
        foreach ($data as $index => $row){
            $tmpTotalKarat += $row->kadar;
            $tmpTotalBerat += $row->berat;
            ++$tmpTotalItems;
        }

        return ['berat' => $tmpTotalBerat, 'karat' => $tmpTotalKarat, 'item' => $tmpTotalItems];
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        abort_if(Gate::denies('tukarTambahKurang_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        return view('admin.tukarTambahKurang.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\TukarTambahKurang  $tukarTambahKurang
     * @return \Illuminate\Http\Response
     */
    public function show(TukarTambahKurang $tukarTambahKurang)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\TukarTambahKurang  $tukarTambahKurang
     * @return \Illuminate\Http\Response
     */
    public function edit(TukarTambahKurang $tukarTambahKurang)
    {
        abort_if(Gate::denies('pembelian_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $metode_pembayarans = MetodePembayaran::pluck('nama_metode', 'id');
        $tukarTambahKurang->load("customer", "tukarTambahKurangItems");

        return view('admin.tukarTambahKurang.edit', compact('metode_pembayarans', 'tukarTambahKurang'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\TukarTambahKurang  $tukarTambahKurang
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, TukarTambahKurang $tukarTambahKurang)
    {
        //
    }

    public function massDestroy(Request $request)
    {
        abort_if(Gate::denies('tukarTambahKurang_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $request->validate([
            'ids'   => 'required|array',
            'ids.*' => 'exists:tukar_tambah_kurangs,id',
        ]);
        TukarTambahKurang::whereIn('id', request('ids'))->delete();

        return response(null, Response::HTTP_NO_CONTENT);
    }
    
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\TukarTambahKurang  $tukarTambahKurang
     * @return \Illuminate\Http\Response
     */
    public function destroy(TukarTambahKurang $tukarTambahKurang)
    {
        abort_if(Gate::denies('tukarTambahKurang_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $tukarTambahKurang->delete();

        return back();
    }
}
