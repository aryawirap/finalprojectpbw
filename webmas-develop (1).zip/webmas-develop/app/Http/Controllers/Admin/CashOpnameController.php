<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Berangkas;
use App\Models\Pelunasan;
use App\Models\Pembelian;
use App\Models\Pemesanan;
use App\Models\Penjualan;
use App\Models\TukarTambahKurang;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Barryvdh\DomPDF\Facade\Pdf;

class CashOpnameController extends Controller
{
    public function index(Request $request)
    {
        if ($request->ajax()){ // filter by date range
            $data = $this->checkerSummary($request->get('from'), $request->get('to'));

            $day = Carbon::parse($request->get('from'))->diff($request->get('to'))->days; // hitung brp hari
            $tempData = [];
            $tempReport = [];
            for ($i=0; $i < $day+1; $i++){ // make summary
                $dataHarian = $this->checkerSummary(Carbon::parse($request->get('from'))->addDays($i)->toDateString(), Carbon::parse($request->get('from'))->addDays($i)->toDateString());
                $tgl = Carbon::parse($request->get('from'))->addDays($i)->format('d-m-Y');

                $tempReport[] = [
                    'tanggal' => Carbon::parse($request->get('from'))->addDays($i)->format('d-m-Y'),
                    'summaryBerangkas' => encodeCurrency($dataHarian['summaryBerangkas']),
                    'summaryUangMasuk' => encodeCurrency($dataHarian['summaryUangMasuk']),
                    'summaryUangKeluar' => encodeCurrency($dataHarian['summaryUangKeluar'])
                ];
                array_push($tempData,
                    [
                        'name' => 'Penjualan',
                        'tanggal' => $tgl,
                        'route' => 'penjualan',
                        'amount' => encodeCurrency($dataHarian['penjualan'])
                    ],
                    [
                        'name' => 'Pembelian',
                        'tanggal' => $tgl,
                        'route' => 'pembelian',
                        'amount' => encodeCurrency($dataHarian['pembelian'])
                    ],
                    [
                        'name' => 'Pemesanan',
                        'tanggal' => $tgl,
                        'route' => 'pemesanan',
                        'amount' => encodeCurrency($dataHarian['pemesanan'])
                    ],
                    [
                        'name' => 'Pelunasan',
                        'tanggal' => $tgl,
                        'route' => 'pelunasan',
                        'amount' => encodeCurrency($dataHarian['pelunasan'])
                    ],
                    [
                        'name' => 'Tukar Tambah',
                        'tanggal' => $tgl,
                        'route' => 'tukarTambahKurang',
                        'amount' => encodeCurrency($dataHarian['tukarTambah'])
                    ],
                    [
                        'name' => 'Tukar Kurang',
                        'tanggal' => $tgl,
                        'route' => 'tukarTambahKurang',
                        'amount' => encodeCurrency($dataHarian['tukarKurang'])
                    ],
                    [
                        'name' => 'Form pengurangan',
                        'tanggal' => $tgl,
                        'route' => 'berangkas',
                        'amount' => encodeCurrency($dataHarian['pengurangan'])
                    ],
                    [
                        'name' => 'Form penambahan',
                        'tanggal' => $tgl,
                        'route' => 'berangkas',
                        'amount' => encodeCurrency($dataHarian['penambahan'])
                    ]
                );
            }

            if ($request->get('type') === 'export'){
                $pdf = Pdf::loadView('exports.cashOpname', compact('tempData','tempReport'));
                $fileName =  time().'.'. 'pdf' ;
                return $pdf->download($fileName);
            }else{
                return response()->json(['summaryBerangkas' => encodeCurrency($data['summaryBerangkas']), 'summaryUangMasuk' => encodeCurrency($data['summaryUangMasuk']), 'summaryUangKeluar' => encodeCurrency($data['summaryUangKeluar']), 'day' => $day, 'data' => $tempData]);
            }
        }else{ // harian
            $dataHarian = $this->checkerSummary(date("Y-m-d"), date("Y-m-d"));
            $tempData = [
                [
                    'name' => 'Penjualan',
                    'amount' => $dataHarian['penjualan']
                ],
                [
                    'name' => 'Pembelian',
                    'amount' => $dataHarian['pembelian']
                ],
                [
                    'name' => 'Pemesanan',
                    'amount' => $dataHarian['pemesanan']
                ],
                [
                    'name' => 'Pelunasan',
                    'amount' => $dataHarian['pelunasan']
                ],
                [
                    'name' => 'Tukar Tambah',
                    'amount' => $dataHarian['tukarTambah']
                ],
                [
                    'name' => 'Tukar Kurang',
                    'amount' => $dataHarian['tukarKurang']
                ],
                [
                    'name' => 'Form pengurangan',
                    'amount' => $dataHarian['pengurangan']
                ],
                [
                    'name' => 'Form penambahan',
                    'amount' => $dataHarian['penambahan']
                ],
            ];
        }


        return view('admin.cash-opname.index',['summaryBerangkas' => $dataHarian['summaryBerangkas'], 'summaryUangMasuk' => $dataHarian['summaryUangMasuk'], 'summaryUangKeluar' => $dataHarian['summaryUangKeluar'], 'listData' => $tempData]);
    }

    private function checkerSummary($from, $to){
        $from = $this->formatDate($from,2);
        $to = $this->formatDate($to,1);
        $formPengurangan = Berangkas::getPengurangan()->whereBetween("tanggal", [$from, $to]);
        $formPenambahan = Berangkas::getPenambahan()->whereBetween("tanggal", [$from, $to]);

        // sumary berangkas
        $penambahanBerangkas = $formPenambahan->where('type_berangkas','1')->sum('jumlah');
        $penguranganBerangkas = $formPengurangan->where('type_berangkas','1')->sum('jumlah');
        $summaryBerangkas = $penambahanBerangkas - $penguranganBerangkas;

        $summaryPenjualan = Penjualan::whereBetween("created_at", [$from, $to])->sum('grandTotal');
        $summaryPelunasan = Pelunasan::whereBetween("created_at", [$from, $to])->sum('grandTotal');
        $summaryPemesanan = Pemesanan::withTrashed()->whereBetween("created_at", [$from, $to])->sum('grand_total') - Pemesanan::withTrashed()->whereBetween("created_at", [$from, $to])->sum('sisa_pelunasan');
        $summaryTukarTambah = TukarTambahKurang::getTukarTambah()->whereBetween("created_at", [$from, $to])->sum('totalPay');
        // summary uang masuk
        $penambahanBerangkasUangMasuk = $formPenambahan->where('type_berangkas',2)->sum('jumlah');
        $penguranganBerangkasUangMasuk = $formPengurangan->where('type_berangkas',2)->sum('jumlah');
        $summaryUangMasuk = $summaryPenjualan + $summaryPemesanan + $summaryTukarTambah + $penambahanBerangkasUangMasuk + $penguranganBerangkasUangMasuk + $summaryPelunasan;

        $summaryTukarKurang = TukarTambahKurang::getTukarKurang()->whereBetween("created_at", [$from, $to])->sum('totalPay');
        $summaryPembelian = Pembelian::whereBetween("created_at", [$from ." 00:00:00", $to])->sum('grand_total');
        $penambahanBerangkasUangKeluar = $formPenambahan->where('type_berangkas',3)->sum('jumlah');
        $penguranganBerangkasUangKeluar = $formPengurangan->where('type_berangkas',3)->sum('jumlah');
        $summaryUangKeluar = $summaryTukarKurang + $summaryPembelian + $penambahanBerangkasUangKeluar + $penguranganBerangkasUangKeluar;

        return [
            'summaryBerangkas' => $summaryBerangkas,
            'summaryUangMasuk' => $summaryUangMasuk,
            'summaryUangKeluar' => $summaryUangKeluar,

            'pengurangan' => $penguranganBerangkas,
            'penambahan' => $penambahanBerangkas,
            'penjualan' => $summaryPenjualan,
            'pelunasan' => $summaryPelunasan,
            'pembelian' => $summaryPembelian,
            'pemesanan' => $summaryPemesanan,
            'tukarTambah' => $summaryTukarTambah,
            'tukarKurang' => $summaryTukarKurang

        ];
    }

    private function formatDate($value,$type){
        if ($type == 1){
            return Carbon::createFromFormat("Y-m-d",$value)->addDays(1)->format("Y-m-d 00:00:00");
        }else{
            return Carbon::createFromFormat("Y-m-d",$value)->format("Y-m-d 00:00:00");
        }
    }
}
