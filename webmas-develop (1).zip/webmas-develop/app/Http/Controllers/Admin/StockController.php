<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\MediaUploadingTrait;
use App\Http\Requests\MassDestroyStockRequest;
use App\Http\Requests\StoreStockRequest;
use App\Http\Requests\UpdateStockRequest;
use App\Models\Category;
use App\Models\Stock;
use Gate;
use Illuminate\Http\Request;
use Spatie\MediaLibrary\MediaCollections\Models\Media;
use Symfony\Component\HttpFoundation\Response;
use Yajra\DataTables\Facades\DataTables;

class StockController extends Controller
{
    use MediaUploadingTrait;

    public function index(Request $request)
    {
        abort_if(Gate::denies('stock_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        if ($request->ajax()) {
            $query = Stock::with(['category'])->select(sprintf('%s.*', (new Stock())->table));
            $table = Datatables::of($query);

            $table->addColumn('placeholder', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');

            $table->editColumn('actions', function ($row) {
                $viewGate = 'stock_show';
                $editGate = 'stock_edit';
                $deleteGate = 'stock_delete';
                $crudRoutePart = 'stocks';

                return view('partials.datatablesActions', compact(
                'viewGate',
                'editGate',
                'deleteGate',
                'crudRoutePart',
                'row'
            ));
            });

            $table->editColumn('id', function ($row) {
                return $row->id ? $row->id : '';
            });
            $table->editColumn('nama_barang', function ($row) {
                return $row->nama_barang ? $row->nama_barang : '';
            });
            $table->addColumn('category_type_emas', function ($row) {
                return $row->category ? $row->category->type_emas : '';
            });

            $table->editColumn('jumlah_product', function ($row) {
                return $row->jumlah_product ? $row->jumlah_product : '';
            });
            $table->editColumn('berat', function ($row) {
                return $row->berat ? $row->berat : '';
            });
            $table->editColumn('karat', function ($row) {
                return $row->karat ? $row->karat : '';
            });
            $table->editColumn('kadar', function ($row) {
                return $row->kadar ? $row->kadar : '';
            });

            $table->editColumn('image', function ($row) {
                if ($photo = $row->image) {
                    return sprintf(
                        '<a href="%s" target="_blank"><img src="%s" width="50px" height="50px"></a>',
                        $photo->url,
                        $photo->thumbnail
                    );
                }
                return '';
            });

            $table->rawColumns(['actions', 'placeholder', 'category', 'image']);

            return $table->make(true);
        }

        $categories = Category::get();

        return view('admin.stocks.index', compact('categories'));
    }

    public function create()
    {
        abort_if(Gate::denies('stock_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $categories = Category::pluck('type_emas', 'id')->prepend(trans('global.pleaseSelect'), '');

        return view('admin.stocks.create', compact('categories'));
    }

    public function store(StoreStockRequest $request)
    {
        $stock = Stock::create($request->all());
        if ($request->input('image', false)) {
            $stock->addMedia(storage_path('tmp/uploads/' . basename($request->input('image'))))->toMediaCollection('stock_image');
        }

        if ($media = $request->input('ck-media', false)) {
            Media::whereIn('id', $media)->update(['model_id' => $stock->id]);
        }

        return redirect()->route('admin.stocks.index');
    }

    public function edit(Stock $stock)
    {
        abort_if(Gate::denies('stock_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $categories = Category::pluck('type_emas', 'id')->prepend(trans('global.pleaseSelect'), '');

        $stock->load('category');

        return view('admin.stocks.edit', compact('categories', 'stock'));
    }

    public function update(UpdateStockRequest $request, Stock $stock)
    {
        $stock->update($request->all());
        if ($request->input('image', false)) {
            if (!$stock->image || $request->input('image') !== $stock->image->file_name) {
                if ($stock->image) {
                    $stock->image->delete();
                }
                $stock->addMedia(storage_path('tmp/uploads/' . basename($request->input('image'))))->toMediaCollection('stock_image');
            }
        } elseif ($stock->image) {
            $stock->image->delete();
        }
        return redirect()->route('admin.stocks.index');
    }

    public function show(Stock $stock)
    {
        abort_if(Gate::denies('stock_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $stock->load('category');

        return view('admin.stocks.show', compact('stock'));
    }

    public function destroy(Stock $stock)
    {
        abort_if(Gate::denies('stock_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $stock->delete();

        return back();
    }

    public function massDestroy(MassDestroyStockRequest $request)
    {
        Stock::whereIn('id', request('ids'))->delete();

        return response(null, Response::HTTP_NO_CONTENT);
    }

    public function storeCKEditorImages(Request $request)
    {
        abort_if(Gate::denies('stock_create') && Gate::denies('stock_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $model         = new Stock();
        $model->id     = $request->input('crud_id', 0);
        $model->exists = true;
        $media         = $model->addMediaFromRequest('upload')->toMediaCollection('ck-media');

        return response()->json(['id' => $media->id, 'url' => $media->getUrl()], Response::HTTP_CREATED);
    }
}
