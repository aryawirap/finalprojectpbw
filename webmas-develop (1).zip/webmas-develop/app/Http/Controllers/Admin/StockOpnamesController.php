<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Stock;
use App\Models\StockOpname;
use App\Models\StockOpnameDetail;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Symfony\Component\HttpFoundation\Response;
use Yajra\DataTables\Facades\DataTables;

class StockOpnamesController extends Controller
{
    private function toDateEntity($date)
    {
        return \Carbon\Carbon::createFromFormat("d-m-Y",$date)->format("Y-m-d");
    }

    public function index(Request $request)
    {
        abort_if(Gate::denies('stockOpname_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        if ($request->ajax()) {
            if ($request->get('type') === 'export') {
                $from = $request->get('from');
                $to = $request->get('to');
                $category = Category::all();
                $pdf = Pdf::loadView('exports.stockOpname', compact('from', 'to','category'));
                $fileName = time() . '.' . 'pdf';
                return $pdf->download($fileName);
            }

            $query = StockOpname::select(sprintf('%s.*', (new StockOpname())->table));
            $query->when($request->get('from') !== null && $request->get('to') !== null, function ($q){
                return $q->whereBetween('created_at', [$this->toDateEntity(request()->get('from')) ." 00:00:00", $this->toDateEntity(request()->get('to'))." 23:59:59"]);
            });
            $table = Datatables::of($query);

            $table->addColumn('placeholder', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');

            $table->addColumn('penambahan', function(StockOpname $stockOpname) {
                return $stockOpname->stockOpnameDetail->where("type",2)->sum("jumlah");
            });

            $table->addColumn('stockKeluar', function(StockOpname $stockOpname) {
                return $stockOpname->stockOpnameDetail->where("type",1)->sum("jumlah");
            });

            $table->addColumn('total', function(StockOpname $stockOpname) {
                return  ($stockOpname->stock_awal + $stockOpname->stockOpnameDetail->where("type",2)->sum("jumlah")) - $stockOpname->stockOpnameDetail->where("type",1)->sum("jumlah");
            });

            $table->editColumn('actions', function ($row) {
                $addStockGate = 'stockOpname_create';
                $detailGate = 'stockOpname_detail';
                $crudRoutePart = 'stockOpname';

                return view('partials.datatablesStockOpnameActions', compact(
                    'addStockGate',
                    'detailGate',
                    'crudRoutePart',
                    'row'
                ));
            });

            $table->editColumn('id', function ($row) {
                return $row->id ? $row->id : '';
            });
            $table->editColumn('stock_awal', function ($row) {
                return $row->stock_awal ? $row->stock_awal : '';
            });
            $table->editColumn('stock_id', function ($row) {
                return $row->stock ? $row->stock->nama_barang : '';
            });
            $table->editColumn('tanggal', function ($row) {
                return $row->tanggal ?? '';
            });
//            $table->editColumn('status', function ($row) {
//                return $row->status ?? '';
//            });
            $table->rawColumns(['actions', 'placeholder']);
            return $table->make(true);
        }
        return view('admin.stockOpname.index');
    }

    public function syncStockOpname(Request $request)
    {
        $tgl = $request->post("tanggal");
        $stock = Stock::all();
        foreach ($stock as $row){
            $check = StockOpname::where("tanggal",$tgl)->where("stock_id",$row->id)->first();
            if ($check === NULL){ // stock tidak ada pengurangan pada tanggal ini
                StockOpname::create([
                    'stock_id' => $row->id,
                    'tanggal' => $tgl,
                    'stock_awal' => $row->jumlah_product,
                    'status' => 1
                ]);
            }
        }
        $formatted = Carbon::createFromFormat("Y-m-d",$tgl)->format("d F Y");
        return redirect()->route('admin.stockOpname.index')->with('success',"Berhasil synchronize stock opname {$formatted}");
    }

    public function addStock(StockOpname $stockOpname, $tgl)
    {
        return view("admin.stockOpname.addStock", compact("stockOpname","tgl"));
    }

    public function deleteStock(StockOpnameDetail $stockOpnameDetail)
    {
        Stock::findOrFail($stockOpnameDetail->stockOpname->stock_id)->decrement('jumlah_product',$stockOpnameDetail->jumlah);
        $stockOpnameDetail->delete();
        return redirect()->route('admin.stockOpname.index')->with('success',"Berhasil hapus stock opname detail");
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
           "jumlah" => ['required'],
           "tgl" => ['required'],
           "catatan" => ['required'],
           "StockOpnameId" => ['required'],
        ]);
        StockOpnameDetail::create([
            "catatan" => $validated['catatan'],
            "jumlah" => $validated['jumlah'],
            "type" => 2,
            "stock_opname_id" => $validated['StockOpnameId']
        ]);

        $stockOpname = StockOpname::findOrFail($validated['StockOpnameId']);
        $stock = Stock::findOrFail($stockOpname->stock_id);
        $stock->update(['jumlah_product' => $stock->jumlah_product + (int) $validated['jumlah']]);

        return redirect()->route('admin.stockOpname.index')->with('success',"Berhasil tambah stock {$stock['nama_barang']}");
    }

    public function show(StockOpname $stockOpname)
    {
        return view('admin.stockOpname.show', compact("stockOpname"));
    }

    public function edit(StockOpname $stockOpname)
    {
    }

    public function update(Request $request, StockOpname $stockOpname)
    {
    }

    public function destroy(StockOpname $stockOpname)
    {
    }
}