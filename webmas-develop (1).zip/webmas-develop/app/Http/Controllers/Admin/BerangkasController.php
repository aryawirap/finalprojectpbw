<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Berangkas;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Symfony\Component\HttpFoundation\Response;
use Yajra\DataTables\Facades\DataTables;

class BerangkasController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        abort_if(Gate::denies('berangkas_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $query = Berangkas::query()->select(sprintf('%s.*', (new Berangkas())->table));
        $query->when($request->get('from') !== null && $request->get('to') !== null, function ($q){
            return $q->whereBetween('created_at', [request()->get('from') ." 00:00:00", request()->get('to')." 23:59:59"]);
        });

        if ($request->ajax()) {
            $table = Datatables::of($query);

            $table->addColumn('placeholder', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');

            $table->editColumn('actions', function ($row) {
                $viewGate = 'berangkas_show';
                $editGate = 'berangkas_edit';
                $deleteGate = 'berangkas_delete';
                $crudRoutePart = 'berangkas';

                return view('partials.datatablesActions', compact(
                    'viewGate',
                    'editGate',
                    'deleteGate',
                    'crudRoutePart',
                    'row'
                ));
            });

            $table->editColumn('id', function ($row) {
                return $row->id ? $row->id : '';
            });

            $table->editColumn('tanggal', function ($row) {
                return $row->tanggal ? $row->tanggal : '';
            });

            $table->editColumn('type_berangkas', function ($row) {
                if ($row->type_berangkas == 1){
                    return 'Berangkas';
                }elseif($row->type_berangkas == 2){
                    return 'Uang masuk';
                }elseif($row->type_berangkas == 3){
                    return 'Uang keluar';
                }else{
                    return '-';
                }
            });

            $table->editColumn('type', function ($row) {
                if ($row->type == 1){
                    return 'Pengurangan';
                }elseif($row->type == 2){
                    return 'Penambahan';
                }else{
                    return '-';
                }
            });

            $table->editColumn('keterangan', function ($row) {
                return $row->keterangan ? $row->keterangan : '';
            });

            $table->editColumn('jumlah', function ($row) {
                return $row->jumlah ? encodeCurrency($row->jumlah) : '';
            });

            $table->rawColumns(['actions', 'placeholder']);

            return $table->make(true);
        }

        return view("admin.berangkas.index");
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        abort_if(Gate::denies('berangkas_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        return view("admin.berangkas.create");
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'tanggal' => ['required','date'],
            'type_berangkas' => ['required'],
            'type' => ['required'],
            'jumlah' => ['required'],
            'keterangan' => ['required'],
        ]);
        $validated['jumlah'] = decodeCurrency($validated['jumlah']); // decode currency
        Berangkas::create($validated);
        return redirect()->route("admin.berangkas.index")->with("success","success add berangkas data");
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Berangkas  $berangka
     * @return \Illuminate\Http\Response
     */
    public function show(Berangkas $berangka)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Berangkas  $berangka
     * @return \Illuminate\Http\Response
     */
    public function edit(Berangkas $berangka)
    {
        abort_if(Gate::denies('berangkas_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        return view("admin.berangkas.edit",compact("berangka"));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Berangkas  $berangka
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Berangkas $berangka)
    {

        $validated = $request->validate([
            'tanggal' => ['required','date'],
            'type_berangkas' => ['required'],
            'type' => ['required'],
            'jumlah' => ['required'],
            'keterangan' => ['required'],
        ]);
        $validated['jumlah'] = decodeCurrency($validated['jumlah']); // decode currency
        $berangka->update($validated);
        return redirect()->route("admin.berangkas.index")->with("success","success update data");
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Berangkas  $berangka
     * @return \Illuminate\Http\Response
     */
    public function destroy(Berangkas $berangka)
    {
        abort_if(Gate::denies('berangkas_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $berangka->delete();
        return back();
    }

    public function massDestroy(Request $request)
    {
        abort_if(Gate::denies('berangkas_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $request->validate([
            'ids'   => 'required|array',
            'ids.*' => 'exists:tukar_tambah_kurangs,id',
        ]);
        Berangkas::whereIn('id', request('ids'))->delete();

        return response(null, Response::HTTP_NO_CONTENT);
    }
}
