<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\MassDestroyPelunasanRequest;
use App\Models\MetodePembayaran;
use App\Models\Pelunasan;
use Haruncpi\LaravelIdGenerator\IdGenerator;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Yajra\DataTables\Facades\DataTables;
use Gate;
use App\Http\Requests\StorePelunasanRequest;
use App\Http\Requests\UpdatePelunasanRequest;
use Barryvdh\DomPDF\Facade\Pdf;

class PelunasanController extends Controller
{
    private function toDateEntity($date)
    {
        return \Carbon\Carbon::createFromFormat("d-m-Y",$date)->format("Y-m-d");
    }

    public function index(Request $request)
    {
        abort_if(Gate::denies('pelunasan_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        if ($request->ajax()) {
            $query = Pelunasan::with("customer")->select(sprintf('%s.*', (new Pelunasan())->table));
            $query->when($request->get('from') !== null && $request->get('to') !== null, function ($q){
                return $q->whereBetween('created_at', [$this->toDateEntity(request()->get('from')) ." 00:00:00", $this->toDateEntity(request()->get('to'))." 23:59:59"]);
            });
            $table = Datatables::of($query);
            
            $table->addColumn('placeholder', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');
            
            $table->editColumn('actions', function ($row) {
                $editGate = 'pelunasan_edit';
                $deleteGate = 'pelunasan_delete';
                $invoiceGate = 'pelunasan_invoice';
                $crudRoutePart = 'pelunasan';
                
                return view('partials.datatablesActionWithoutShow', compact(
                    'editGate',
                    'invoiceGate',
                    'deleteGate',
                    'crudRoutePart',
                    'row'
                ));
            });
            
            $table->editColumn('id', function ($row) {
                return $row->id ? $row->id : '';
            });
            $table->editColumn('barkode', function ($row) {
                return $row->barkode ? $row->barkode : '';
            });
            $table->editColumn('tanggal_pelunasan', function ($row) {
                return $row->tanggal_pelunasan ? $row->tanggal_pelunasan : '';
            });
            $table->editColumn('sisa_pelunasan', function ($row) {
                return $row->sisa_pelunasan ? "Rp. " . strval(number_format($row->sisa_pelunasan)) : '';
            });
            $table->editColumn('created_at', function ($row) {
                return $row->created_at ?: '';
            });
            $table->rawColumns(['actions', 'placeholder']);
            return $table->make(true);
        }

        $metode_pembayarans = MetodePembayaran::get();

        return view('admin.repayment.index', compact('metode_pembayarans'));
    }

    public function create()
    {
        abort_if(Gate::denies('pelunasan_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('admin.repayment.create');
    }

    public function store(StorePelunasanRequest $request)
    {
        $sale = Pelunasan::create($request->all());
        $id = IdGenerator::generate(['table' => 'todos', 'length' => 6, 'prefix' => date('Y-m-d')]);
        $sale->metode_pembayarans()->sync($request->input('metode_pembayarans', []));

        return redirect()->route('admin.repayment.index');
    }

    public function invoice(Pelunasan $pelunasan)
    {
        $pdf = Pdf::setPaper("folio")->loadView('exports.manual.pelunasan', compact("pelunasan"));
        $name = time() . "-invoice.pdf";
        if ($pelunasan->pdfPath !== null){
            unlink(public_path($pelunasan->pdfPath));
        }
        $pdf->save("invoices/".$name);
        $pelunasan->update([
            'pdfPath' => "invoices/".$name
        ]);
        return view("exports.preview",['invoice' => $pelunasan,'path' => 'pelunasan']);
    }

    public function edit(Pelunasan $pelunasan)
    {
        abort_if(Gate::denies('pelunasan_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $metode_pembayarans = MetodePembayaran::pluck('nama_metode', 'id');
        $pelunasan->load("pemesanan");

        return view('admin.repayment.edit', compact('metode_pembayarans', 'pelunasan'));
    }

    public function update(UpdatePelunasanRequest $request, Pelunasan $pelunasan)
    {
        $pelunasan->update($request->all());
        $pelunasan->metode_pembayarans()->sync($request->input('metode_pembayarans', []));

        return redirect()->route('admin.repayment.index');
    }

    public function show(Pelunasan $pelunasan)
    {
        abort_if(Gate::denies('pelunasan_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $pelunasan->load('metode_pembayarans');

        return view('admin.repayment.show', compact('pelunasan'));
    }

    public function destroy(Pelunasan $pelunasan)
    {
        abort_if(Gate::denies('pelunasan_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $pelunasan->delete();

        return back();
    }

    public function massDestroy(MassDestroyPelunasanRequest $request)
    {
        Pelunasan::whereIn('id', request('ids'))->delete();

        return response(null, Response::HTTP_NO_CONTENT);
    }
}
