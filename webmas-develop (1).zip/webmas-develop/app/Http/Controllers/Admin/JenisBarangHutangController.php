<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\MassDestroyJenisBarangHutangRequest;
use App\Http\Requests\StoreJenisBarangHutangRequest;
use App\Http\Requests\UpdateJenisBarangHutangRequest;
use App\Models\JenisBarangHutang;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Yajra\DataTables\Facades\DataTables;

class JenisBarangHutangController extends Controller
{
    public function index(Request $request)
    {
        abort_if(Gate::denies('jenis_barang_hutang_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        if ($request->ajax()) {
            $query = JenisBarangHutang::query()->select(sprintf('%s.*', (new JenisBarangHutang())->table));
            $table = Datatables::of($query);

            $table->addColumn('placeholder', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');

            $table->editColumn('actions', function ($row) {
                $viewGate = 'jenis_barang_hutang_show';
                $editGate = 'jenis_barang_hutang_edit';
                $deleteGate = 'jenis_barang_hutang_delete';
                $crudRoutePart = 'jenis-barang-hutangs';

                return view('partials.datatablesActions', compact(
                'viewGate',
                'editGate',
                'deleteGate',
                'crudRoutePart',
                'row'
            ));
            });

            $table->editColumn('id', function ($row) {
                return $row->id ? $row->id : '';
            });
            $table->editColumn('jenis', function ($row) {
                return $row->jenis ? $row->jenis : '';
            });

            $table->rawColumns(['actions', 'placeholder']);

            return $table->make(true);
        }

        return view('admin.jenisBarangHutangs.index');
    }

    public function create()
    {
        abort_if(Gate::denies('jenis_barang_hutang_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('admin.jenisBarangHutangs.create');
    }

    public function store(StoreJenisBarangHutangRequest $request)
    {
        $jenisBarangHutang = JenisBarangHutang::create($request->all());

        return redirect()->route('admin.jenis-barang-hutangs.index');
    }

    public function edit(JenisBarangHutang $jenisBarangHutang)
    {
        abort_if(Gate::denies('jenis_barang_hutang_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('admin.jenisBarangHutangs.edit', compact('jenisBarangHutang'));
    }

    public function update(UpdateJenisBarangHutangRequest $request, JenisBarangHutang $jenisBarangHutang)
    {
        $jenisBarangHutang->update($request->all());

        return redirect()->route('admin.jenis-barang-hutangs.index');
    }

    public function show(JenisBarangHutang $jenisBarangHutang)
    {
        abort_if(Gate::denies('jenis_barang_hutang_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $jenisBarangHutang->load('jenisBarangHutangs');

        return view('admin.jenisBarangHutangs.show', compact('jenisBarangHutang'));
    }

    public function destroy(JenisBarangHutang $jenisBarangHutang)
    {
        abort_if(Gate::denies('jenis_barang_hutang_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $jenisBarangHutang->delete();

        return back();
    }

    public function massDestroy(MassDestroyJenisBarangHutangRequest $request)
    {
        JenisBarangHutang::whereIn('id', request('ids'))->delete();

        return response(null, Response::HTTP_NO_CONTENT);
    }
}
