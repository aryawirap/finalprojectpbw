<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\MassDestroySaleRequest;
use App\Http\Requests\StoreSaleRequest;
use App\Http\Requests\UpdateSaleRequest;
use App\Models\MetodePembayaran;
use App\Models\Penjualan;
use App\Models\Sale;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;
use Gate;
use Haruncpi\LaravelIdGenerator\IdGenerator;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Yajra\DataTables\Facades\DataTables;

class SaleController extends Controller
{

    private function toDateEntity($date)
    {
        return Carbon::createFromFormat("d-m-Y",$date)->format("Y-m-d");
    }

    public function index(Request $request)
    {
        abort_if(Gate::denies('sale_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        if ($request->ajax()) {
            $query = Penjualan::with("customer")->select(sprintf('%s.*', (new Penjualan())->table));
            $query->when($request->get('from') !== null && $request->get('to') !== null, function ($q){
                return $q->whereBetween('created_at', [$this->toDateEntity(request()->get('from')) ." 00:00:00", $this->toDateEntity(request()->get('to'))." 23:59:59"]);
            });
            $table = Datatables::of($query);
            $table->addColumn('placeholder', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');

            $table->editColumn('actions', function ($row) {
                $editGate = 'sale_edit';
                $deleteGate = 'sale_delete';
                $invoiceGate = 'sale_invoice';
                $crudRoutePart = 'sales';

                return view('partials.datatablesActionWithoutShow', compact(
                    'editGate',
         'deleteGate',
                    'crudRoutePart',
                    'invoiceGate',
                    'row'
                ));
            });

            $table->editColumn('id', function ($row) {
                return $row->id ? $row->id : '';
            });

            $table->editColumn('noTrx', function ($row) {
                return $row->noTrx ? $row->noTrx : '';
            });

            $table->editColumn('customer_id', function ($row) {
                return $row->customer ? $row->customer->nama : '';
            });

            $table->editColumn('totalKuitansi', function ($row) {
                return $row->totalKuitansi ? $row->totalKuitansi : '';
            });

            $table->editColumn('grandTotal', function ($row) {
                return $row->grandTotal ? number_format($row->grandTotal) : '';
            });
            $table->editColumn('created_at', function ($row) {
                return $row->created_at ? $row->created_at : '';
            });
            $table->rawColumns(['actions', 'placeholder']);
            return $table->make(true);
        }

        $metode_pembayarans = MetodePembayaran::get();

        return view('admin.sales.index', compact('metode_pembayarans'));
    }

    public function invoice(Penjualan $sale)
    {
        $pdf = Pdf::setPaper("folio")->loadView('exports.manual.penjualan', compact("sale"));
        $name = time() . "-invoice.pdf";
        if ($sale->pdfPath !== null){ // remove old one
            unlink(public_path($sale->pdfPath));
        }
        $pdf->save("invoices/".$name); // save new one
        $sale->update([ // update new pdf path
            'pdfPath' => "invoices/".$name
        ]);
        return view("exports.preview",['invoice' => $sale,'path' => 'sales']);
    }

    public function create()
    {
        abort_if(Gate::denies('sale_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('admin.sales.create');
    }

    public function store(StoreSaleRequest $request)
    {
        $sale = Sale::create($request->all());
        $id = IdGenerator::generate(['table' => 'todos', 'length' => 6, 'prefix' => date('Y-m-d')]);
        $sale->metode_pembayarans()->sync($request->input('metode_pembayarans', []));

        return redirect()->route('admin.sales.index');
    }

    public function edit(Penjualan $sale)
    {
        abort_if(Gate::denies('sale_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $sale->load("customer", "penjualanItems", "metodePembayarans"); // load customer data from relationship
        return view('admin.sales.edit', compact('sale'));
    }

    public function update(UpdateSaleRequest $request, Sale $sale)
    {
        $sale->update($request->all());
        $sale->metode_pembayarans()->sync($request->input('metode_pembayarans', []));

        return redirect()->route('admin.sales.index');
    }

    public function show(Sale $sale)
    {
        abort_if(Gate::denies('sale_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $sale->load('metode_pembayarans');

        return view('admin.sales.show', compact('sale'));
    }

    public function destroy(Penjualan $sale)
    {
        abort_if(Gate::denies('sale_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $sale->delete();

        return back();
    }

    public function massDestroy(MassDestroySaleRequest $request)
    {
        Penjualan::whereIn('id', request('ids'))->delete();

        return response(null, Response::HTTP_NO_CONTENT);
    }
}
