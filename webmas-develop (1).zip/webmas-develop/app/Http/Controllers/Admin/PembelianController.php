<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\MassDestroyPembelianRequest;
use App\Models\MetodePembayaran;
use App\Models\Pembelian;
use App\Models\PembelianPayment;
use App\Models\PembelianItem;
use Haruncpi\LaravelIdGenerator\IdGenerator;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Yajra\DataTables\Facades\DataTables;
use Gate;
use App\Http\Requests\StorePembelianRequest;
use App\Http\Requests\UpdatePembelianRequest;
use Barryvdh\DomPDF\Facade\Pdf;

class PembelianController extends Controller
{
    private function toDateEntity($date)
    {
        return \Carbon\Carbon::createFromFormat("d-m-Y",$date)->format("Y-m-d");
    }

    public function index(Request $request)
    {
        abort_if(Gate::denies('pembelian_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        if ($request->ajax()) {
            $query = Pembelian::with("customer")->select(sprintf('%s.*', (new Pembelian())->table));
            $query->when($request->get('from') !== null && $request->get('to') !== null, function ($q){
                return $q->whereBetween('created_at', [$this->toDateEntity(request()->get('from')) ." 00:00:00", $this->toDateEntity(request()->get('to'))." 23:59:59"]);
            });
            $table = Datatables::of($query);
            
            $table->addColumn('placeholder', '&nbsp;');
            $table->addColumn('actions', '&nbsp;');
            
            $table->editColumn('actions', function ($row) {
                $editGate = 'pembelian_edit';
                $deleteGate = 'pembelian_delete';
                $invoiceGate = 'pembelian_invoice';
                $crudRoutePart = 'pembelian';

                return view('partials.datatablesActionWithoutShowPreview', compact(
                    'editGate',
                    'deleteGate',
                    'invoiceGate',
                    'crudRoutePart',
                    'row'
                ));
            });
            
            $table->editColumn('id', function ($row) {
                return $row->id ? $row->id : '';
            });
            $table->editColumn('noTrx', function ($row) {
                return $row->noTrx ? $row->noTrx : '';
            });
            $table->editColumn('customer_id', function ($row) {
                return $row->customer ? $row->customer->nama : '';
            });
            $table->editColumn('total_kuitansi', function ($row) {
                return $row->total_kuitansi ? $row->total_kuitansi : '';
            });
            $table->editColumn('grand_total', function ($row) {
                return $row->grand_total ? number_format($row->grand_total) : '';
            });
            $table->editColumn('from', function ($row) {
                return $row->from == 0 ? 'Toko' : 'Toko lain';
            });
            $table->filterColumn('from', function($query, $keyword) {
                if (strtolower($keyword) == 'toko'){
                    $keyword = '0';
                }else{
                    $keyword = '1';
                }
                $query->where('from', $keyword);
            });

            $table->editColumn('nota', function ($row) {
                return $row->nota ? $row->nota : '';
            });
            $table->editColumn('created_at', function ($row) {
                return $row->created_at ? $row->created_at : '';
            });
            $table->rawColumns(['actions', 'placeholder']);
            return $table->make(true);
        }


        $barangRongsokPembalian = PembelianItem::query()->when($request->get('from') !== null && $request->get('to') !== null, function ($q){
            return $q->whereBetween('created_at', [request()->get('from') ." 00:00:00", request()->get('to')." 23:59:59"]);
        });
        $summaryBarangRongsokPembalian = $barangRongsokPembalian->count();

        $beratBarangRongsokPembalian = PembelianItem::query()->when($request->get('from') !== null && $request->get('to') !== null, function ($q){
            return $q->whereBetween('created_at', [request()->get('from') ." 00:00:00", request()->get('to')." 23:59:59"]);
        });
        $summaryBeratBarangRongsokPembalian = $beratBarangRongsokPembalian->sum('berat');

        return view('admin.purchases.index', compact('summaryBarangRongsokPembalian', 'summaryBeratBarangRongsokPembalian'));
    }

    public function invoice(Pembelian $pembelian)
    {
        $pdf = Pdf::setPaper("folio")->loadView('exports.manual.pembelian', compact("pembelian"));
        $name = time() . "-invoice.pdf";
        if ($pembelian->pdfPath !== null){
            unlink(public_path($pembelian->pdfPath));
        }
        $pdf->save("invoices/".$name);
        $pembelian->update([
            'pdfPath' => "invoices/".$name
        ]);
        return view("exports.preview",['invoice' => $pembelian,'path' => 'pembelian']);
    }

    public function create()
    {
        abort_if(Gate::denies('pembelian_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('admin.purchases.create');
    }

    public function store(StorePembelianRequest $request)
    {
        $sale = Pembelian::create($request->all());
        $id = IdGenerator::generate(['table' => 'todos', 'length' => 6, 'prefix' => date('Y-m-d')]);
        $sale->metode_pembayarans()->sync($request->input('metode_pembayarans', []));

        return redirect()->route('admin.purchases.index');
    }

    public function edit(Pembelian $pembelian)
    {
        abort_if(Gate::denies('pembelian_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $metode_pembayarans = MetodePembayaran::pluck('nama_metode', 'id');
        $pembelian->load("customer", "pembelianItems");

        return view('admin.purchases.edit', compact('metode_pembayarans', 'pembelian'));
    }

    public function update(UpdatePembelianRequest $request, Pembelian $pembelian)
    {
        $pembelian->update($request->all());
        $pembelian->metode_pembayarans()->sync($request->input('metode_pembayarans', []));

        return redirect()->route('admin.purchases.index');
    }

    public function show(Pembelian $pembelian)
    {
        abort_if(Gate::denies('pembelian_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $pembelian->load('metode_pembayarans');

        return view('admin.purchases.show', compact('pembelian'));
    }

    public function destroy(Pembelian $pembelian)
    {
        abort_if(Gate::denies('pembelian_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $pembelian->delete();

        return back();
    }

    public function massDestroy(MassDestroyPembelianRequest $request)
    {
        Pembelian::whereIn('id', request('ids'))->delete();

        return response(null, Response::HTTP_NO_CONTENT);
    }
}
