<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\MassDestroyGeneralConfigRequest;
use App\Http\Requests\StoreGeneralConfigRequest;
use App\Http\Requests\UpdateGeneralConfigRequest;
use App\Models\GeneralConfig;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Yajra\DataTables\Facades\DataTables;

class GeneralConfigController extends Controller
{
    public function index(Request $request)
    {
        abort_if(Gate::denies('general_config_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $data = GeneralConfig::first();
        return view('admin.generalConfigs.index', compact("data"));
    }

    public function update(UpdateGeneralConfigRequest $request, GeneralConfig $generalConfig)
    {
        $pathname = $generalConfig->logo;

        if ($request->hasFile("logo")){
            unlink($pathname);
            $pathname = $request->file("logo")->storeAs('assets','logo.png','local_public');
        }

        $generalConfig->update([
            "logo" => $pathname,
            "name" => $request["name"]
        ]);

        return redirect()->route('admin.general-configs.index');
    }
}
