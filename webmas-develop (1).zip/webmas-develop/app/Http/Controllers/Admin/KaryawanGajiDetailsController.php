<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\karyawanGajiDetail;
use Illuminate\Http\Request;

class KaryawanGajiDetailsController extends Controller
{
    public function index()
    {
        
    }

    public function create()
    {
    }

    public function store(Request $request)
    {
    }

    public function show(karyawanGajiDetail $karyawanGajiDetail)
    {
    }

    public function edit(karyawanGajiDetail $karyawanGajiDetail)
    {
    }

    public function update(Request $request, karyawanGajiDetail $karyawanGajiDetail)
    {
    }

    public function destroy(karyawanGajiDetail $karyawanGajiDetail)
    {
    }
}