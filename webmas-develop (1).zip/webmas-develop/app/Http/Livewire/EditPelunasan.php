<?php

namespace App\Http\Livewire;

use App\Models\Category;
use App\Models\Customer;
use App\Models\MetodePembayaran;
use App\Models\Pelunasan;
use Livewire\Component;
use App\Models\Pemesanan;
use App\Http\Controllers\Traits\CurrencyTrait;
use App\Models\UpdatedDataReason;

class EditPelunasan extends Component
{
    use CurrencyTrait;

    public $metode_pembayarans = [];
    public $list_metode_pembayarans = [];
    public $totalKuitansi = 1;
    public $tempSisaPembayaran = 0;
    public $sisaPelunasan = 0;
    public $alasan = "";
    public $type_pembayaran = 1;
    protected $listeners = ['onChangeProdukId', 'onChangeTotalItemKwitansi' => '$refresh'];
    public $barcode = '';
    public $isiBarcode = '';
    public $pemesananID = 0;
    public $tanggal_pelunasan = '';
    public $cekBar = false;
    public $trx = [
    ];
    public $payment_list = [];
    public $customer = [
        "id" => 0,
        "nama" => "",
        "phone" => "",
        "email" => "",
    ];

    public $pelunasanData;
    public $catatan;

    public function mount()
    {   
        $this->sisaPelunasan = $this->pelunasanData->sisa_pelunasan;
        $this->tanggal_pelunasan = $this->pelunasanData->tanggal_pelunasan;
        $this->barcode = $this->pelunasanData->barkode;
        $this->catatan = $this->pelunasanData->note;

        foreach ($this->pelunasanData->pelunasanItems as $item){
            $this->trx[$item->noKuitansi-1]["items"][] = [
                "jenis_id" => $item->category_id,
                "nama_jenis" => $item->jenisEmas,
                "varian" => $item->varian,
                "nama_produk" => $item->namaBarang,
                "berat" => $item->berat,
                "kadar" => $item->kadar,
                "harga" => $this->encodeCurrency($item->hargaPerGram),
                "ongkos" => $this->encodeCurrency($item->ongkos),
                "uploaded" => $item->image
            ];
        }

        foreach ($this->pelunasanData->metodePembayarans as $metode){
            $this->list_metode_pembayarans[] =  [
                'metode_pembayaran_id' => $metode["pivot"]["metode_pembayaran_id"],
                'amount' => $metode["pivot"]["amount"]
            ];
        }

        $pembayaranList = MetodePembayaran::get(['id','nama_metode']);
        foreach ($pembayaranList as $list){
            $this->payment_list[] = [
                'id' => $list->id,
                'name' => $list->nama_metode,
                'used' => false,
            ];
        }

        $this->type_pembayaran = $this->pelunasanData->payment_type;
        $this->customerList = Customer::pluck("nama","id");
        $this->jenis_emas = Category::pluck('type_emas','id');
        $this->metode_pembayarans = $pembayaranList;

        foreach (collect($this->list_metode_pembayarans)->pluck('metode_pembayaran_id')->toArray() as $arr){
            foreach ($this->payment_list as $index => $d){
                if ($d['id'] === $arr){
                    $this->payment_list[$index]['used'] = true; // update array
                }
            }
        }
    }

    public function calculatesisaPelunasan()
    {
        $sisaPelunasan = 0;
        foreach ($this->trx as $trx){
            foreach ($trx["items"] as $item){
                $sisaPelunasan += ((float) $item["berat"] * (float) $this->decodeCurrency($item["harga_pergram"])) + (float) $this->decodeCurrency($item["ongkos"]);
            }
        }
        $this->sisaPelunasan = $sisaPelunasan;
    }

    public function calculateSisaPembayaran()
    {
        $this->calculatesisaPelunasan();
        $totalMetodePembayaran =  0;
        foreach ($this->list_metode_pembayarans as $d){
            $totalMetodePembayaran += $this->decodeCurrency($d['amount']) == '' ? 0 : $this->decodeCurrency($d['amount']);
        }
        $this->tempSisaPembayaran = (float) $totalMetodePembayaran - $this->sisaPelunasan;
    }

    public function searchIndexAndUpdatePaymentListByMetodeId($id)
    {
        foreach ($this->payment_list as $index => $d){
            if ($d['id'] == $id){
                $this->payment_list[$index]['used'] = !$this->payment_list[$index]['used'];// update array
                return;
            }
        }
    }

    public function updatingTypePembayaran($value)
    {
        if($value == 1 && $this->type_pembayaran == 2){
            $this->tempSisaPembayaran = $this->totalPembayaran;
        } else {
            $this->calculateSisaPembayaran();
        }
    }

    public function updatedListMetodePembayarans($value, $index)
    {
        if(str_contains($index, "amount")){
            $this->calculateSisaPembayaran();
        }
    }

    public function updatingListMetodePembayarans($value, $index)
    {
        if (str_contains($index, "metode_pembayaran_id")){
            $ex = explode('.', $index);
            $this->searchIndexAndUpdatePaymentListByMetodeId($this->list_metode_pembayarans[$ex[0]]['metode_pembayaran_id']); // used = true
            if ($value != ''){
                $this->searchIndexAndUpdatePaymentListByMetodeId($value); // used = true\
            }
        }
    }

    public function onClickCreateMetodePembayaran(){
        $this->list_metode_pembayarans[] =  [
            'metode_pembayaran_id' => '',
            'amount' => 0
        ];
    }

    public function onClickRemoveMetodePembayaran($index)
    {
        $this->searchIndexAndUpdatePaymentListByMetodeId($this->list_metode_pembayarans[$index]["metode_pembayaran_id"]);
        $this->tempSisaPembayaran -= (float) $this->decodeCurrency($this->list_metode_pembayarans[$index]["amount"]);
        unset($this->list_metode_pembayarans[$index]);
        $this->list_metode_pembayarans = array_values($this->list_metode_pembayarans);
    }

    public function cekBarcode()
    {
        $this->trx = [];
        $data = Pemesanan::where('noTrx', '=', $this->barcode)->get()->first();

        if(!is_null($data) && $data->count() > 0) {
            $this->sisaPelunasan = $data->sisa_pelunasan;
            $this->tempSisaPembayaran = $this->sisaPelunasan;
            $this->isiBarcode = "Nota di temukan";
            $this->pemesananID = $data->id;
        } else {
            $this->isiBarcode = "Data tidak ditemukan";
        }
    }

    public function save()
    {
        $pelunasan = Pelunasan::findOrFail($this->pelunasanData->id);
        $pelunasan->update([
            "tanggal_pelunasan" => $this->tanggal_pelunasan,
            "payment_type" => $this->type_pembayaran,
            "note" => $this->catatan,
        ]);

        $comment = new UpdatedDataReason();
        $comment->reason = $this->alasan;
        $pelunasan->comments()->save($comment);

        if($this->type_pembayaran == 1){ // single payment
            $pelunasan->metodePembayarans()->sync([
                [
                    'metode_pembayaran_id' => $this->list_metode_pembayarans[0]["metode_pembayaran_id"],
                    'amount' => $this->sisaPelunasan
                ]
            ]);
        }else{ // multi payment
            $tempMetode = [];
            foreach ($this->list_metode_pembayarans as $d){
                $tempMetode[(int) $d['metode_pembayaran_id']] = [
                    'amount' => $this->decodeCurrency($d['amount']) == '' ? 0 : $this->decodeCurrency($d['amount']),
                ];
            }
            $pelunasan->metodePembayarans()->sync($tempMetode);
        }

        return redirect()->route('admin.pelunasan.invoice',['pelunasan' => $pelunasan->id])->with("success","data saved");
    }

    public function render()
    {
        return view('livewire.edit-pelunasan');
    }
}
