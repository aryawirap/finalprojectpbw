<?php

namespace App\Http\Livewire;

use App\Http\Controllers\Traits\CurrencyTrait;
use Livewire\Component;

class FormHutangKaryawan extends Component
{
    use CurrencyTrait;
    public $jumlah_hutang = 0;
    public $lamaCicilan = 0;
    public $cicilanPerbulan = 0;
    public $jenis_barangs = [];
    public $jenisBarangSwitch = false;

    public function render()
    {
        if ($this->jumlah_hutang !== 0 && $this->lamaCicilan !== 0 && $this->lamaCicilan !== "" && $this->jumlah_hutang !== "" ){
            $this->cicilanPerbulan = (int) $this->decodeCurrency($this->jumlah_hutang) / (int) $this->lamaCicilan;
        }
        return view('livewire.form-hutang-karyawan');
    }

    public function otherJenisBarang()
    {
        $this->dispatchBrowserEvent('pharaonic.select2.load', [
            'component' => 1,
            'target'    => '#input-jenisBarang'
        ]);
        $this->jenisBarangSwitch = !$this->jenisBarangSwitch;
    }
}
