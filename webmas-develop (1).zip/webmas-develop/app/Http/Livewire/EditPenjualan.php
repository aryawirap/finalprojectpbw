<?php

namespace App\Http\Livewire;

use App\Http\Controllers\Traits\CurrencyTrait;
use App\Models\Category;
use App\Models\Customer;
use App\Models\MetodePembayaran;
use App\Models\Penjualan;
use App\Models\PenjualanItem;
use App\Models\Stock;
use App\Models\StockOpname;
use App\Models\StockOpnameDetail;
use App\Models\UpdatedDataReason;
use Haruncpi\LaravelIdGenerator\IdGenerator;
use Livewire\Component;
use Livewire\WithFileUploads;

class EditPenjualan extends Component
{
    use CurrencyTrait, WithFileUploads;

    public $metode_pembayarans = [];  // from database
    public $jenis_emas = []; // from database
    public $payment_list = []; // unique for multi payment

    public $list_metode_pembayarans = [];
    public $totalKuitansi = 1;
    public $grandTotal;
    public $trx = [];
    public $tempSisaPembayaran = 0; // only for multi payment

    public $type_pembayaran = 1;
    public $alasan = "";
    public $catatan;

    // customer data
    public $createCustomer = false;
    public $customer = [
        "id" => 0,
        "nama" => "",
        "phone" => "",
        "email" => "",
    ];

    public $penjualanData; // dump penjualan data by id
    public $customerList = [];

    protected $listeners = ['onChangeProdukId', 'onChangeTotalItemKwitansi' => '$refresh'];

    public function mount()
    {
        // initialize customer
        $customer = $this->penjualanData->customer;
        $this->customer["id"] = $customer->id;
        $this->customer["nama"] = $customer->nama;
        $this->customer["phone"] = $customer->nomor_hp;
        $this->customer["email"] = $customer->email;

        // initialize invoice
        $this->totalKuitansi = $this->penjualanData->totalKuitansi;
        $this->grandTotal = $this->penjualanData->grandTotal;

        // loop items
        foreach ($this->penjualanData->penjualanItems as $item){
            $this->trx[$item->noKuitansi-1]["items"][] = [
                "jenis_id" => $item->category_id,
                "nama_jenis" => $item->jenisEmas,
                "varian" => $item->varian,
                "produk_id" => $item->stock_id,
                "nama_produk" => $item->namaBarang,
                "berat" => $item->berat,
                "kadar" => $item->kadar,
                "harga" => $this->encodeCurrency($item->hargaPerGram),
                "ongkos" => $this->encodeCurrency($item->ongkos),
                "uploaded" => $item->image,
                "oldUploaded" => $item->image,
            ];
        }

        // loop metode pembayran
        foreach ($this->penjualanData->metodePembayarans as $metodeData){
            $this->list_metode_pembayarans[] =  [
                'metode_pembayaran_id' => $metodeData["pivot"]["metode_pembayaran_id"],
                'amount' => $this->encodeCurrency($metodeData["pivot"]["amount"])
            ];
        }

        // initialize support data
        $pembayaranList = MetodePembayaran::get(['id','nama_metode']);
        foreach ($pembayaranList as $list){
            $this->payment_list[] = [
                'id' => $list->id,
                'name' => $list->nama_metode,
                'used' => false,
            ];
        }

        $this->customerList = Customer::pluck("nama","id");
        $this->type_pembayaran = $this->penjualanData->payment_type;
        $this->jenis_emas = Category::pluck('type_emas','id');
        $this->metode_pembayarans = $pembayaranList;
        $this->catatan = $this->penjualanData->note;

        foreach (collect($this->list_metode_pembayarans)->pluck('metode_pembayaran_id')->toArray() as $arr){
            foreach ($this->payment_list as $index => $d){
                if ($d['id'] === $arr){
                    $this->payment_list[$index]['used'] = true; // update array
                }
            }
        }
    }

    public function calculateGrandTotal()
    {
        $grandTotal = 0;
        foreach ($this->trx as $trx){
            foreach ($trx["items"] as $item){
                $grandTotal += ((float) $item["berat"] * (float) $this->decodeCurrency($item["harga"])) + (float) $this->decodeCurrency($item["ongkos"]);
            }
        }
        $this->grandTotal = $grandTotal;
    }

    public function calculateSisaPembayaran()
    {
        $this->calculateGrandTotal();
        $totalMetodePembayaran =  0;
        foreach ($this->list_metode_pembayarans as $d){
            $totalMetodePembayaran += $this->decodeCurrency($d['amount']) == '' ? 0 : $this->decodeCurrency($d['amount']);
        }
        $this->tempSisaPembayaran = (float) $totalMetodePembayaran - $this->grandTotal;
    }

    public function searchIndexAndUpdatePaymentListByMetodeId($id)
    {
        foreach ($this->payment_list as $index => $d){
            if ($d['id'] == $id){
                $this->payment_list[$index]['used'] = !$this->payment_list[$index]['used'];// update array
                return;
            }
        }
    }

    public function updatingTypePembayaran($value)
    {
        if($value == 1 && $this->type_pembayaran == 2){
            $this->tempSisaPembayaran = $this->grandTotal;
//            $this->list_metode_pembayarans = [ // reset to default
//                [
//                    'metode_pembayaran_id' => '',
//                    'amount' => 0
//                ]
//            ];
        }else{
            $this->calculateSisaPembayaran();
        }
    }

    public function updatedListMetodePembayarans($value, $index){
        if(str_contains($index, "amount")){
            $this->calculateSisaPembayaran();
        }
    }

    public function updatingListMetodePembayarans($value, $index)
    {
        if (str_contains($index, "metode_pembayaran_id")){
            $ex = explode('.', $index);
            $this->searchIndexAndUpdatePaymentListByMetodeId($this->list_metode_pembayarans[$ex[0]]['metode_pembayaran_id']); // used = true
            if ($value != ''){
                $this->searchIndexAndUpdatePaymentListByMetodeId($value); // used = true\
            }
        }
    }

    public function onClickCreateMetodePembayaran(){
        $this->list_metode_pembayarans[] =  [
            'metode_pembayaran_id' => '',
            'amount' => 0
        ];
    }

    public function onClickRemoveMetodePembayaran($index)
    {
        $this->searchIndexAndUpdatePaymentListByMetodeId($this->list_metode_pembayarans[$index]["metode_pembayaran_id"]);
        $this->tempSisaPembayaran -= (float) $this->decodeCurrency($this->list_metode_pembayarans[$index]["amount"]);
        unset($this->list_metode_pembayarans[$index]);
        $this->list_metode_pembayarans = array_values($this->list_metode_pembayarans);
        $this->calculateSisaPembayaran();
    }

    public function save()
    {
        $tempCustomer = null;
        // if new customer
        if($this->createCustomer){
            $tempCustomer = Customer::create([
                "nama" => $this->customer["nama"],
                "email" => $this->customer["email"],
                "nomor_hp" => $this->customer["phone"],
            ]);
        }else{ // already customer
            $tempCustomer["id"] = $this->customer["id"];
        }

        $penjualan = Penjualan::findOrFail($this->penjualanData->id);
        $date = $penjualan->created_at->format("Y-m-d");
        $penjualan->update([ // update invoice
            "payment_type" => $this->type_pembayaran,
            "totalKuitansi" => $this->totalKuitansi,
            "customer_id" => $tempCustomer["id"],
            "grandTotal" => $this->grandTotal,
            "note" => $this->catatan
        ]);

        $tmpPenjualanItem = $penjualan->penjualanItems()->pluck("id")->toArray();
        $tmpStock = $penjualan->penjualanItems()->pluck("stock_id")->toArray(); // add last stock before insert new
        $tmpStockDetail = StockOpnameDetail::where("penjualan_id",$penjualan->id)->pluck("id")->toArray();

        foreach ($tmpStock as $stock_id){
            Stock::findOrFail($stock_id)->increment('jumlah_product');
        }

        $no = 1;
        foreach ($this->trx as $trx){
            foreach ($trx["items"] as $item){
                $checkStockOpname = StockOpname::where("tanggal",$date)->where("stock_id", $item["produk_id"])->first();

                if ($checkStockOpname !== null){
                    StockOpnameDetail::create([ // create StockOpname Detail
                        "type" => 1, // 1 = pengurangan dari penjualan, 2 = penambahan
                        "jumlah" => 1,
                        "penjualan_id" => $penjualan->id,
                        "stock_opname_id" => $checkStockOpname->id,
                        "created_at" => $checkStockOpname->created_at
                    ]);
                }

                $data = [
                    "penjualan_id" => $penjualan->id,
                    "category_id" => $item["jenis_id"],
                    "varian" => $item["varian"],
                    "stock_id" => $item["produk_id"],
                    "noKuitansi" => $no,
                    "jenisEmas" => Category::findOrFail($item["jenis_id"])->type_emas,
                    "namaBarang" => $item["nama_produk"],
                    "berat" => $item["berat"],
                    "kadar" => $item["kadar"],
                    "hargaPerGram" => $this->decodeCurrency($item["harga"]),
                    "ongkos" => $this->decodeCurrency($item["ongkos"]),
                    "total" => ((float) $item["berat"] * (float) $this->decodeCurrency($item["harga"])) + (float) $this->decodeCurrency($item["ongkos"]),
                    "image" => $item['uploaded']
                ];
                if (gettype($item["uploaded"]) !== 'string' && gettype($item["uploaded"]) === 'object'){
                    $data['image'] = $item["uploaded"]->storePublicly('foto_barang_penjualan','local_public');
                    if (!empty($item["oldUploaded"])){
                        unlink(public_path($item["oldUploaded"]));
                    }
                }

                Stock::findOrFail($item["produk_id"])->decrement('jumlah_product'); // decrement stock
                PenjualanItem::create($data);
            }
            $no++;
        }

        // delete by list of id
        PenjualanItem::whereIn("id",$tmpPenjualanItem)->delete();
        StockOpnameDetail::whereIn("id",$tmpStockDetail)->delete();

        // add comment before update
        $comment = new UpdatedDataReason();
        $comment->reason = $this->alasan;
        $penjualan->comments()->save($comment);

        if($this->type_pembayaran == 1){ // single payment
            $penjualan->metodePembayarans()->sync([
                [
                    'metode_pembayaran_id' => $this->list_metode_pembayarans[0]["metode_pembayaran_id"],
                    'amount' => $this->grandTotal
                ]
            ]);
        }else{ // multi payment
            $tempMetode = [];
            foreach ($this->list_metode_pembayarans as $d){
                $tempMetode[(int) $d['metode_pembayaran_id']] = [
                    'amount' => $this->decodeCurrency($d['amount']) == '' ? 0 : $this->decodeCurrency($d['amount']),
                ];
            }
            $penjualan->metodePembayarans()->sync($tempMetode); // assign to pivot table penjualan_metode_pembayaran
        }
        return redirect()->route('admin.sales.invoice',['sale' => $penjualan->id])->with("success","data saved");  // redirect to sales
    }

    public function updatingTrx($value, $index)
    {
        $d = explode('.',$index);
        if (str_contains($index,'jenis_id') && $value == ""){
            $this->trx[$d[0]]['items'][$d[2]] = [
              "jenis_id" => "",
              "nama_jenis" => "",
              "varian" => "",
              "produk_id" => "",
              "nama_produk" => "",
              "berat" => 0,
              "kadar" => 0,
              "harga" => $this->encodeCurrency(0),
              "ongkos" => $this->trx[$d[0]]['items'][$d[2]]['ongkos'],
              "uploaded" => null,
            ];
        }
        $this->calculateSisaPembayaran();
    }

    public function updatedTrx($value, $index)
    {
        $this->calculateSisaPembayaran();
    }

    public function updatedCreateCustomer($value)
    {
        // reset when return to false && id not 0
        if (!$value || $this->customer["id"] !== 0){
            $this->customer = [
                "id" => 0,
                "nama" => "",
                "phone" => "",
                "email" => "",
            ];
        }
    }

    public function updatedCustomerId($value)
    {
        // search customer by id
        if ($this->customer["id"] !== 0 && $this->createCustomer === false && $value !== ''){
            $customerData = Customer::findOrFail($this->customer["id"]);
            $this->customer["nama"] = $customerData->nama;
            $this->customer["email"] = $customerData->email;
            $this->customer["phone"] = $customerData->nomor_hp;
        }
    }

    public function onChangeProdukId($value, $kwitansi, $index)
    {
        $this->trx[$kwitansi]["items"][$index]["produk_id"] = $value[0];
        $this->trx[$kwitansi]["items"][$index]["nama_produk"] = $value[1];
        $this->trx[$kwitansi]["items"][$index]["berat"] = $value[2];
        $this->trx[$kwitansi]["items"][$index]["kadar"] = $value[3];
    }

    public function onChangeTotalItemKwitansi($value, $kwitansi, $index)
    {
        $this->trx[$kwitansi]["items"][$index]["total"] = $value;
    }

    public function addRow($index)
    {
        $this->trx[$index]["items"][] = [
            "jenis_id" => '',
            "nama_jenis" => '',
            "varian" => '',
            "produk_id" => '',
            "nama_produk" => '',
            "berat" => 0,
            "kadar" => 0,
            "harga" => 0,
            "ongkos" => 0,
            "uploaded" => null
        ];
    }

    public function removeTrxRow($index)
    {
        unset($this->trx[$index]);
        $this->trx = array_values($this->trx);
        $this->totalKuitansi--;
        $this->calculateSisaPembayaran(); // calculate grand total
    }

    public function deleteRow($indexKuitansi, $indexRow)
    {
        unset($this->trx[$indexKuitansi-1]["items"][$indexRow]);
        $this->trx[$indexKuitansi-1]["items"] = array_values($this->trx[$indexKuitansi-1]["items"]);
        $this->calculateSisaPembayaran(); // calculate grand total
    }

    public function hitungSubTotal($indexKuitansi)
    {
        $subTotal = 0;
        foreach ($this->trx[$indexKuitansi-1]["items"] as $item){
            $subTotal += ((float) $item["berat"] * (float) $this->decodeCurrency($item["harga"])) + (float) $this->decodeCurrency($item["ongkos"]);
        }
        $this->trx[$indexKuitansi-1]["sub_total"] = $subTotal;
    }

    public function updatingTotalKuitansi($value)
    {
        if ($value < 1 || $value == ""){

            $this->trx = [];
            $this->trx[] = [
                "sub_total" => 0,
                "items" => [
                    [
                        "jenis_id" => '',
                        "nama_jenis" => '',
                        "varian" => '',
                        "produk_id" => '',
                        "nama_produk" => '',
                        "berat" => $this->encodeCurrency(0),
                        "kadar" => $this->encodeCurrency(0),
                        "harga" => $this->encodeCurrency(0),
                        "ongkos" => $this->encodeCurrency(0),
                        "uploaded" => null
                    ]
                ]
            ];
            $this->calculateSisaPembayaran();
            return;
        }

        if ($value <= $this->totalKuitansi){
            for ($i=$this->totalKuitansi-1; $i >= $value; $i--){
                unset($this->trx[$i]);
                $this->trx = array_values($this->trx);
            }
        }

        for ($i=count($this->trx); $i < $value; $i++){
            $this->trx[] = [
                "sub_total" => 0,
                "items" => [
                    [
                        "jenis_id" => '',
                        "nama_jenis" => '',
                        "varian" => '',
                        "produk_id" => '',
                        "nama_produk" => '',
                        "berat" => 0,
                        "kadar" => 0,
                        "harga" => 0,
                        "ongkos" => 0,
                        "uploaded" => null
                    ]
                ]
            ];
        }
        $this->calculateSisaPembayaran();
    }

    public function render()
    {
        return view('livewire.edit-penjualan');
    }
}
