<?php

namespace App\Http\Livewire;

use Livewire\Component;

class FormKaryawan extends Component
{
    public $roles = [];
    public $roleSelected = "1";
    public $type = "";
    public $user;
    public $karyawan = null;

    public function mount(){
        if ($this->type === "edit"){
            if($this->user->roles[0]->id !== 1){
                $this->roleSelected = "2";
                $this->karyawan = $this->user->karyawan;
            }
        }
    }

    public function render()
    {
        return view('livewire.form-karyawan');
    }
}
