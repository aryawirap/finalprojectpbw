<?php

namespace App\Http\Livewire;

use App\Models\Category;
use App\Models\Customer;
use App\Models\MetodePembayaran;
use App\Models\Pelunasan;
use App\Models\PelunasanItem;
use Livewire\Component;
use Haruncpi\LaravelIdGenerator\IdGenerator;
use App\Models\Pemesanan;
use Illuminate\Support\Carbon;
use App\Http\Controllers\Traits\CurrencyTrait;

class CreatePelunasan extends Component
{
    use CurrencyTrait;

    public $metode_pembayarans = [];
    public $list_metode_pembayarans = [
        [
            'metode_pembayaran_id' => '',
            'amount' => 0
        ]
    ];
    public $totalKuitansi = 1;
    public $tempSisaPembayaran = 0;
    public $sisaPelunasan = 0;
    public $catatan;
    public $type_pembayaran = 1;
    protected $listeners = ['onChangeProdukId', 'onChangeTotalItemKwitansi' => '$refresh'];
    public $barcode = '';
    public $isiBarcode = '';
    public $pemesananID = 0;
    public $tanggal_pelunasan = '';
    public $cekBar = false;
    public $trx = [
    ];
    public $payment_list = [];
    public $customer = [
        "id" => 0,
        "nama" => "",
        "phone" => "",
        "email" => "",
    ];

    public function mount()
    {
        $pembayaranList = MetodePembayaran::pluck('nama_metode', 'id');
        foreach ($pembayaranList as $index => $list){
            $this->payment_list[] = [
                'id' => $index,
                'name' => $list,
                'used' => false,
            ];
        }
        $this->customerList = Customer::pluck("nama","id");
        $this->jenis_emas = Category::pluck('type_emas','id');
        $this->metode_pembayarans = $pembayaranList;
    }

    public function calculateSisaPembayaran()
    {
        $totalMetodePembayaran =  0;
        foreach ($this->list_metode_pembayarans as $d){
            $totalMetodePembayaran += $this->decodeCurrency($d['amount']) == '' ? 0 : $this->decodeCurrency($d['amount']);
        }
        $this->tempSisaPembayaran = (float) $totalMetodePembayaran - $this->sisaPelunasan;
    }

    public function searchIndexAndUpdatePaymentListByMetodeId($id)
    {
        foreach ($this->payment_list as $index => $d){
            if ($d['id'] == $id){
                $this->payment_list[$index]['used'] = !$this->payment_list[$index]['used'];// update array
                return;
            }
        }
    }

    public function updatingTypePembayaran($value)
    {
        if($value == 1 && $this->type_pembayaran == 2){
            $this->tempSisaPembayaran = $this->sisaPelunasan;
        }else{
            $this->calculateSisaPembayaran();
        }
    }

    public function updatedListMetodePembayarans($value, $index)
    {
        if(str_contains($index, "amount")){
            $this->calculateSisaPembayaran();
        }
    }

    public function updatingListMetodePembayarans($value, $index)
    {
        if (str_contains($index, "metode_pembayaran_id")){
            $ex = explode('.', $index);
            $this->searchIndexAndUpdatePaymentListByMetodeId($this->list_metode_pembayarans[$ex[0]]['metode_pembayaran_id']); // used = true
            if ($value != ''){
                $this->searchIndexAndUpdatePaymentListByMetodeId($value); // used = true\
            }
        }
    }

    public function onClickCreateMetodePembayaran(){
         $this->list_metode_pembayarans[] =  [
             'metode_pembayaran_id' => '',
             'amount' => 0
         ];
    }

    public function onClickRemoveMetodePembayaran($index)
    {
        $this->tempSisaPembayaran += (float) $this->list_metode_pembayarans[$index]["amount"];
        unset($this->list_metode_pembayarans[$index]);
        $this->list_metode_pembayarans = array_values($this->list_metode_pembayarans);
    }

    public function cekBarcode()
    {
        $this->cekBar = true;
        $this->trx = [];
        $data = Pemesanan::where('noTrx', '=', trim($this->barcode))->get()->first();

        if(!is_null($data) && $data->count() > 0) {
            $this->customer = [
                "id" => $data->customer->id,
                "nama" => $data->customer->nama,
                "phone" => $data->customer->nomor_hp,
                "email" => $data->customer->email,
            ];
            foreach ($data["pemesananItems"] as $item){
                // dd($item);
                $this->trx[$item->no-1]["items"][] = [
                    "jenis_id" => $item->category_id,
                    "nama_jenis" => $item->jenis_emas,
                    "varian" => $item->varian,
                    "nama_produk" => $item->nama_barang,
                    "berat" => $item->berat,
                    "kadar" => $item->kadar,
                    "harga" => $this->encodeCurrency($item->harga_pergram),
                    "ongkos" => $this->encodeCurrency($item->ongkos),
                    "uploaded" => $item->images
                ];
            }
            $this->sisaPelunasan = $data->sisa_pelunasan;
            $this->tempSisaPembayaran = $this->sisaPelunasan;
            $this->isiBarcode = "Nota di temukan";
            $this->pemesananID = $data->id;
        } else {
            $this->isiBarcode = "Data tidak ditemukan";
        }
    }

    public function save()
    {
        $pemesanan = Pemesanan::find($this->pemesananID);
        $noTrx = IdGenerator::generate(['field' => 'noTrx','table' => 'penjualans', 'length' => 13, 'prefix' => date('Ymd')."-"]);
        
        $tempPelunasan = Pelunasan::create([
            // "pemesanan_id" => $this->pemesananID,
            "barkode" => $this->barcode,
            "tanggal_pelunasan" => $this->tanggal_pelunasan != '' ? $this->tanggal_pelunasan : Carbon::now()->toDate(),
            "sisa_pelunasan" => $this->sisaPelunasan,
            "noTrx" => $noTrx,
            "totalKuitansi" => $this->totalKuitansi,
            "customer_id" => $pemesanan->customer_id,
            "grandTotal" => $this->sisaPelunasan,
            "payment_type" => $this->type_pembayaran,
            "note" => $this->catatan
        ]);

        foreach ($pemesanan->pemesananItems as $item){
            PelunasanItem::create([
                "pelunasan_id" => $tempPelunasan->id,
                "category_id" => $item->category_id,
                "noKuitansi" => $item->no,
                "jenisEmas" => Category::findOrFail($item->category_id)->type_emas,
                "namaBarang" => $item->nama_barang,
                "berat" => $item->berat,
                "kadar" => $item->kadar,
                "hargaPerGram" => $item->harga_pergram,
                "hargaSekarang" => $item->harga_pergram,
                "ongkos" => $item->ongkos,
                "varian" => $item->varian,
                "total" => ((float) $item->berat * (float) $item->harga_pergram) + (float) $item->ongkos,
                "image" => $item->images,
            ]);
        }

        if($this->type_pembayaran == 1){
            $tempPelunasan->metodePembayarans()->attach([
                [
                    'metode_pembayaran_id' => $this->list_metode_pembayarans[0]["metode_pembayaran_id"],
                    'amount' => $this->sisaPelunasan
                ]
            ]);
        }else{
            $tempMetode = [];
            foreach ($this->list_metode_pembayarans as $d){
                $tempMetode[(int) $d['metode_pembayaran_id']] = [
                    'amount' => $this->decodeCurrency($d['amount']) == '' ? 0 : $this->decodeCurrency($d['amount']),
                ];
            }
            $tempPelunasan->metodePembayarans()->attach($tempMetode);
        }
        $pemesanan->update(['status' => 1]);
        $pemesanan->delete();
        
        return redirect()->route('admin.pelunasan.invoice',['pelunasan' => $tempPelunasan->id])->with("success","data saved");
    }

    public function render()
    {
        return view('livewire.create-pelunasan');
    }
}
