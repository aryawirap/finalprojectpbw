<?php

namespace App\Http\Livewire;

use App\Models\Berangkas;
use App\Models\Hutang;
use App\Models\Karyawan;
use App\Models\KaryawanGaji;
use App\Models\karyawanGajiDetail;
use Illuminate\Support\Facades\DB;
use Livewire\Component;

class EditGajiKaryawan extends Component
{
    public $karyawanGaji; // database

    public $karyawans; // database
    public $karyawan_id;
    public $gaji;
    public $listHutang = []; // database
    public $listSelectedHutang = [];
    public $listSelectedHutangLama = [];
    public $potongan;
    public $gajiBersih;

    public function mount()
    {
        $this->karyawans = Karyawan::where("tanggal_keluar", null)->pluck("name","id");
        $this->gaji = encodeCurrency($this->karyawanGaji->gaji);
        $this->potongan = encodeCurrency($this->karyawanGaji->potongan);
        $this->gajiBersih = encodeCurrency($this->karyawanGaji->totalGaji);
        $this->karyawan_id = $this->karyawanGaji->karyawan_id;

        $tempHutangSelected = [];
        foreach ($this->karyawanGaji->detailGaji->pluck("hutang_id") as $index => $item) {
            $tempHutangSelected[$item] = true;
        }
        $this->listSelectedHutang = $tempHutangSelected;

        $tempListHutangLama = collect();
        foreach ($this->karyawanGaji->detailGaji as $row){
            $tempListHutangLama->push(Hutang::findOrFail($row->hutang_id));
        }
        $this->listSelectedHutangLama = $tempListHutangLama;

        $this->listHutang = Karyawan::with("hutangsBelumLunas")->findOrFail($this->karyawan_id)->hutangsBelumLunas;
    }

    public function updatedKaryawanId($value)
    {
        if ($value !== ""){
            $karyawan = Karyawan::with("hutangsBelumLunas")->findOrFail($value);
            $this->gaji = encodeCurrency($karyawan->gaji);
            $this->listHutang = $karyawan->hutangsBelumLunas;
            $this->gajiBersih = encodeCurrency($karyawan->gaji);
        }else{
            $this->gaji = encodeCurrency(0);
            $this->listHutang = [];
            $this->listSelectedHutang = [];
            $this->potongan = encodeCurrency(0);
            $this->gajiBersih = encodeCurrency(0);
        }
    }

    public function updatedListSelectedHutang($value)
    {
        $this->potongan = encodeCurrency(0);
        foreach ($this->listSelectedHutang as $index => $row){
            if ($row){
                $check = $this->listHutang->where("id",$index)->first();
                if ($check !== null){
                    $this->potongan = encodeCurrency(decodeCurrency($this->potongan) + $check['nominal_cicilan']);
                }
            }
        }

        $tmpGaji = encodeCurrency(0);
        if (gettype((int) decodeCurrency($this->gaji)) === "integer"){
            $tmpGaji = $this->gaji;
        }
        $this->gajiBersih = encodeCurrency((int) decodeCurrency($tmpGaji) -  (int) decodeCurrency($this->potongan));
    }

    public function updatedGaji($value)
    {
        $this->updatedListSelectedHutang("");
    }

    public function updatingGaji($value)
    {
        $this->updatedListSelectedHutang("");
    }

    public function save()
    {
        KaryawanGaji::findOrFail($this->karyawanGaji->id)->update([ // update karyawan gaji
            'potongan' => decodeCurrency($this->potongan),
            'gaji' => decodeCurrency($this->gaji),
            'totalGaji' => decodeCurrency($this->gajiBersih)
        ]);

        Berangkas::where([ // update form pengurangan
            "model_id" => $this->karyawanGaji->id,
            "type_berangkas" => 1,
            "type" => 1 // 1= pengurangan
        ])->first()->update([
            "jumlah" => decodeCurrency($this->gajiBersih),
            "keterangan" => "edited by system. gajian dengan dengan gaji ". $this->gaji . ". potongan " . $this->potongan .". karyawan ". $this->karyawan_id,
        ]);

        Berangkas::where([ // update form penambahan
            "model_id" => $this->karyawanGaji->id,
            "type_berangkas" => 1,
            "type" => 2 // 2= penambahan
        ])->first()->update([
            "jumlah" => decodeCurrency($this->potongan),
            "keterangan" => "edited by system.". "potongan hutang " . $this->potongan .". karyawan ". $this->karyawan_id,
        ]);

        foreach ($this->listSelectedHutang as $index => $row){
            $check = $this->listHutang->where("id",$index)->first();
            if ($check !== null){
                $hutang = Hutang::findOrFail($index);
                if (count($this->listSelectedHutangLama) > 0){
                    $hutangLamaDibayarkan = $this->listSelectedHutangLama->where("id",$index)->first(); // kembalikan lama uang
                    if ($hutangLamaDibayarkan !== null){
                        $totalNominalLama = intval($hutangLamaDibayarkan["nominal_cicilan"]);
                        $hutang->update(['lama_cicilan' => DB::raw('lama_cicilan + 1'), "sudahDibayar" => DB::raw("sudahDibayar - $totalNominalLama")]);
                        karyawanGajiDetail::where("hutang_id",$hutang->id)->where("karyawan_gaji_id",$this->karyawanGaji->id)->delete(); // hapus karyawan gaji detail
                    }
                }

                if ($row){
                    $hutangBaru = Hutang::findOrFail($index);
                    if ($hutangBaru->lama_cicilan - 1 >= 0){ // kurangi uang
                        $hutangBaru->update(['lama_cicilan' => DB::raw('lama_cicilan - 1'), "sudahDibayar" => DB::raw("sudahDibayar + $check->nominal_cicilan")]);
                        karyawanGajiDetail::create([
                            'hutang_id' => $index,
                            'karyawan_gaji_id' => $this->karyawanGaji->id,
                            'nominal' => $check->nominal_cicilan
                        ]);
                    }else{
                        $hutangBaru->update(['status' => 2]);
                    }
                }
            }
        }
        return redirect()->route("admin.gaji.index")->with("success","succesfully add karyawan gaji");
    }

    public function render()
    {
        return view('livewire.edit-gaji-karyawan');
    }
}
