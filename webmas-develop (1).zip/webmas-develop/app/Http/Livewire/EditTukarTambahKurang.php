<?php

namespace App\Http\Livewire;

use App\Http\Controllers\Traits\CurrencyTrait;
use App\Models\Category;
use App\Models\Customer;
use App\Models\MetodePembayaran;
use App\Models\TukarTambahKurang;
use App\Models\TukarTambahKurangItem;
use App\Models\UpdatedDataReason;
use Livewire\Component;
use Livewire\WithFileUploads;

class EditTukarTambahKurang extends Component
{
    use CurrencyTrait, WithFileUploads;
    public $metode_pembayarans = []; // from database
    public $jenis_emas = []; // from database
    public $payment_list = []; // unique for multi payment
    public $tukarTambahKurangData; // from database

    protected $rules = [
        'invoiceTukarTambahKurangData.*.sub_total' => 'required',
        'invoiceTukarTambahKurangData.*.items.*.varian' => 'nullable',
        'invoiceTukarTambahKurangData.*.items.*.jenis_id' => 'required',
        'invoiceTukarTambahKurangData.*.items.*.produk_id' => 'required',
        'invoiceTukarTambahKurangData.*.items.*.nama_produk' => 'required',
        'invoiceTukarTambahKurangData.*.items.*.berat' => 'required',
        'invoiceTukarTambahKurangData.*.items.*.kadar' => 'required',
        'invoiceTukarTambahKurangData.*.items.*.harga' => 'required',
        'invoiceTukarTambahKurangData.*.items.*.ongkos' => 'required',
        'invoiceTukarTambahKurangData.*.items.*.uploaded' => 'nullable|image',
    ];

    protected $messages = [
        'invoiceTukarTambahKurangData.*.items.*.uploaded.image' => 'File upload harus berupa gambar',
        'invoiceTukarTambahKurangData.*.items.*.ongkos.required' => 'Field harus di isi',
        'invoiceTukarTambahKurangData.*.items.*.harga.required' => 'Field harus di isi',
        'invoiceTukarTambahKurangData.*.items.*.jenis_id.required' => 'Field harus di isi',
        'invoiceTukarTambahKurangData.*.items.*.produk_id.required' => 'Field harus di isi',
    ];
    
    public $list_metode_pembayarans = [];
    public $totalKuitansi = 1;
    public $trxKuitansi = 1;
    public $grandTotal = 0;
    public $grandTotalTukarTambah = 0;
    public $trx = [];
    public $tempSisaPembayaran = 0;

    public $from;
    public $type_pembayaran = 1;
    public $alasan = "";
    public $catatan;
    public $invoiceTukarTambahKurangData = [
        [
            "sub_total" => 0,
            "items" => []
        ]
    ];

    public $typetukarTambah = 1;

    // customer data
    public $createCustomer = false;
    public $customer = [
        "id" => 0,
        "nama" => "",
        "phone" => "",
        "email" => "",
    ];

    public $customerList = [];
    protected $listeners = ['onChangeProdukId', 'onChangeTotalItemKwitansi' => '$refresh'];

    public function mount()
    {
        // initialize customer
        $customer = $this->tukarTambahKurangData->customer;
        $this->customer["id"] = $customer->id;
        $this->customer["nama"] = $customer->nama;
        $this->customer["phone"] = $customer->nomor_hp;
        $this->customer["email"] = $customer->email;

        // initialize invoice
        $this->typetukarTambah = $this->tukarTambahKurangData->type;
        $this->grandTotalTukarTambah = $this->tukarTambahKurangData->totalPay;
        $this->totalKuitansi = $this->tukarTambahKurangData->total_kuitansi;
        $this->grandTotal = $this->tukarTambahKurangData->grand_total;
        $this->from = $this->tukarTambahKurangData->from;
        $this->trxKuitansi = $this->tukarTambahKurangData->tukarTambahKurangItems->where('type','2')->groupBy("noKuitansi")->count();

        // loop items
        foreach ($this->tukarTambahKurangData->tukarTambahKurangItems->where('type','1') as $item){
            $this->trx[$item->noKuitansi-1]["items"][] = [
                "jenis_id" => $item->category_id,
                "nama_jenis" => $item->jenis_emas,
                "varian" => $item->varian,
                "produk_id" => $item->stock_id,
                "nama_produk" => $item->namaBarang,
                "berat" => $item->berat,
                "kadar" => $item->kadar,
                "harga" => $this->encodeCurrency($item->hargaPerGram),
                "harga_sekarang" => $this->encodeCurrency($item->hargaPerGramBaru),
                "potongan" => $this->encodeCurrency($item->potongan),
                "uploaded" => $item->image,
                "oldUploaded" => $item->image,
            ];
        }

        // invoice tukar tambah kurang
        foreach ($this->tukarTambahKurangData->tukarTambahKurangItems->where('type','2') as $item){
            $this->invoiceTukarTambahKurangData[$item->noKuitansi-1]["items"][] = [
                "jenis_id" => $item->category_id,
                "nama_jenis" => $item->jenisEmas,
                "varian" => $item->varian,
                "produk_id" => $item->stock_id,
                "nama_produk" => $item->namaBarang,
                "berat" => $item->berat,
                "kadar" => $item->kadar,
                "harga" => $this->encodeCurrency($item->hargaPerGram),
                "ongkos" => $this->encodeCurrency($item->potongan),
                "uploaded" => $item->image,
                "oldUploaded" => $item->image,
            ];
        }
        

        foreach ($this->tukarTambahKurangData->metodePembayarans as $metode){
            $this->list_metode_pembayarans[] =  [
                'metode_pembayaran_id' => $metode["pivot"]["metode_pembayaran_id"],
                'amount' => $this->encodeCurrency($metode["pivot"]["amount"])
            ];
        }

        // initialize support data
        $pembayaranList = MetodePembayaran::get(['id','nama_metode']);
        foreach ($pembayaranList as $list){
            $this->payment_list[] = [
                'id' => $list->id,
                'name' => $list->nama_metode,
                'used' => false,
            ];
        }
        $this->customerList = Customer::pluck("nama","id");
        $this->type_pembayaran = $this->tukarTambahKurangData->payment_type;
        $this->jenis_emas = Category::pluck('type_emas','id');
        $this->metode_pembayarans = $pembayaranList;
        $this->catatan = $this->tukarTambahKurangData->note;

        foreach (collect($this->list_metode_pembayarans)->pluck('metode_pembayaran_id')->toArray() as $arr){
            foreach ($this->payment_list as $index => $d){
                if ($d['id'] === $arr){
                    $this->payment_list[$index]['used'] = true; // update array
                }
            }
        }
    }

    public function updated($propertyName)
    {
        $this->validateOnly($propertyName);
    }

    public function calculateGrandTotal()
    {
        $grandTotal = 0;
        $tmpGrandTotalTukarTambah = 0;
        foreach ($this->trx as $trx){
            foreach ($trx["items"] as $item){
                $grandTotal += ((float) $item["berat"] * (float) $this->decodeCurrency($item["harga_sekarang"])) - (float) $this->decodeCurrency($item["potongan"]);
            }
        }
        if ($this->typetukarTambah == 1){ // tukar tambah
            foreach ($this->invoiceTukarTambahKurangData as $trx){
                foreach ($trx["items"] as $item){
                    $tmpGrandTotalTukarTambah += ((float) $item["berat"] * (float) $this->decodeCurrency($item["harga"])) + (float) $this->decodeCurrency($item["ongkos"]);
                }
            }
            $this->grandTotal = $tmpGrandTotalTukarTambah + $grandTotal;
        }else{
            $this->grandTotal = $grandTotal;
        }
    }

    public function calculateTukarTambahKurang()
    {
        $this->calculateGrandTotal();
        $tmpGrandTotalTukarTambah = 0;
        foreach ($this->invoiceTukarTambahKurangData as $trx){
            foreach ($trx["items"] as $item){
                $tmpGrandTotalTukarTambah += ((float) $item["berat"] * (float) $this->decodeCurrency($item["harga"])) + (float) $this->decodeCurrency($item["ongkos"]);
            }
        }
        if ($this->typetukarTambah == 1){ // ini untuk tukar tambah 597,000 - 0
            $grandTotalBarangPenjualan = 0;
            foreach ($this->trx as $trx){
                foreach ($trx["items"] as $item){
                    $grandTotalBarangPenjualan += ((float) $item["berat"] * (float) $this->decodeCurrency($item["harga_sekarang"])) - (float) $this->decodeCurrency($item["potongan"]);
                }
            }
            $tmpGr = $tmpGrandTotalTukarTambah - $grandTotalBarangPenjualan;
        }else{ // ini untuk tukar kurang
            $tmpGr= $this->grandTotal - $tmpGrandTotalTukarTambah;
        }

        $this->grandTotalTukarTambah = $tmpGr;
        $this->tempSisaPembayaran = $tmpGr;
        $this->calculateSisaPembayaran();
    }

    public function calculateSisaPembayaran()
    {
        $this->calculateGrandTotal();
        $totalMetodePembayaran =  0;
        foreach ($this->list_metode_pembayarans as $d){
            $totalMetodePembayaran += $this->decodeCurrency($d['amount']) == '' ? 0 : $this->decodeCurrency($d['amount']);
        }
        $this->tempSisaPembayaran = (float) $totalMetodePembayaran - $this->grandTotalTukarTambah;
    }

    public function searchIndexAndUpdatePaymentListByMetodeId($id)
    {
        foreach ($this->payment_list as $index => $d){
            if ($d['id'] == $id){
                $this->payment_list[$index]['used'] = !$this->payment_list[$index]['used'];// update array
                return;
            }
        }
    }

    public function updatingTypePembayaran($value)
    {
        if($value == 1 && $this->type_pembayaran == 2){
            $this->tempSisaPembayaran = $this->grandTotal;
        }else{
            $this->calculateSisaPembayaran();
        }
    }

    public function updatedTypeTukarTambah()
    {
        $this->calculateTukarTambahKurang();
    }

    public function updatedListMetodePembayarans($value, $index)
    {
        if(str_contains($index, "amount")){
            $this->calculateSisaPembayaran();
        }
    }

    public function updatingListMetodePembayarans($value, $index)
    {
        if (str_contains($index, "metode_pembayaran_id")){
            $ex = explode('.', $index);
            $this->searchIndexAndUpdatePaymentListByMetodeId($this->list_metode_pembayarans[$ex[0]]['metode_pembayaran_id']); // used = true
            if ($value != ''){
                $this->searchIndexAndUpdatePaymentListByMetodeId($value); // used = true\
            }
        }
    }

    public function onClickCreateMetodePembayaran(){
        $this->list_metode_pembayarans[] =  [
            'metode_pembayaran_id' => '',
            'amount' => 0
        ];
    }

    public function onClickRemoveMetodePembayaran($index)
    {
        $this->searchIndexAndUpdatePaymentListByMetodeId($this->list_metode_pembayarans[$index]["metode_pembayaran_id"]);
        $this->tempSisaPembayaran += (float) $this->list_metode_pembayarans[$index]["amount"];
        unset($this->list_metode_pembayarans[$index]);
        $this->list_metode_pembayarans = array_values($this->list_metode_pembayarans);
        $this->calculateSisaPembayaran();
    }

    public function save()
    {
        $tempCustomer = null;
        // if new customer
        if($this->createCustomer){
            $tempCustomer = Customer::create([
                "nama" => $this->customer["nama"],
                "email" => $this->customer["email"],
                "nomor_hp" => $this->customer["phone"],
            ]);
        }else{ // already customer
            $tempCustomer["id"] = $this->customer["id"];
        }

        $tukarTambahKurang = TukarTambahKurang::findOrFail($this->tukarTambahKurangData->id);
        $tukarTambahKurang->update([ // create invoice
            "total_kuitansi" => $this->totalKuitansi,
            "customer_id" => $tempCustomer["id"],
            "grand_total" => $this->grandTotal,
            "type" => $this->typetukarTambah,
            "note" => $this->catatan,
            "payment_type" => $this->type_pembayaran,
            "totalPay" => $this->grandTotalTukarTambah
        ]);

        $tmpTukarTambah = $tukarTambahKurang->tukarTambahKurangItems()->pluck("id")->toArray();

        foreach ($this->trx as $index => $trx){ // loop items
            foreach ($trx["items"] as $item){
                $data = [
                    "tukar_tambah_kurang_id" => $tukarTambahKurang->id,
                    "category_id" => $item["jenis_id"],
                    "stock_id" => $item["produk_id"],
                    "varian" => $item["varian"],
                    "type" => 1, // 1 = default, 2= invoice
                    "noKuitansi" => $index+1,
                    "jenisEmas" => Category::findOrFail($item["jenis_id"])->type_emas,
                    "namaBarang" => $item["nama_produk"],
                    "berat" => $item["berat"],
                    "kadar" => $item["kadar"],
                    "hargaPerGram" => $this->decodeCurrency($item["harga"]),
                    "hargaPerGramBaru" => $this->decodeCurrency($item["harga_sekarang"]),
                    "potongan" => $item["potongan"] ? $this->decodeCurrency($item["potongan"]) : 0,
                    "total" => ((float) $item["berat"] * (float) $this->decodeCurrency($item["harga_sekarang"])) - (float) $this->decodeCurrency($item["potongan"]),
                    "image" => $item['uploaded']
                ];

                if (!is_string($item["uploaded"]) && is_object($item["uploaded"])){
                    $data['image'] = $item["uploaded"]->storePublicly('foto_barang_tukar_tambah_kurang','local_public');
                    if (!empty($item["oldUploaded"])){
                        unlink(public_path($item["oldUploaded"]));
                    }
                }

                TukarTambahKurangItem::create($data);
            }
        }

        foreach ($this->invoiceTukarTambahKurangData as $index => $inv){ // loop invoice data items
            foreach ($inv["items"] as $item) {
                $data = [
                    "tukar_tambah_kurang_id" => $tukarTambahKurang->id,
                    "category_id" => $item["jenis_id"],
                    "stock_id" => $item["produk_id"],
                    "varian" => $item["varian"],
                    "type" => 2, // 1 = default, 2= invoice
                    "noKuitansi" => $index+1,
                    "jenisEmas" => Category::findOrFail($item["jenis_id"])->type_emas,
                    "namaBarang" => $item["nama_produk"],
                    "berat" => $item["berat"],
                    "kadar" => $item["kadar"],
                    "hargaPerGram" => $this->decodeCurrency($item["harga"]),
                    "hargaPerGramBaru" => 0,
                    "potongan" => $item["ongkos"] ? $this->decodeCurrency($item["ongkos"]) : 0,
                    "total" => ((float)$item["berat"] * (float)$this->decodeCurrency($item["harga"])) + (float)$this->decodeCurrency($item["ongkos"]),
                    "image" => $item['uploaded']
                ];

                if (!is_string($item["uploaded"]) && is_object($item["uploaded"])){
                    $data['image'] = $item["uploaded"]->storePublicly('foto_barang_tukar_tambah_kurang','local_public');
                    if (!empty($item["oldUploaded"])){
                        unlink(public_path($item["oldUploaded"]));
                    }
                }

                TukarTambahKurangItem::create($data);
            }
        }

        // delete by list of id
        TukarTambahKurangItem::whereIn("id", $tmpTukarTambah)->delete();

        // add comment before update
        $comment = new UpdatedDataReason();
        $comment->reason = $this->alasan;
        $tukarTambahKurang->comments()->save($comment);

        if($this->type_pembayaran == 1){ // single payment
            $tukarTambahKurang->metodePembayarans()->sync([
                [
                    'metode_pembayaran_id' => $this->list_metode_pembayarans[0]["metode_pembayaran_id"],
                    'amount' => $this->grandTotalTukarTambah
                ]
            ]);
        }else{ // multi payment
            $tempMetode = [];
            foreach ($this->list_metode_pembayarans as $d){
                $tempMetode[(int) $d['metode_pembayaran_id']] = [
                    'amount' => $this->decodeCurrency($d['amount']) == '' ? 0 : $this->decodeCurrency($d['amount']),
                ];
            }
            $tukarTambahKurang->metodePembayarans()->sync($tempMetode); // assign to pivot table penjualan_metode_pembayaran
        }

        // redirect to pembelian
        return redirect()->route('admin.tukarTambahKurang.invoice',['tukarTambahKurang' => $tukarTambahKurang->id])->with("success","data saved");  // redirect to sales
    }

    public function updatedTrx()
    {
        $this->calculateTukarTambahKurang();
    }

    public function updatingTrx($value, $index)
    {
        $d = explode('.',$index);
        if (str_contains($index,'jenis_id') && $value == ""){
            $this->trx[$d[0]]['items'][$d[2]] = [
                "jenis_id" => "",
                "nama_jenis" => "",
                "varian" => "",
                "produk_id" => "",
                "nama_produk" => "",
                "berat" => 0,
                "kadar" => 0,
                "harga_sekarang" => $this->encodeCurrency(0),
                "potongan" => $this->encodeCurrency(0),
                "harga" => $this->encodeCurrency(0),
                "uploaded" => null,
            ];
        }
        $this->calculateTukarTambahKurang();
    }

    public function updatingInvoiceTukarTambahKurangData($value, $index)
    {
        $d = explode('.',$index);
        if (str_contains($index,'jenis_id') && $value == ""){
            $this->invoiceTukarTambahKurangData[$d[0]]['items'][$d[2]] = [
                "jenis_id" => "",
                "nama_jenis" => "",
                "varian" => "",
                "produk_id" => "",
                "nama_produk" => "",
                "berat" => 0,
                "kadar" => 0,
                "harga" => $this->encodeCurrency(0),
                "ongkos" => $this->invoiceTukarTambahKurangData[$d[0]]['items'][$d[2]]['ongkos'],
                "uploaded" => null,
            ];
        }
        $this->calculateTukarTambahKurang();
    }

    public function updatedInvoiceTukarTambahKurangData()
    {
        $this->calculateTukarTambahKurang();
    }

    public function updatedCreateCustomer($value)
    {
        // reset when return to false && id not 0
        if (!$value || $this->customer["id"] !== 0){
            $this->customer = [
                "id" => 0,
                "nama" => "",
                "phone" => "",
                "email" => "",
            ];
        }
    }

    public function updatedCustomerId($value)
    {
        // search customer by id
        if ($this->customer["id"] !== 0 && $this->createCustomer === false && $value !== ''){
            $customerData = Customer::findOrFail($this->customer["id"]);
            $this->customer["nama"] = $customerData->nama;
            $this->customer["email"] = $customerData->email;
            $this->customer["phone"] = $customerData->nomor_hp;
        }
    }

    public function onChangeProdukId($value, $kwitansi, $index)
    {
        if ($value[4] == 2){
            $this->invoiceTukarTambahKurangData[$kwitansi]["items"][$index]["produk_id"] = $value[0];
            $this->invoiceTukarTambahKurangData[$kwitansi]["items"][$index]["nama_produk"] = $value[1];
            $this->invoiceTukarTambahKurangData[$kwitansi]["items"][$index]["berat"] = $value[2];
            $this->invoiceTukarTambahKurangData[$kwitansi]["items"][$index]["kadar"] = $value[3];
        }else{
            $this->trx[$kwitansi]["items"][$index]["produk_id"] = $value[0];
            $this->trx[$kwitansi]["items"][$index]["nama_produk"] = $value[1];
        }
    }

    public function onChangeTotalItemKwitansi($value, $kwitansi, $index)
    {
        $this->trx[$kwitansi]["items"][$index]["total"] = $value;
    }

    public function addRow($index, $type = null)
    {
        if ($type == 'invoice'){
            $this->invoiceTukarTambahKurangData[$index]["items"][] = [
                "jenis_id" => '',
                "nama_jenis" => '',
                "varian" => '',
                "produk_id" => '',
                "nama_produk" => '',
                "berat" => 0,
                "kadar" => 0,
                "harga" => 0,
                "harga_sekarang" => 0,
                "ongkos" => 0,
                "uploaded" => null
            ];
        }else{
            $this->trx[$index]["items"][] = [
                "jenis_id" => '',
                "nama_jenis" => '',
                "varian" => '',
                "produk_id" => '',
                "nama_produk" => '',
                "berat" => 0,
                "kadar" => 0,
                "harga" => 0,
                "harga_sekarang" => 0,
                "potongan" => 0,
                "uploaded" => null
            ];
        }
    }

    public function removeTrxRow($index)
    {
        unset($this->invoiceTukarTambahKurangData[$index]);
        $this->invoiceTukarTambahKurangData = array_values($this->invoiceTukarTambahKurangData);
        $this->trxKuitansi--;
        $this->calculateTukarTambahKurang();
    }

    public function deleteRow($indexKuitansi, $indexRow, $type = null)
    {
        if ($type == 'invoice'){
            unset($this->invoiceTukarTambahKurangData[$indexKuitansi]["items"][$indexRow]);
            $this->invoiceTukarTambahKurangData[$indexKuitansi]["items"] = array_values($this->invoiceTukarTambahKurangData[$indexKuitansi]["items"]);
            $this->calculateTukarTambahKurang();
        }else{
            unset($this->tukarTambahKurangData[$indexKuitansi-1]["items"][$indexRow]);
            $this->tukarTambahKurangData[$indexKuitansi-1]["items"] = array_values($this->tukarTambahKurangData[$indexKuitansi-1]["items"]);
        }
    }

    public function hitungSubTotal($indexKuitansi)
    {
        $subTotal = 0;
        foreach ($this->trx[$indexKuitansi-1]["items"] as $item){
            $subTotal += ((float) $item["berat"] * (float) $this->decodeCurrency($item["harga_sekarang"])) - (float) $this->decodeCurrency($item["potongan"]);
        }
        $this->trx[$indexKuitansi-1]["sub_total"] = $subTotal;
    }

    public function updatingTrxKuitansi($value)
    {
        if ($value < 1 || $value == ""){
            $this->invoiceTukarTambahKurangData = [];
            $this->invoiceTukarTambahKurangData[] = [
                "sub_total" => 0,
                "items" => [
                    [
                        "jenis_id" => '',
                        "nama_jenis" => '',
                        "varian" => '',
                        "produk_id" => '',
                        "nama_produk" => '',
                        "berat" => $this->encodeCurrency(0),
                        "kadar" => $this->encodeCurrency(0),
                        "harga" => $this->encodeCurrency(0),
                        "ongkos" => $this->encodeCurrency(0),
                        "uploaded" => null
                    ]
                ]
            ];
            $this->calculateTukarTambahKurang();
            return;
        }

        if ($value <= $this->trxKuitansi){
            for ($i=$this->trxKuitansi-1; $i >= $value; $i--){
                unset($this->invoiceTukarTambahKurangData[$i]);
                $this->invoiceTukarTambahKurangData = array_values($this->invoiceTukarTambahKurangData);
            }
        }

        for ($i=count($this->invoiceTukarTambahKurangData); $i < $value; $i++){
            $this->invoiceTukarTambahKurangData[] = [
                "sub_total" => 0,
                "items" => [
                    [
                        "jenis_id" => '',
                        "nama_jenis" => '',
                        "varian" => '',
                        "produk_id" => '',
                        "nama_produk" => '',
                        "berat" => 0,
                        "kadar" => 0,
                        "harga" => 0,
                        "harga_sekarang" => 0,
                        "ongkos" => 0,
                        "uploaded" => null
                    ]
                ]
            ];
        }
    }

    public function render()
    {
        return view('livewire.tukarTambahKurang.editTukarTambahKurang');
    }
}
