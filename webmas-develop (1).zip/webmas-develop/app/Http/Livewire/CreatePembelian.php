<?php

namespace App\Http\Livewire;

use App\Http\Controllers\Traits\CurrencyTrait;
use App\Models\Category;
use App\Models\Customer;
use App\Models\MetodePembayaran;
use Livewire\Component;
use Haruncpi\LaravelIdGenerator\IdGenerator;
use App\Models\Pembelian;
use App\Models\PembelianItem;
use App\Models\Penjualan;
use Livewire\WithFileUploads;

class CreatePembelian extends Component
{
    use CurrencyTrait, WithFileUploads;

    protected $rules = [
//        'trx.*.sub_total' => 'required',
        'trx.*.items.*.jenis_id' => 'required',
        'trx.*.items.*.produk_id' => 'required',
        'trx.*.items.*.varian' => 'nullable',
        'trx.*.items.*.nama_produk' => 'required',
        'trx.*.items.*.berat' => 'required',
        'trx.*.items.*.kadar' => 'required',
        'trx.*.items.*.harga_sekarang' => 'required',
        'trx.*.items.*.harga' => 'required',
        'trx.*.items.*.potongan' => 'required',
        'trx.*.items.*.uploaded' => 'nullable|image',
    ];

    protected $messages = [
        'trx.*.items.*.uploaded.image' => 'File upload harus berupa gambar',
        'trx.*.items.*.jenis_id.required' => 'Field harus di isi',
        'trx.*.items.*.produk_id.required' => 'Field harus di isi',
        'trx.*.items.*.harga_sekarang.required' => 'Field harus di isi',
        'trx.*.items.*.harga.required' => 'Field harus di isi',
        'trx.*.items.*.potongan.required' => 'Field harus di isi',
    ];

    public $metode_pembayarans = []; // from database
    public $list_metode_pembayarans = [
        [
            'metode_pembayaran_id' => '',
            'amount' => 0
        ]
    ];
    public $tempSisaPembayaran = 0; // only for multi payment
    public $jenis_emas = [];
    public $payment_list = []; // unique for multi payment
    public $totalKuitansi = 1;
    public $grandTotal;
    public $nota = '';
    public $cekNota = false;
    public $isiNota = '';
    public $adaData = false;
    public $dataPembelian = [];
    public $catatan;
    public $trx = [
    ];

    public $type_pembayaran = 1;
    public $from = 1;
    public $createCustomer = false;
    public $customer = [
        "id" => 0,
        "nama" => "",
        "phone" => "",
        "email" => "",
    ];

    public $customerList = [];

    protected $listeners = ['onChangeProdukId', 'onChangeTotalItemKwitansi' => '$refresh'];

    public function mount()
    {
        $pembayaranList = MetodePembayaran::pluck('nama_metode', 'id');
        foreach ($pembayaranList as $index => $list){
            $this->payment_list[] = [
                'id' => $index,
                'name' => $list,
                'used' => false,
            ];
        }
        $this->customerList = Customer::pluck("nama","id");
        $this->jenis_emas =  Category::pluck('type_emas','id');
        $this->metode_pembayarans = $pembayaranList;
    }

    public function updated($propertyName)
    {
        $this->validateOnly($propertyName);
    }

    public function calculateGrandTotal()
    {
        $grandTotal = 0;
        foreach ($this->trx as $trx){
            foreach ($trx["items"] as $item){
                $grandTotal += ((float) $item["berat"] * (float) $this->decodeCurrency($item["harga_sekarang"])) - (float) $this->decodeCurrency($item["potongan"]);
            }
        }
        $this->grandTotal = $grandTotal;
    }

    public function calculateSisaPembayaran()
    {
        $this->calculateGrandTotal();
        $totalMetodePembayaran =  0;
        foreach ($this->list_metode_pembayarans as $d){
            $totalMetodePembayaran += $this->decodeCurrency($d['amount']) == '' ? 0 : $this->decodeCurrency($d['amount']);
        }
        $this->tempSisaPembayaran = (float) $totalMetodePembayaran - $this->grandTotal;
    }

    public function searchIndexAndUpdatePaymentListByMetodeId($id)
    {
        foreach ($this->payment_list as $index => $d){
            if ($d['id'] == $id){
                $this->payment_list[$index]['used'] = !$this->payment_list[$index]['used'];// update array
                return;
            }
        }
    }

    public function changeFromIni(){
        $this->from = 1;
        if(count($this->trx) == 0 ){
            $this->cekNota = false;
        }
    }
    
    public function changeFromLain(){
        $this->from = 2;
        $this->cekNota = true;
        if(count($this->trx) == 0 ){
            $this->trx = [
                [
                    "sub_total" => 0,
                    "items" => [
                        [
                            "jenis_id" => '',
                            "nama_jenis" => '',
                            "varian" => '',
                            "produk_id" => '',
                            "nama_produk" => '',
                            "berat" => 0,
                            "kadar" => 0,
                            "harga" => $this->encodeCurrency(0),
                            "harga_sekarang" => $this->encodeCurrency(0),
                            "potongan" => $this->encodeCurrency(0),
                            "uploaded" => null
                        ]
                    ]
                ]
            ];
        }
    }

    public function updatingTypePembayaran($value)
    {
        if($value == 1 && $this->type_pembayaran == 2){
            $this->tempSisaPembayaran = $this->grandTotal;
//            $this->list_metode_pembayarans = [ // reset to default
//                [
//                    'metode_pembayaran_id' => '',
//                    'amount' => 0
//                ]
//            ];
        }else{
            $this->calculateSisaPembayaran();
        }
    }

    public function updatedListMetodePembayarans($value, $index)
    {
        if(str_contains($index, "amount")){
            $this->calculateSisaPembayaran();
        }
    }

    public function updatingListMetodePembayarans($value, $index)
    {
        if (str_contains($index, "metode_pembayaran_id")){
            $ex = explode('.', $index);
            $this->searchIndexAndUpdatePaymentListByMetodeId($this->list_metode_pembayarans[$ex[0]]['metode_pembayaran_id']); // used = true
            if ($value != ''){
                $this->searchIndexAndUpdatePaymentListByMetodeId($value); // used = true\
            }
        }
    }

    public function onClickCreateMetodePembayaran(){
         $this->list_metode_pembayarans[] =  [
             'metode_pembayaran_id' => '',
             'amount' => 0
         ];
    }

    public function onClickRemoveMetodePembayaran($index)
    {
        $this->tempSisaPembayaran += (float) $this->list_metode_pembayarans[$index]["amount"];
        unset($this->list_metode_pembayarans[$index]);
        $this->list_metode_pembayarans = array_values($this->list_metode_pembayarans);
    }

    public function cekNotaBtn()
    {
        $this->cekNota = true;
        $this->trx = [];
        $data = Penjualan::with("customer")->where('noTrx', '=', trim($this->nota))->get()->first();

        if(!is_null($data) && $data->count() > 0) {
            $this->customer = [
                "id" => $data->customer->id,
                "nama" => $data->customer->nama,
                "phone" => $data->customer->nomor_hp,
                "email" => $data->customer->email,
            ];
            // $this->totalKuitansi = $data->total_kuitansi;
            $this->grandTotal = $data->grand_total;
            $this->isiNota = "Nota ditemukan";
            $this->adaData = true;
            $this->totalKuitansi = $data->totalKuitansi;
            foreach ($data["penjualanItems"] as $item){
                $this->trx[$item->noKuitansi-1]["items"][] = [
                    "jenis_id" => $item->category_id,
                    "nama_jenis" => $item->jenisEmas,
                    "varian" => $item->varian,
                    "produk_id" => $item->stock_id,
                    "nama_produk" => $item->namaBarang,
                    "berat" => $item->berat,
                    "kadar" => $item->kadar,
                    "harga" => $this->encodeCurrency($item->hargaPerGram),
                    "harga_sekarang" => $this->encodeCurrency(0),
                    "potongan" => $this->encodeCurrency(0),
                    "uploaded" => null
                ];
            }
        } else {
            $this->isiNota = "Nota tidak ditemukan";
            $this->trx = [
                [
                    "sub_total" => 0,
                    "items" => [
                        [
                            "jenis_id" => '',
                            "nama_jenis" => '',
                            "varian" => '',
                            "produk_id" => '',
                            "nama_produk" => '',
                            "berat" => 0,
                            "kadar" => 0,
                            "harga" => $this->encodeCurrency(0),
                            "harga_sekarang" => $this->encodeCurrency(0),
                            "potongan" => $this->encodeCurrency(0),
                            "uploaded" => null
                        ]
                    ]
                ]
            ];
        }
    }

    public function save()
    {
        $validatedData = $this->validate();
        if($this->from == 2){
            $this->createCustomer = true;
        }

        $tempCustomer = null;
        // if new customer
        if($this->createCustomer){
            $tempCustomer = Customer::create([
                "nama" => $this->customer["nama"],
                "email" => $this->customer["email"],
                "nomor_hp" => $this->customer["phone"],
            ]);
        }else{ // already customer
            $tempCustomer["id"] = $this->customer["id"];
        }

        // generate id invoice
        $noTrx = IdGenerator::generate(['field' => 'noTrx','table' => 'tb_pembelian', 'length' => 13, 'prefix' => date('Ymd')."-"]);

        $from = 0;

        $tempPembelian = Pembelian::create([ // create invoice
            "noTrx" => $noTrx,
            "total_kuitansi" => $this->totalKuitansi,
            "customer_id" => $tempCustomer["id"],
            "grand_total" => $this->grandTotal,
            "nota" => $this->nota,
            "note" => $this->catatan,
            "from" => $from,
            "payment_type" => $this->type_pembayaran,
        ]);

        $no = 1;
        foreach ($validatedData['trx'] as $trx){
            foreach ($trx["items"] as $item){
                $data = [
                    "pembelian_id" => $tempPembelian->id,
                    "category_id" => $item["jenis_id"],
                    "varian" => $item["varian"],
                    "stock_id" => $item["produk_id"],
                    "no" => $no,
                    "jenis_emas" => Category::findOrFail($item["jenis_id"])->type_emas,
                    "nama_barang" => $item["nama_produk"],
                    "berat" => $item["berat"],
                    "kadar" => $item["kadar"],
                    "harga_pergram" => $this->decodeCurrency($item["harga"]),
                    "harga_sekarang" => $this->decodeCurrency($item["harga_sekarang"]),
                    "potongan" => $this->decodeCurrency($item["potongan"]),
                    "total" => ((float) $item["berat"] * (float) $this->decodeCurrency($item["harga_sekarang"])) - (float) $this->decodeCurrency($item["potongan"]),
                ];

                if ($item["uploaded"] !== null){
                    $data['images'] = $item["uploaded"]->storePublicly('foto_barang_pembelian','local_public');
                }

                PembelianItem::create($data);
            }
            $no++;
        }
        if($this->type_pembayaran == 1){ // single payment
            $tempPembelian->metodePembayarans()->attach([
                [
                    'metode_pembayaran_id' => $this->list_metode_pembayarans[0]["metode_pembayaran_id"],
                    'amount' => $this->grandTotal
                ]
            ]);
        }else{ // multi payment
            $tempMetode = [];
            foreach ($this->list_metode_pembayarans as $d){
                $tempMetode[(int) $d['metode_pembayaran_id']] = [
                    'amount' => $this->decodeCurrency($d['amount']) == '' ? 0 : $this->decodeCurrency($d['amount']),
                ];
            }
            $tempPembelian->metodePembayarans()->attach($tempMetode); // assign to pivot table penjualan_metode_pembayaran
        }

        if ($this->adaData && $this->nota !== ''){ // delete penjualan
            Penjualan::where('noTrx', trim($this->nota))->first()->delete();
        }
        // redirect to pembelian
        return redirect()->route('admin.pembelian.index')->with("success","data berhasil disimpan");
    }

    public function updatingTrx($value, $index)
    {
        $d = explode('.',$index);
        if (str_contains($index,'jenis_id') && $value == ""){
            $this->trx[$d[0]]['items'][$d[2]] = [
                "jenis_id" => "",
                "nama_jenis" => "",
                "varian" => "",
                "produk_id" => "",
                "nama_produk" => "",
                "berat" => 0,
                "kadar" => 0,
                "harga" => $this->encodeCurrency(0),
                "harga_sekarang" => $this->trx[$d[0]]['items'][$d[2]]['harga_sekarang'],
                "potongan" => $this->trx[$d[0]]['items'][$d[2]]['potongan'],
                "uploaded" => null,
            ];
        }
        $this->calculateSisaPembayaran();
    }

    public function updatedTrx($value, $index)
    {
        $this->calculateSisaPembayaran();
    }

    public function updatedCreateCustomer($value)
    {
        // reset when return to false && id not 0
        if (!$value || $this->customer["id"] !== 0){
            $this->customer = [
                "id" => 0,
                "nama" => "",
                "phone" => "",
                "email" => "",
            ];
        }
    }

    public function updatedCustomerId($value)
    {
        // search customer by id
        if ($this->customer["id"] !== 0 && $this->createCustomer === false && $value !== ''){
            $customerData = Customer::findOrFail($this->customer["id"]);
            $this->customer["nama"] = $customerData->nama;
            $this->customer["email"] = $customerData->email;
            $this->customer["phone"] = $customerData->nomor_hp;
        }
    }

    public function onChangeProdukId($value, $kwitansi, $index)
    {
        $this->trx[$kwitansi]["items"][$index]["produk_id"] = $value[0];
        $this->trx[$kwitansi]["items"][$index]["nama_produk"] = $value[1];
        $this->trx[$kwitansi]["items"][$index]["berat"] = $value[2];
        $this->trx[$kwitansi]["items"][$index]["kadar"] = $value[3];
    }

    public function onChangeTotalItemKwitansi($value, $kwitansi, $index)
    {
        $this->trx[$kwitansi]["items"][$index]["total"] = $value;
    }
    
    public function addRow($index)
    {
        $this->trx[$index]["items"][] = [
            "jenis_id" => '',
            "nama_jenis" => '',
            "varian" => '',
            "produk_id" => '',
            "nama_produk" => '',
            "berat" => 0,
            "kadar" => 0,
            "harga" => $this->encodeCurrency(0),
            "harga_sekarang" => $this->encodeCurrency(0),
            "potongan" => $this->encodeCurrency(0),
            "uploaded" => null
        ];
    }

    public function removeTrxRow($index)
    {
        unset($this->trx[$index]);
        $this->trx = array_values($this->trx);
        $this->totalKuitansi--;
        $this->calculateGrandTotal();
    }

    public function deleteRow($indexKuitansi, $indexRow)
    {
        unset($this->trx[$indexKuitansi-1]["items"][$indexRow]);
        $this->trx[$indexKuitansi-1]["items"] = array_values($this->trx[$indexKuitansi-1]["items"]);
        $this->calculateGrandTotal();
    }

    public function hitungSubTotal($indexKuitansi)
    {
        $subTotal = 0;
        foreach ($this->trx[$indexKuitansi-1]["items"] as $item){
            $subTotal += ((float) $item["berat"] * (float) $this->decodeCurrency($item["harga_sekarang"])) + (float) $this->decodeCurrency($item["potongan"]);
        }
        $this->trx[$indexKuitansi-1]["sub_total"] = $subTotal;
    }

    public function updatingTotalKuitansi($value)
    {
        if ($value < 1 || $value == ""){
            $this->trx = [];
            $this->trx[] = [
                "sub_total" => 0,
                "items" => [
                    [
                        "jenis_id" => '',
                        "nama_jenis" => '',
                        "varian" => '',
                        "produk_id" => '',
                        "nama_produk" => '',
                        "berat" => 0,
                        "kadar" => 0,
                        "harga" => $this->encodeCurrency(0),
                        "harga_sekarang" => $this->encodeCurrency(0),
                        "potongan" => $this->encodeCurrency(0),
                        "uploaded" => null
                    ]
                ]
            ];
            $this->calculateSisaPembayaran();
            return;
        }

        if ($value <= $this->totalKuitansi){
            for ($i=$this->totalKuitansi-1; $i >= $value; $i--){
               unset($this->trx[$i]);
               $this->trx = array_values($this->trx);
            }
        }

        for ($i=count($this->trx); $i < $value; $i++){
            $this->trx[] = [
                "sub_total" => 0,
                "items" => [
                    [
                        "jenis_id" => '',
                        "nama_jenis" => '',
                        "varian" => '',
                        "produk_id" => '',
                        "nama_produk" => '',
                        "berat" => 0,
                        "kadar" => 0,
                        "harga" => $this->encodeCurrency(0),
                        "harga_sekarang" => $this->encodeCurrency(0),
                        "potongan" => $this->encodeCurrency(0),
                        "uploaded" => null
                    ]
                ]
            ];
        }
    }

    public function render()
    {
        return view('livewire.create-pembelian');
    }
}
