<?php

namespace App\Http\Livewire;

use App\Http\Controllers\Traits\CurrencyTrait;
use App\Models\Category;
use App\Models\Customer;
use App\Models\MetodePembayaran;
use App\Models\Pemesanan;
use App\Models\PemesananItem;
use App\Models\UpdatedDataReason;
use Haruncpi\LaravelIdGenerator\IdGenerator;
use Livewire\Component;
use App\Models\Stock;
use Livewire\WithFileUploads;

class EditPemesanan extends Component
{
    use CurrencyTrait, WithFileUploads;

    public $metode_pembayarans = [];
    public $jenis_emas = [];
    public $payment_list = [];

    public $list_metode_pembayarans = [];
    public $totalKuitansi = 1;
    public $grandTotal;
    public $totalPembayaran;
    public $sisaPelunasan = 0;
    public $trx = [];
    public $tempSisaPembayaran = 0;

    public $type_pembayaran = 1;
    public $alasan = "";
    public $catatan;

    public $createCustomer = false;
    public $customer = [
        "id" => 0,
        "nama" => "",
        "phone" => "",
        "email" => "",
    ];

    public $pemesananData;
    public $customerList = [];
    public $preview = false;

    protected $listeners = ['onChangeProdukId', 'onChangeTotalItemKwitansi' => '$refresh'];

    public function mount()
    {
        $customer = $this->pemesananData->customer;
        $this->customer["id"] = $customer->id;
        $this->customer["nama"] = $customer->nama;
        $this->customer["phone"] = $customer->nomor_hp;
        $this->customer["email"] = $customer->email;

        $this->totalKuitansi = $this->pemesananData->total_kuitansi;
        $this->grandTotal = $this->pemesananData->grand_total;
        $this->sisaPelunasan = $this->pemesananData->sisa_pelunasan;
        $this->catatan = $this->pemesananData->note;
        
        $this->checkPreview();
        
        $totalPembayaran = 0;
        foreach ($this->pemesananData->pemesananItems as $item){
            $this->trx[$item->no-1]["items"][] = [
                "jenis_id" => $item->category_id,
                "nama_jenis" => $item->jenis_emas,
                "varian" => $item->varian,
                "produk_id" => $item->stock_id,
                "nama_produk" => $item->nama_barang,
                "berat" => $item->berat,
                "kadar" => $item->kadar,
                "harga" => $this->encodeCurrency($item->harga_pergram),
                "ongkos" => $this->encodeCurrency($item->ongkos),
                "down_payment" => $this->encodeCurrency($item->payment),
                "selesai_pesanan" => $item->selesai_pesanan,
                "uploaded" => $item->images,
                "oldUploaded" => $item->images,
            ];
            $totalPembayaran += $item->payment;
        }
        $this->totalPembayaran = $totalPembayaran;
        
        foreach ($this->pemesananData->metodePembayarans as $metode){
            $this->list_metode_pembayarans[] =  [
                'metode_pembayaran_id' => $metode["pivot"]["metode_pembayaran_id"],
                'amount' => $this->encodeCurrency($metode["pivot"]["amount"])
            ];
        }

        $pembayaranList = MetodePembayaran::get(['id','nama_metode']);
        foreach ($pembayaranList as $list){
            $this->payment_list[] = [
                'id' => $list->id,
                'name' => $list->nama_metode,
                'used' => false,
            ];
        }
        $this->customerList = Customer::pluck("nama","id");
        $this->type_pembayaran = $this->pemesananData->payment_type;
        $this->jenis_emas = Category::pluck('type_emas','id');
        $this->metode_pembayarans = $pembayaranList;

        foreach (collect($this->list_metode_pembayarans)->pluck('metode_pembayaran_id')->toArray() as $arr){
            foreach ($this->payment_list as $index => $d){
                if ($d['id'] === $arr){
                    $this->payment_list[$index]['used'] = true;
                }
            }
        }
    }

    public function calculateGrandTotal()
    {
        $grandTotal = 0;
        foreach ($this->trx as $trx){
            foreach ($trx["items"] as $item){
                $grandTotal += ((float) $item["berat"] * (float) $this->decodeCurrency($item["harga"])) + (float) $this->decodeCurrency($item["ongkos"]);
            }
        }
        $this->grandTotal = $grandTotal;
    }

    public function calculateTotalPembayaran()
    {
        $totalPembayaran = 0;
        foreach ($this->trx as $trx){
            foreach ($trx["items"] as $item){
                $totalPembayaran += (float) $this->decodeCurrency($item["down_payment"]);
            }
        }
        $this->totalPembayaran = $totalPembayaran;
    }
    
    public function calculateSisaPelunasan()
    {
        $sisaPelunasan = $this->grandTotal;
        foreach ($this->trx as $trx){
            foreach ($trx["items"] as $item){
                $sisaPelunasan -= (float) $this->decodeCurrency($item["down_payment"]);
            }
        }
        $this->sisaPelunasan = $sisaPelunasan;
    }

    public function calculateSisaPembayaran()
    {
        $this->calculateGrandTotal();
        $this->calculateTotalPembayaran();
        $this->calculateSisaPelunasan();
        $totalMetodePembayaran =  0;
        foreach ($this->list_metode_pembayarans as $d){
            $totalMetodePembayaran += $this->decodeCurrency($d['amount']) == '' ? 0 : $this->decodeCurrency($d['amount']);
        }
        $this->tempSisaPembayaran = (float) $totalMetodePembayaran - $this->totalPembayaran;

        $this->checkPreview();
    }

    public function searchIndexAndUpdatePaymentListByMetodeId($id)
    {
        foreach ($this->payment_list as $index => $d){
            if ($d['id'] == $id){
                $this->payment_list[$index]['used'] = !$this->payment_list[$index]['used'];
                return;
            }
        }
    }

    public function updatingTypePembayaran($value)
    {
        if($value == 1 && $this->type_pembayaran == 2){
            $this->tempSisaPembayaran = $this->totalPembayaran;
        } else {
            $this->calculateSisaPembayaran();
        }
    }

    public function updatedListMetodePembayarans($value, $index)
    {
        if(str_contains($index, "amount")){
            $this->calculateSisaPembayaran();
        }
    }

    public function updatingListMetodePembayarans($value, $index)
    {
        if (str_contains($index, "metode_pembayaran_id")){
            $ex = explode('.', $index);
            $this->searchIndexAndUpdatePaymentListByMetodeId($this->list_metode_pembayarans[$ex[0]]['metode_pembayaran_id']);
            if ($value != ''){
                $this->searchIndexAndUpdatePaymentListByMetodeId($value);
            }
        }
    }

    public function onClickCreateMetodePembayaran(){
        $this->list_metode_pembayarans[] =  [
            'metode_pembayaran_id' => '',
            'amount' => 0
        ];

        $this->checkPreview();
   }

   public function onClickRemoveMetodePembayaran($index)
   {
       $this->tempSisaPembayaran += (float) $this->list_metode_pembayarans[$index]["amount"];
       unset($this->list_metode_pembayarans[$index]);
       $this->list_metode_pembayarans = array_values($this->list_metode_pembayarans);

       $this->checkPreview();
   }

    public function save()
    {
        $tempCustomer = null;
        if($this->createCustomer){
            $tempCustomer = Customer::create([
                "nama" => $this->customer["nama"],
                "email" => $this->customer["email"],
                "nomor_hp" => $this->customer["phone"],
            ]);
        }else{
            $tempCustomer["id"] = $this->customer["id"];
        }

        $pemesanan = Pemesanan::findOrFail($this->pemesananData->id);
        $pemesanan->update([
            "total_kuitansi" => $this->totalKuitansi,
            "customer_id" => $tempCustomer["id"],
            "grand_total" => $this->grandTotal,
            "sisa_pelunasan" => $this->sisaPelunasan,
            "payment_type" => $this->type_pembayaran,
            "note" => $this->catatan
        ]);

        $tmpPemesananItem = $pemesanan->pemesananItems()->pluck("id")->toArray();
        $tmpStock = $pemesanan->pemesananItems()->pluck("stock_id")->toArray();

        // foreach ($tmpStock as $stock_id){
        //     Stock::findOrFail($stock_id)->increment('jumlah_product');
        // }
        
        $no = 1;
        foreach ($this->trx as $trx){
            foreach ($trx["items"] as $item){
                $data = [
                    "pemesanan_id" => $pemesanan->id,
                    "category_id" => $item["jenis_id"],
                    "varian" => $item["varian"],
                    "no" => $no,
                    "jenis_emas" => Category::findOrFail($item["jenis_id"])->type_emas,
                    "nama_barang" => $item["nama_produk"],
                    "berat" => $item["berat"],
                    "kadar" => $item["kadar"],
                    "harga_pergram" => $this->decodeCurrency($item["harga"]),
                    "ongkos" => $this->decodeCurrency($item["ongkos"]),
                    "payment" => $this->decodeCurrency($item["down_payment"]),
                    "selesai_pesanan" => $item["selesai_pesanan"],
                    "total" => ((float) $item["berat"] * (float) $this->decodeCurrency($item["harga"])) + (float) $this->decodeCurrency($item["ongkos"]),
                    "images" => $item['uploaded']
                ];
                if (gettype($item["uploaded"]) !== 'string' && gettype($item["uploaded"]) === 'object'){
                    $data['images'] = $item["uploaded"]->storePublicly('foto_barang_pemesanan','local_public');
                    if (!empty($item["oldUploaded"])){
                        unlink(public_path($item["oldUploaded"]));
                    }
                }
                // dd($data);
                // Stock::findOrFail($item["produk_id"])->decrement('jumlah_product'); // decrement stock
                PemesananItem::create($data);
            }
            $no++;
        }

        PemesananItem::whereIn("id",$tmpPemesananItem)->delete();

        $comment = new UpdatedDataReason();
        $comment->reason = $this->alasan;
        $pemesanan->comments()->save($comment);

        if($this->type_pembayaran == 1){
            $pemesanan->metodePembayarans()->sync([
                [
                    'metode_pembayaran_id' => $this->list_metode_pembayarans[0]["metode_pembayaran_id"],
                    'amount' => $this->totalPembayaran
                ]
            ]);
        }else{
            $tempMetode = [];
            foreach ($this->list_metode_pembayarans as $d){
                $tempMetode[(int) $d['metode_pembayaran_id']] = [
                    'amount' => $this->decodeCurrency($d['amount']) == '' ? 0 : $this->decodeCurrency($d['amount']),
                ];
            }
            $pemesanan->metodePembayarans()->sync($tempMetode);
        }

        return redirect()->route('admin.pemesanan.invoice',['pemesanan' => $pemesanan->id])->with("success","data saved");
    }

    public function updatingTrx($value, $index)
    {
        $d = explode('.',$index);
        if (str_contains($index,'jenis_id') && $value == ""){
            $this->trx[$d[0]]['items'][$d[2]] = [
                "jenis_id" => "",
                "nama_jenis" => "",
                "varian" => "",
                "produk_id" => "",
                "nama_produk" => "",
                "berat" => 0,
                "kadar" => 0,
                "harga" => $this->encodeCurrency(0),
                "ongkos" => $this->trx[$d[0]]['items'][$d[2]]['ongkos'],
                "down_payment" => $this->trx[$d[0]]['items'][$d[2]]['down_payment'],
                "selesai_pesanan" => "",
                "uploaded" => null,
            ];
        }
        $this->calculateSisaPembayaran();
    }

    public function updatedTrx()
    {
        $this->calculateSisaPembayaran();
    }

    public function checkPreview()
    {
        $this->preview = true;
        
        foreach($this->trx as $trx){
            foreach($trx["items"] as $item){
                $total = ((float) $item["berat"] * (float) $this->decodeCurrency($item["harga"])) + (float) $this->decodeCurrency($item["ongkos"]);
                if($this->decodeCurrency($item["down_payment"]) < ($total / 2) || $item["selesai_pesanan"] === ''){
                    $this->preview = false;
                    break;
                }
            }
            if($this->preview == false){
                break;
            }
        }

        if($this->grandTotal == 0 || $this->customer["nama"] === ""){
            $this->preview = false;
        }
    }

    public function updatedCreateCustomer($value)
    {
        if (!$value || $this->customer["id"] !== 0){
            $this->customer = [
                "id" => 0,
                "nama" => "",
                "phone" => "",
                "email" => "",
            ];
        }

        $this->checkPreview();
    }

    public function updatedCustomerId($value)
    {
        if ($this->customer["id"] !== 0 && $this->createCustomer === false && $value !== ''){
            $customerData = Customer::findOrFail($this->customer["id"]);
            $this->customer["nama"] = $customerData->nama;
            $this->customer["email"] = $customerData->email;
            $this->customer["phone"] = $customerData->nomor_hp;
        }

        $this->checkPreview();
    }

    public function onChangeProdukId($value, $kwitansi, $index)
    {
        $this->trx[$kwitansi]["items"][$index]["produk_id"] = $value[0];
        $this->trx[$kwitansi]["items"][$index]["nama_produk"] = $value[1];
        $this->trx[$kwitansi]["items"][$index]["berat"] = $value[2];
        $this->trx[$kwitansi]["items"][$index]["kadar"] = $value[3];
    }

    public function onChangeTotalItemKwitansi($value, $kwitansi, $index)
    {
        $this->trx[$kwitansi]["items"][$index]["total"] = $value;

        $this->checkPreview();
    }

    public function addRow($index)
    {
        $this->trx[$index]["items"][] = [
            "jenis_id" => '',
            "nama_jenis" => '',
            "varian" => '',
            "produk_id" => '',
            "nama_produk" => '',
            "berat" => 0,
            "kadar" => 0,
            "harga" => $this->encodeCurrency(0),
            "ongkos" => $this->encodeCurrency(0),
            "down_payment" => $this->encodeCurrency(0),
            "selesai_pesanan" => '',
            "uploaded" => null
        ];

        $this->checkPreview();
    }

    public function removeTrxRow($index)
    {
        unset($this->trx[$index]);
        $this->trx = array_values($this->trx);
        $this->totalKuitansi--;

        $this->checkPreview();
        $this->calculateGrandTotal();
        $this->calculateTotalPembayaran();
        $this->calculateSisaPelunasan();
    }

    public function deleteRow($indexKuitansi, $indexRow)
    {
        unset($this->trx[$indexKuitansi-1]["items"][$indexRow]);
        $this->trx[$indexKuitansi-1]["items"] = array_values($this->trx[$indexKuitansi-1]["items"]);

        $this->checkPreview();
        $this->calculateGrandTotal();
        $this->calculateTotalPembayaran();
        $this->calculateSisaPelunasan();
    }

    public function hitungSubTotal($indexKuitansi)
    {
        $subTotal = 0;
        foreach ($this->trx[$indexKuitansi-1]["items"] as $item){
            $subTotal += ((float) $item["berat"] * (float) $item["harga"]) + (float) $item["ongkos"];
            $item["harga"] = $this->decodeCurrency($item["harga"]);
        }
        $this->trx[$indexKuitansi-1]["sub_total"] = $subTotal;

        $this->checkPreview();
    }

    public function updatingTotalKuitansi($value)
    {
        if ($value < 1 || $value == ""){
            $this->trx[] = [
                "sub_total" => 0,
                "items" => [
                    [
                        "jenis_id" => '',
                        "nama_jenis" => '',
                        "varian" => '',
                        "produk_id" => '',
                        "nama_produk" => '',
                        "berat" => $this->encodeCurrency(0),
                        "kadar" => $this->encodeCurrency(0),
                        "harga" => $this->encodeCurrency(0),
                        "ongkos" => $this->encodeCurrency(0),
                        "down_payment" => $this->encodeCurrency(0),
                        "selesai_pesanan" => '',
                        "uploaded" => null
                    ]
                ]
            ];
            $this->calculateSisaPembayaran();
            return;
        }

        if ($value <= $this->totalKuitansi){
            for ($i=$this->totalKuitansi-1; $i >= $value; $i--){
               unset($this->trx[$i]);
               $this->trx = array_values($this->trx);
            }
        }

        for ($i=count($this->trx); $i < $value; $i++){
            $this->trx[] = [
                "sub_total" => 0,
                "items" => [
                    [
                        "jenis_id" => '',
                        "nama_jenis" => '',
                        "varian" => '',
                        "produk_id" => '',
                        "nama_produk" => '',
                        "berat" =>0,
                        "kadar" =>0,
                        "harga" =>$this->encodeCurrency(0),
                        "ongkos" =>$this->encodeCurrency(0),
                        "down_payment" =>$this->encodeCurrency(0),
                        "selesai_pesanan" => '',
                        "uploaded" => null
                    ]
                ]
            ];
        }
        $this->calculateSisaPembayaran();
    }

    public function render()
    {
        return view('livewire.edit-pemesanan');
    }
}
