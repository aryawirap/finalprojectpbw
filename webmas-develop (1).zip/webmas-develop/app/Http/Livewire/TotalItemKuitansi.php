<?php

namespace App\Http\Livewire;

use App\Http\Controllers\Traits\CurrencyTrait;
use Livewire\Component;

class TotalItemKuitansi extends Component
{
    use CurrencyTrait;
    public $berat;
    public $harga;
    public $harga_sekarang;
    public $potongan;
    public $total;
    public $kwitansi;
    public $index;

    public function dehydrate()
    {
        $this->total = 'Rp. ' . number_format(((float) $this->berat * (float) $this->decodeCurrency($this->harga_sekarang)) - (float) $this->decodeCurrency($this->potongan));
    }

    public function render()
    {
        return view('livewire.total-item-kuitansi');
    }
}
