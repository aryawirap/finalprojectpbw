<?php

namespace App\Http\Livewire;

use App\Models\Category;
use App\Models\Stock;
use Livewire\Component;

class ListProduct extends Component
{
    public $category;
    public $selected = "";
    public $index;
    public $kwitansi;
    public $products = [];
    public $from = 1; // 1 penjualan, pembelian, pemesanan, 2 = tukarTambahKurang
    public $disabled = false;

    public function render()
    {
        $this->products = Stock::where("category_id", $this->category)->pluck("nama_barang","id");
        return view('livewire.list-product');
    }

    public function updatedSelected($value)
    {
        $stock = Stock::find($value);
        $this->emit('onChangeProdukId', [$value, $stock === null ? "-" : $stock->nama_barang, $stock->berat ?? 0, $stock->karat ?? 0, $this->from], $this->kwitansi, $this->index);
    }
}
