<?php

namespace App\Http\Livewire;

use App\Http\Controllers\Traits\CurrencyTrait;
use Livewire\Component;

class SubTotalKuitansi extends Component
{
    use CurrencyTrait;
    public $trxList = [];
    public $kwitansi;

    public function render()
    {
        $subTotal = 0;
        if (!empty($this->trxList)){
            foreach ($this->trxList[$this->kwitansi]["items"] as $item){
                $subTotal += ((float) $item["berat"] * (float) $this->decodeCurrency($item["harga_sekarang"])) - (float) $this->decodeCurrency($item["potongan"]);
            }
        }
        return view('livewire.sub-total-kuitansi', compact("subTotal"));
    }
}
