<?php

namespace App\Http\Livewire;

use App\Http\Controllers\Traits\CurrencyTrait;
use App\Models\Category;
use App\Models\Customer;
use App\Models\MetodePembayaran;
use App\Models\Penjualan;
use App\Models\TukarTambahKurang;
use App\Models\TukarTambahKurangItem;
use Carbon\Carbon;
use Haruncpi\LaravelIdGenerator\IdGenerator;
use Livewire\Component;

class CreateTukarTambahKurang extends Component
{
    use CurrencyTrait;
    public $metode_pembayarans = []; // from database
    public $list_metode_pembayarans = [
        [
            'metode_pembayaran_id' => '',
            'amount' => 0
        ]
    ];

    protected $rules = [
        'tukarTambahKurangData.*.sub_total' => 'required',
        'tukarTambahKurangData.*.items.*.jenis_id' => 'required',
        'tukarTambahKurangData.*.items.*.varian' => 'nullable',
        'tukarTambahKurangData.*.items.*.produk_id' => 'required',
        'tukarTambahKurangData.*.items.*.nama_produk' => 'required',
        'tukarTambahKurangData.*.items.*.berat' => 'required',
        'tukarTambahKurangData.*.items.*.kadar' => 'required',
        'tukarTambahKurangData.*.items.*.harga' => 'required',
        'tukarTambahKurangData.*.items.*.ongkos' => 'required',
        'tukarTambahKurangData.*.items.*.uploaded' => 'nullable|image',
    ];

    protected $messages = [
        'tukarTambahKurangData.*.items.*.uploaded.image' => 'File upload harus berupa gambar',
        'tukarTambahKurangData.*.items.*.ongkos.required' => 'Field harus di isi',
        'tukarTambahKurangData.*.items.*.harga.required' => 'Field harus di isi',
        'tukarTambahKurangData.*.items.*.jenis_id.required' => 'Field harus di isi',
        'tukarTambahKurangData.*.items.*.produk_id.required' => 'Field harus di isi',
    ];

    public $payment_list = []; // unique for multi payment
    public $catatan;

    public $tempSisaPembayaran = 0; // only for multi payment
    public $jenis_emas = [];
    public $totalKuitansi = 1;
    public $trxKuitansi = 1;
    public $cekNota = false;
    public $isiNota = '';
    public $adaData = false;

    public $typetukarTambah = 1; // 1 = tukar tambah, 2 = tukar kurang
    public $nota = '';
    public $trx = [];
    public $grandTotal = 0;
    public $grandTotalTukarTambah = 0;


    public $tukarTambahKurangData = [
        [
            "sub_total" => 0,
            "items" => [
                [
                    "jenis_id" => '',
                    "nama_jenis" => '',
                    "varian" => '',
                    "produk_id" => '',
                    "nama_produk" => '',
                    "berat" => 0,
                    "kadar" => 0,
                    "harga" => 0,
                    "ongkos" => 0,
                    "uploaded" => null
                ]
            ]
        ]
    ];

    public $type_pembayaran = 1;
    public $from = 1;
    public $createCustomer = false;
    public $customer = [
        "id" => 0,
        "nama" => "",
        "phone" => "",
        "email" => "",
    ];

    public $customerList = [];
    public $tmpPenjualan = null;

    protected $listeners = ['onChangeProdukId', 'onChangeTotalItemKwitansi' => '$refresh'];

    public function mount()
    {
        $pembayaranList = MetodePembayaran::pluck('nama_metode', 'id');
        foreach ($pembayaranList as $index => $list){
            $this->payment_list[] = [
                'id' => $index,
                'name' => $list,
                'used' => false,
            ];
        }
        $this->customerList = Customer::pluck("nama","id");
        $this->jenis_emas = Category::pluck('type_emas','id');
        $this->metode_pembayarans = $pembayaranList;
    }

    public function updated($propertyName)
    {
        $this->validateOnly($propertyName);
    }

    public function calculateGrandTotal()
    {
        $grandTotal = 0;
        $tmpGrandTotalTukarTambah = 0;
        foreach ($this->trx as $trx){
            foreach ($trx["items"] as $item){
                $grandTotal += ((float) $item["berat"] * (float) $this->decodeCurrency($item["harga_sekarang"])) - (float) $this->decodeCurrency($item["potongan"]);
            }
        }
        if ($this->typetukarTambah == 1){ // tukar tambah
            foreach ($this->tukarTambahKurangData as $trx){
                foreach ($trx["items"] as $item){
                    $tmpGrandTotalTukarTambah += ((float) $item["berat"] * (float) $this->decodeCurrency($item["harga"])) + (float) $this->decodeCurrency($item["ongkos"]);
                }
            }
            $this->grandTotal = $tmpGrandTotalTukarTambah + $grandTotal;
        }else{
            $this->grandTotal = $grandTotal;
        }
    }

    public function calculateTukarTambahKurang()
    {
        $this->calculateGrandTotal();
        $tmpGrandTotalTukarTambah = 0;
        foreach ($this->tukarTambahKurangData as $trx){
            foreach ($trx["items"] as $item){
                $tmpGrandTotalTukarTambah += ((float) $item["berat"] * (float) $this->decodeCurrency($item["harga"])) + (float) $this->decodeCurrency($item["ongkos"]);
            }
        }
        $tmpGr = 0;
        if ($this->typetukarTambah == 1){ // ini untuk tukar tambah 597,000 - 0
            $grandTotalBarangPenjualan = 0;
            foreach ($this->trx as $trx){
                foreach ($trx["items"] as $item){
                    $grandTotalBarangPenjualan += ((float) $item["berat"] * (float) $this->decodeCurrency($item["harga_sekarang"])) - (float) $this->decodeCurrency($item["potongan"]);
                }
            }
            $tmpGr = $tmpGrandTotalTukarTambah - $grandTotalBarangPenjualan;
        }else{ // ini untuk tukar kurang
            $tmpGr= $this->grandTotal - $tmpGrandTotalTukarTambah;
        }

        $this->grandTotalTukarTambah = $tmpGr;
        $this->tempSisaPembayaran = $tmpGr;
        $this->calculateSisaPembayaran();
    }

    public function calculateSisaPembayaran()
    {
        $this->calculateGrandTotal();
        $totalMetodePembayaran =  0;
        foreach ($this->list_metode_pembayarans as $d){
            $totalMetodePembayaran += $this->decodeCurrency($d['amount']) == '' ? 0 : $this->decodeCurrency($d['amount']);
        }
        $this->tempSisaPembayaran = (float) $totalMetodePembayaran - $this->grandTotalTukarTambah;
    }

    public function searchIndexAndUpdatePaymentListByMetodeId($id)
    {
        foreach ($this->payment_list as $index => $d){
            if ($d['id'] == $id){
                $this->payment_list[$index]['used'] = !$this->payment_list[$index]['used'];// update array
                return;
            }
        }
    }

    public function updatingListMetodePembayarans($value, $index)
    {
        if (str_contains($index, "metode_pembayaran_id")){
            $ex = explode('.', $index);
            $this->searchIndexAndUpdatePaymentListByMetodeId($this->list_metode_pembayarans[$ex[0]]['metode_pembayaran_id']); // used = true
            if ($value != ''){
                $this->searchIndexAndUpdatePaymentListByMetodeId($value); // used = true\
            }
        }
    }

    public function updatedTypeTukarTambah()
    {
        $this->calculateTukarTambahKurang();
    }

    function changeFromIni(){
        $this->from = 1;
        if(count($this->trx) == 0 ){
            $this->cekNota = false;
        }
    }

    function changeFromLain(){
        $this->from = 2;
        $this->cekNota = true;
        if(count($this->trx) == 0 ){
            $this->trx = [
                [
                    "sub_total" => 0,
                    "items" => [
                        [
                            "jenis_id" => '',
                            "nama_jenis" => '',
                            "varian" => '',
                            "produk_id" => '',
                            "nama_produk" => '',
                            "berat" => 0,
                            "kadar" => 0,
                            "harga" => 0,
                            "harga_sekarang" => 0,
                            "potongan" => 0,
                            "uploaded" => null
                        ]
                    ]
                ]
            ];
        }
    }

    public function updatingTypePembayaran($value)
    {
        if($value == 1 && $this->type_pembayaran == 2){
            $this->tempSisaPembayaran = $this->grandTotal;
        }else{
            $this->calculateSisaPembayaran();
        }
    }

    public function updatedListMetodePembayarans($value, $index)
    {
        if(str_contains($index, "amount")){
            $this->calculateSisaPembayaran();
        }
    }

    public function onClickCreateMetodePembayaran(){
        $this->list_metode_pembayarans[] =  [
            'metode_pembayaran_id' => '',
            'amount' => 0
        ];
    }

    public function onClickRemoveMetodePembayaran($index)
    {
        $this->searchIndexAndUpdatePaymentListByMetodeId($this->list_metode_pembayarans[$index]["metode_pembayaran_id"]);
        $this->tempSisaPembayaran += (float) $this->list_metode_pembayarans[$index]["amount"];
        unset($this->list_metode_pembayarans[$index]);
        $this->list_metode_pembayarans = array_values($this->list_metode_pembayarans);
        $this->calculateSisaPembayaran();
    }

    public function cekNotaBtn()
    {
        $this->cekNota = true;
        $this->trx = [];
        $data = Penjualan::with("customer")->where('noTrx', '=', trim($this->nota))->get()->first();

        if(!is_null($data) && $data->count() > 0) {
            $time = Carbon::now()->toDateString();

            $this->adaData = true;
            $this->isiNota = "Nota di temukan";
            if ($data->created_at->addDays(14)->toDateString() >= $time){
                $this->customer = [
                    "id" => $data->customer->id,
                    "nama" => $data->customer->nama,
                    "phone" => $data->customer->nomor_hp,
                    "email" => $data->customer->email,
                ];
                $this->totalKuitansi = $data->totalKuitansi;
                $this->grandTotal = $data->grand_total;
                $this->tmpPenjualan = $data;
                foreach ($data["penjualanItems"] as $item){
                    $this->trx[$item->noKuitansi-1]["items"][] = [
                        "jenis_id" => $item->category_id,
                        "nama_jenis" => $item->jenisEmas,
                        "varian" => $item->varian,
                        "produk_id" => $item->stock_id,
                        "nama_produk" => $item->namaBarang,
                        "berat" => $item->berat,
                        "kadar" => $item->kadar,
                        "harga" => $this->encodeCurrency($item->hargaPerGram),
                        "harga_sekarang" => 0,
                        "potongan" => 0,
                        "uploaded" => $item->image
                    ];
                }
            }else{
                $this->isiNota = "Nota expired, tercatat pada tanggal {$data->created_at->format('d-m-Y')}";
            }
        } else {
            $this->isiNota = "Nota tidak ditemukan";
        }
    }

    public function save()
    {
        if($this->from == 2){
            $this->createCustomer = true;
        }

        $tempCustomer = null;
        // if new customer
        if($this->createCustomer){
            $tempCustomer = Customer::create([
                "nama" => $this->customer["nama"],
                "email" => $this->customer["email"],
                "nomor_hp" => $this->customer["phone"],
            ]);
        }else{ // already customer
            $tempCustomer["id"] = $this->customer["id"];
        }

        // generate id invoice
        $noTrx = IdGenerator::generate(['field' => 'noTrx','table' => 'tukar_tambah_kurangs', 'length' => 13, 'prefix' => date('Ymd')."-"]);

        $tmpTukarTambahKurang = TukarTambahKurang::create([ // create invoice
            "noTrx" => $noTrx,
            "total_kuitansi" => $this->totalKuitansi,
            "customer_id" => $tempCustomer["id"],
            "grand_total" => $this->grandTotal,
            "nota" => $this->nota,
            "from" => $this->from,
            "payment_type" => $this->type_pembayaran,
            "type" => $this->typetukarTambah,
            "note" => $this->catatan,
            "totalPay" => $this->grandTotalTukarTambah,
            "tanggalPenjualan" => $this->tmpPenjualan->created_at
        ]);

        foreach ($this->trx as $index => $trx){ // insert items
            foreach ($trx["items"] as $item){
                $this->tukarTambahItemInsert($tmpTukarTambahKurang, $item, $index+1, 1);
            }
        }

        foreach ($this->tukarTambahKurangData as $index => $tkrtmbhKurang) { // insert items
            foreach ($tkrtmbhKurang["items"] as $item) { // insert tukar tambah kurang items
                $this->tukarTambahItemInsert($tmpTukarTambahKurang, $item, $index + 1, 2);
            }
        }

        if($this->type_pembayaran == 1){ // single payment
            $tmpTukarTambahKurang->metodePembayarans()->attach([
                [
                    'metode_pembayaran_id' => $this->list_metode_pembayarans[0]["metode_pembayaran_id"],
                    'amount' => $this->grandTotalTukarTambah
                ]
            ]);
        }else{ // multi payment
            $tempMetode = [];
            foreach ($this->list_metode_pembayarans as $d){
                $tempMetode[(int) $d['metode_pembayaran_id']] = [
                    'amount' => $this->decodeCurrency($d['amount']) == '' ? 0 : $this->decodeCurrency($d['amount']),
                ];
            }
            $tmpTukarTambahKurang->metodePembayarans()->attach($tempMetode); // assign to pivot table penjualan_metode_pembayaran
        }
        Penjualan::where('noTrx',trim($this->nota))->first()->delete(); // delete penjualan when success create tukar tambah data
        // redirect to sales
        return redirect()->route('admin.tukarTambahKurang.invoice',['tukarTambahKurang' => $tmpTukarTambahKurang->id])->with("success","data saved");  // redirect to sales
    }

    public function updatedTrx()
    {
        $this->calculateTukarTambahKurang();
    }

    public function updatingTukarTambahKurangData($value, $index)
    {
        $d = explode('.',$index);
        if (str_contains($index,'jenis_id') && $value == ""){
            $this->trx[$d[0]]['items'][$d[2]] = [
                "jenis_id" => "",
                "nama_jenis" => "",
                "varian" => "",
                "produk_id" => "",
                "nama_produk" => "",
                "berat" => 0,
                "kadar" => 0,
                "harga" => $this->encodeCurrency(0),
                "ongkos" => $this->trx[$d[0]]['items'][$d[2]]['ongkos'],
                "uploaded" => null,
            ];
        }
        $this->calculateTukarTambahKurang();
    }

    public function updatedTukarTambahKurangData()
    {
        $this->calculateTukarTambahKurang();
    }

    public function updatedCreateCustomer($value)
    {
        // reset when return to false && id not 0
        if (!$value || $this->customer["id"] !== 0){
            $this->customer = [
                "id" => 0,
                "nama" => "",
                "phone" => "",
                "email" => "",
            ];
        }
    }

    public function updatedCustomerId($value)
    {
        // search customer by id
        if ($this->customer["id"] !== 0 && $this->createCustomer === false && $value !== ''){
            $customerData = Customer::findOrFail($this->customer["id"]);
            $this->customer["nama"] = $customerData->nama;
            $this->customer["email"] = $customerData->email;
            $this->customer["phone"] = $customerData->nomor_hp;
        }
    }

    public function onChangeProdukId($value, $kwitansi, $index)
    {
        if ($value[4] == 2){
            $this->tukarTambahKurangData[$kwitansi]["items"][$index]["produk_id"] = $value[0];
            $this->tukarTambahKurangData[$kwitansi]["items"][$index]["nama_produk"] = $value[1];
            $this->tukarTambahKurangData[$kwitansi]["items"][$index]["berat"] = $value[2];
            $this->tukarTambahKurangData[$kwitansi]["items"][$index]["kadar"] = $value[3];
        }else{
            $this->trx[$kwitansi]["items"][$index]["produk_id"] = $value[0];
            $this->trx[$kwitansi]["items"][$index]["nama_produk"] = $value[1];
        }
    }

    public function onChangeTotalItemKwitansi($value, $kwitansi, $index)
    {
        $this->trx[$kwitansi]["items"][$index]["total"] = $value;
    }

    public function addRow($index,$type = null)
    {
        if ($type == 'invoice'){
            $this->tukarTambahKurangData[$index]["items"][] = [
                "jenis_id" => '',
                "nama_jenis" => '',
                "varian" => '',
                "produk_id" => '',
                "nama_produk" => '',
                "berat" => 0,
                "kadar" => 0,
                "harga" => 0,
                "harga_sekarang" => 0,
                "ongkos" => 0,
                "uploaded" => null
            ];
        }else{
            $this->trx[$index]["items"][] = [
                "jenis_id" => '',
                "nama_jenis" => '',
                "varian" => '',
                "produk_id" => '',
                "nama_produk" => '',
                "berat" => 0,
                "kadar" => 0,
                "harga" => 0,
                "harga_sekarang" => 0,
                "potongan" => 0,
                "uploaded" => null
            ];
        }
    }

    public function removeTrxRow($index)
    {
        unset($this->tukarTambahKurangData[$index]);
        $this->tukarTambahKurangData = array_values($this->tukarTambahKurangData);
        $this->trxKuitansi--;
        $this->calculateTukarTambahKurang();
    }

    public function deleteRow($indexKuitansi, $indexRow, $type = null)
    {
        if ($type == 'invoice'){
            unset($this->tukarTambahKurangData[$indexKuitansi]["items"][$indexRow]);
            $this->tukarTambahKurangData[$indexKuitansi]["items"] = array_values($this->tukarTambahKurangData[$indexKuitansi]["items"]);
            $this->calculateTukarTambahKurang();
        }else{
            unset($this->tukarTambahKurangData[$indexKuitansi-1]["items"][$indexRow]);
            $this->tukarTambahKurangData[$indexKuitansi-1]["items"] = array_values($this->tukarTambahKurangData[$indexKuitansi-1]["items"]);
        }
    }

    public function hitungSubTotal($indexKuitansi)
    {
        $subTotal = 0;
        foreach ($this->trx[$indexKuitansi-1]["items"] as $item){
            $subTotal += ((float) $item["berat"] * (float) $this->decodeCurrency($item["harga_sekarang"])) + (float) $this->decodeCurrency($item["potongan"]);
        }
        $this->trx[$indexKuitansi-1]["sub_total"] = $subTotal;
    }

    public function updatingTrxKuitansi($value)
    {
        if ($value < 1 || $value == ""){
            $this->tukarTambahKurangData = [];
            $this->tukarTambahKurangData[] = [
                "sub_total" => 0,
                "items" => [
                    [
                        "jenis_id" => '',
                        "nama_jenis" => '',
                        "varian" => '',
                        "produk_id" => '',
                        "nama_produk" => '',
                        "berat" => $this->encodeCurrency(0),
                        "kadar" => $this->encodeCurrency(0),
                        "harga" => $this->encodeCurrency(0),
                        "ongkos" => $this->encodeCurrency(0),
                        "uploaded" => null
                    ]
                ]
            ];
            $this->calculateTukarTambahKurang();
            return;
        }

        if ($value <= $this->trxKuitansi){
            for ($i=$this->trxKuitansi-1; $i >= $value; $i--){
                unset($this->tukarTambahKurangData[$i]);
                $this->tukarTambahKurangData = array_values($this->tukarTambahKurangData);
            }
        }

        for ($i=count($this->tukarTambahKurangData); $i < $value; $i++){
            $this->tukarTambahKurangData[] = [
                "sub_total" => 0,
                "items" => [
                    [
                        "jenis_id" => '',
                        "nama_jenis" => '',
                        "varian" => '',
                        "produk_id" => '',
                        "nama_produk" => '',
                        "berat" => 0,
                        "kadar" => 0,
                        "harga" => 0,
                        "ongkos" => 0,
                        "uploaded" => null
                    ]
                ]
            ];
        }
    }

    public function render()
    {
        return view('livewire.tukarTambahKurang.createTukarTambahKurang');
    }

    /**
     * @param $tmpTukarTambahKurang
     * @param mixed $item
     * @param int $incrementTukarTambah
     * @return void
     */
    private function tukarTambahItemInsert($tmpTukarTambahKurang, mixed $item, int $incrementTukarTambah, $type = 1): void
    {
        if ($type == 1){ // default
            TukarTambahKurangItem::create([
                "tukar_tambah_kurang_id" => $tmpTukarTambahKurang->id,
                "category_id" => $item["jenis_id"],
                "stock_id" => $item["produk_id"],
                "varian" => $item["varian"],
                "noKuitansi" => $incrementTukarTambah,
                "type" => 1, // 1 = default, 2 = tukarTambahKurangInvoice

                "jenisEmas" => Category::findOrFail($item["jenis_id"])->type_emas,
                "namaBarang" => $item["nama_produk"],
                "berat" => $item["berat"],
                "kadar" => $item["kadar"],
                "hargaPerGram" => $this->decodeCurrency($item["harga"]),
                "hargaPerGramBaru" => $this->decodeCurrency($item["harga_sekarang"]),
                "potongan" => $item["potongan"] ? $this->decodeCurrency($item["potongan"]) : 0,
                "total" => ((float)$item["berat"] * (float)$this->decodeCurrency($item["harga_sekarang"])) - (float)$this->decodeCurrency($item["potongan"]),
                "image" => $item["uploaded"]
            ]);
        }else{ // invoice tukarTambahKurang
            $data = [
                "tukar_tambah_kurang_id" => $tmpTukarTambahKurang->id,
                "category_id" => $item["jenis_id"],
                "stock_id" => $item["produk_id"],
                "varian" => $item["varian"],
                "noKuitansi" => $incrementTukarTambah,
                "type" => 2, // 1 = default, 2 = tukarTambahKurangInvoice
                "jenisEmas" => Category::findOrFail($item["jenis_id"])->type_emas,
                "namaBarang" => $item["nama_produk"],
                "berat" => $item["berat"],
                "kadar" => $item["kadar"],
                "hargaPerGram" => $this->decodeCurrency($item["harga"]),
                "hargaPerGramBaru" => 0,
                "potongan" => $item["ongkos"] ? $this->decodeCurrency($item["ongkos"]) : 0,
                "total" => ((float)$item["berat"] * (float)$this->decodeCurrency($item["harga"])) + (float)$this->decodeCurrency($item["ongkos"]),
            ];
            if ($item["uploaded"] !== null){
                $data['image'] = $item["uploaded"]->storePublicly('foto_barang_tukar_tambah_kurang','local_public');
            }
            TukarTambahKurangItem::create($data);
        }
    }
}
