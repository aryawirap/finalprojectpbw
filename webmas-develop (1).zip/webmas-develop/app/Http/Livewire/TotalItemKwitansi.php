<?php

namespace App\Http\Livewire;

use App\Http\Controllers\Traits\CurrencyTrait;
use Livewire\Component;

class TotalItemKwitansi extends Component
{
    use CurrencyTrait;

    public $berat;
    public $harga;
    public $ongkos;
    public $total;
    public $kwitansi;
    public $index;

    public function dehydrate()
    {
        $this->total = 'Rp. ' . number_format(((float) $this->berat * (float) $this->decodeCurrency($this->harga) + (float) $this->decodeCurrency($this->ongkos)));
    }

    public function render()
    {
        return view('livewire.total-item-kwitansi');
    }
}
