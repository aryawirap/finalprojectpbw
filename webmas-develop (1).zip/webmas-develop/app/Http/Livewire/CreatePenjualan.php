<?php

namespace App\Http\Livewire;

use App\Http\Controllers\Traits\CurrencyTrait;
use App\Models\Category;
use App\Models\Customer;
use App\Models\MetodePembayaran;
use App\Models\Penjualan;
use App\Models\PenjualanItem;
use App\Models\Stock;
use App\Models\StockOpname;
use App\Models\StockOpnameDetail;
use Illuminate\Support\Facades\Redirect;
use Livewire\Component;
use Haruncpi\LaravelIdGenerator\IdGenerator;
use Livewire\WithFileUploads;

class CreatePenjualan extends Component
{
    use CurrencyTrait, WithFileUploads;
    private $messageStockOpname = "created by system";
    protected $rules = [
        'trx.*.sub_total' => 'required',
        'trx.*.items.*.varian' => 'nullable',
        'trx.*.items.*.jenis_id' => 'required',
        'trx.*.items.*.produk_id' => 'required',
        'trx.*.items.*.nama_produk' => 'required',
        'trx.*.items.*.berat' => 'required',
        'trx.*.items.*.kadar' => 'required',
        'trx.*.items.*.harga' => 'required',
        'trx.*.items.*.ongkos' => 'required',
        'trx.*.items.*.uploaded' => 'nullable|image',
    ];

    protected $messages = [
        'trx.*.items.*.uploaded.image' => 'File upload harus berupa gambar',
        'trx.*.items.*.ongkos.required' => 'Field harus di isi',
        'trx.*.items.*.harga.required' => 'Field harus di isi',
        'trx.*.items.*.jenis_id.required' => 'Field harus di isi',
        'trx.*.items.*.produk_id.required' => 'Field harus di isi',
    ];

    public $metode_pembayarans = []; // from database
    public $payment_list = []; // unique for multi payment
    public $list_metode_pembayarans = [
        [
            'metode_pembayaran_id' => '',
            'amount' => 0
        ]
    ];
    public $tempSisaPembayaran = 0; // only for multi payment
    public $jenis_emas = []; // from database
    public $totalKuitansi = 1;
    public $grandTotal;
    public $trx = [
        [
            "sub_total" => 0,
            "items" => [
                [
                    "jenis_id" => '',
                    "varian" => '',
                    "nama_jenis" => '',
                    "produk_id" => '',
                    "nama_produk" => '',
                    "berat" => 0,
                    "kadar" => 0,
                    "harga" => 0,
                    "ongkos" => 0,
                    "uploaded" => null
                ]
            ]
        ]
    ];
    public $catatan;

    public $type_pembayaran = 1;
    
    // customer data
    public $createCustomer = false;
    public $customer = [
        "id" => 0,
        "nama" => "",
        "phone" => "",
        "email" => "",
    ];

    public $customerList = []; // from database

    protected $listeners = ['onChangeProdukId', 'onChangeTotalItemKwitansi' => '$refresh'];

    public function mount()
    {
        $pembayaranList = MetodePembayaran::pluck('nama_metode', 'id');
        foreach ($pembayaranList as $index => $list){
            $this->payment_list[] = [
                'id' => $index,
                'name' => $list,
                'used' => false,
            ];
        }
        $this->customerList = Customer::pluck("nama","id");
        $this->jenis_emas = Category::pluck('type_emas','id');
        $this->metode_pembayarans = $pembayaranList;
    }

    public function updated($propertyName)
    {
        $this->validateOnly($propertyName);
    }

    public function calculateGrandTotal()
    {
        $grandTotal = 0;
        foreach ($this->trx as $trx){
            foreach ($trx["items"] as $item){
                $grandTotal += ((float) $item["berat"] * (float) $this->decodeCurrency($item["harga"])) + (float) $this->decodeCurrency($item["ongkos"]);
            }
        }
        $this->grandTotal = $grandTotal;
    }

    public function calculateSisaPembayaran()
    {
        $this->calculateGrandTotal();
        $totalMetodePembayaran =  0;
        foreach ($this->list_metode_pembayarans as $d){
            $totalMetodePembayaran += $this->decodeCurrency($d['amount']) == '' ? 0 : $this->decodeCurrency($d['amount']);
        }
        $this->tempSisaPembayaran = (float) $totalMetodePembayaran - $this->grandTotal;
    }

    public function searchIndexAndUpdatePaymentListByMetodeId($id)
    {
        foreach ($this->payment_list as $index => $d){
            if ($d['id'] == $id){
                $this->payment_list[$index]['used'] = !$this->payment_list[$index]['used'];// update array
                return;
            }
        }
    }

    public function updatingTypePembayaran($value)
    {
        if($value == 1 && $this->type_pembayaran == 2){
            $this->tempSisaPembayaran = $this->grandTotal;
        }else{
            $this->calculateSisaPembayaran();
        }
    }

    public function updatedListMetodePembayarans($value, $index)
    {
        if(str_contains($index, "amount")){
            $this->calculateSisaPembayaran();
        }
    }

    public function updatingListMetodePembayarans($value, $index)
    {
        if (str_contains($index, "metode_pembayaran_id")){
            $ex = explode('.', $index);
            $this->searchIndexAndUpdatePaymentListByMetodeId($this->list_metode_pembayarans[$ex[0]]['metode_pembayaran_id']); // used = true
            if ($value != ''){
                $this->searchIndexAndUpdatePaymentListByMetodeId($value); // used = true\
            }
        }
    }

    public function onClickCreateMetodePembayaran(){
         $this->list_metode_pembayarans[] =  [
             'metode_pembayaran_id' => '',
             'amount' => 0
         ];
    }

    public function onClickRemoveMetodePembayaran($index)
    {
        $this->searchIndexAndUpdatePaymentListByMetodeId($this->list_metode_pembayarans[$index]["metode_pembayaran_id"]);
        $this->tempSisaPembayaran += (float) $this->list_metode_pembayarans[$index]["amount"];
        unset($this->list_metode_pembayarans[$index]);
        $this->list_metode_pembayarans = array_values($this->list_metode_pembayarans);
        $this->calculateSisaPembayaran();
    }

    public function save()
    {
        $validatedData = $this->validate();
        $tempCustomer = null;
        if($this->createCustomer){ // new customer
            $tempCustomer = Customer::create([
                "nama" => $this->customer["nama"],
                "email" => $this->customer["email"],
                "nomor_hp" => $this->customer["phone"],
            ]);
        }else{ // already customer
            $tempCustomer["id"] = $this->customer["id"];
        }

        // generate id invoice
        $noTrx = IdGenerator::generate(['field' => 'noTrx','table' => 'penjualans', 'length' => 13, 'prefix' => date('Ymd')."-"]);

        $tempPenjualan = Penjualan::create([ // create invoice
            "noTrx" => $noTrx,
            "totalKuitansi" => $this->totalKuitansi,
            "customer_id" => $tempCustomer["id"],
            "grandTotal" => $this->grandTotal,
            "payment_type" => $this->type_pembayaran,
            "note" => $this->catatan
        ]);

        // insert data to penjualanItems
        // why loop ? because data we store doesn't iteration same with fillable PenjualanItem
        // next we need improve these algorithms & pejualan items mush be pivot table
        $no = 1;
        foreach ($validatedData['trx'] as $trx){
            foreach ($trx["items"] as $item){

                $checkStockOpname = StockOpname::where("tanggal",date("Y-m-d"))->where("stock_id", $item["produk_id"])->first();
                if ($checkStockOpname !== NULL){
                    StockOpnameDetail::create([ // create StockOpname Detail
                        "type" => 1, // 1 = pengurangan dari penjualan, 2 = penambahan
                        "jumlah" => 1,
                        "penjualan_id" => $tempPenjualan->id,
                        "stock_opname_id" => $checkStockOpname->id,
                        "catatan" => $this->messageStockOpname . " penjualan  " . $tempPenjualan->id
                    ]);
                }else{
                    $tmpStockOpname = StockOpname::create([// create stockOpname
                        "stock_id" => $item["produk_id"],
                        "status" => 1,
                        "tanggal" => date("Y-m-d"),
                        "stock_awal" => Stock::findOrFail($item["produk_id"])->jumlah_product
                    ]);

                    StockOpnameDetail::create([ // create StockOpname Detail
                        "type" => 1, // 1 = pengurangan dari penjualan, 2 = penambahan
                        "jumlah" => 1,
                        "penjualan_id" => $tempPenjualan->id,
                        "stock_opname_id" => $tmpStockOpname->id,
                        "catatan" => $this->messageStockOpname . " penjualan id " . $tempPenjualan->id
                    ]);
                }

                $data = [
                    "penjualan_id" => $tempPenjualan->id,
                    "category_id" => $item["jenis_id"],
                    "varian" => $item["varian"],
                    "stock_id" => $item["produk_id"],
                    "noKuitansi" => $no,
                    "jenisEmas" => Category::findOrFail($item["jenis_id"])->type_emas,
                    "namaBarang" => $item["nama_produk"],
                    "berat" => $item["berat"],
                    "kadar" => $item["kadar"],
                    "hargaPerGram" => $this->decodeCurrency($item["harga"]),
                    "ongkos" => $item["ongkos"] ? $this->decodeCurrency($item["ongkos"]) : 0,
                    "total" => ((float) $item["berat"] * (float) $this->decodeCurrency($item["harga"])) + (float) $this->decodeCurrency($item["ongkos"]),
                ];

                if ($item["uploaded"] !== null){
                    $data['image'] = $item["uploaded"]->storePublicly('foto_barang_penjualan','local_public');
                }

                Stock::findOrFail($item["produk_id"])->decrement('jumlah_product'); // decrement stock
                PenjualanItem::create($data);
            }
            $no++; // no is for order kuitansi
        }
        if($this->type_pembayaran == 1){ // single payment
            $tempPenjualan->metodePembayarans()->attach([
                [
                    'metode_pembayaran_id' => $this->list_metode_pembayarans[0]["metode_pembayaran_id"],
                    'amount' => $this->grandTotal
                ]
            ]);
        }else{ // multi payment
            $tempMetode = [];
            foreach ($this->list_metode_pembayarans as $d){
                $tempMetode[(int) $d['metode_pembayaran_id']] = [
                    'amount' => $this->decodeCurrency($d['amount']) == '' ? 0 : $this->decodeCurrency($d['amount']),
                ];
            }
            $tempPenjualan->metodePembayarans()->attach($tempMetode); // assign to pivot table penjualan_metode_pembayaran
        }
        return redirect()->route('admin.sales.invoice',['sale' => $tempPenjualan->id])->with("success","data saved");  // redirect to sales
    }

    public function updatingTrx($value, $index)
    {
        $d = explode('.',$index);
        if (str_contains($index,'jenis_id') && $value == ""){
            $this->trx[$d[0]]['items'][$d[2]] = [
                "jenis_id" => "",
                "nama_jenis" => "",
                "varian" => "",
                "produk_id" => "",
                "nama_produk" => "",
                "berat" => 0,
                "kadar" => 0,
                "harga" => $this->encodeCurrency(0),
                "ongkos" => $this->trx[$d[0]]['items'][$d[2]]['ongkos'],
                "uploaded" => null,
            ];
        }
        $this->calculateSisaPembayaran();
    }

    public function updatedTrx($value, $index)
    {
        $this->calculateSisaPembayaran();
    }

    public function updatedCreateCustomer($value)
    {
        // reset when return to false && id not 0
        if (!$value || $this->customer["id"] !== 0){
            $this->customer = [
                "id" => 0,
                "nama" => "",
                "phone" => "",
                "email" => "",
            ];
        }
    }

    public function updatedCustomerId($value)
    {
        // search customer by id
        if ($this->customer["id"] !== 0 && $this->createCustomer === false && $value !== ''){
            $customerData = Customer::findOrFail($this->customer["id"]);
            $this->customer["nama"] = $customerData->nama;
            $this->customer["email"] = $customerData->email;
            $this->customer["phone"] = $customerData->nomor_hp;
        }
    }

    public function onChangeProdukId($value, $kwitansi, $index)
    {
        $this->trx[$kwitansi]["items"][$index]["produk_id"] = $value[0];
        $this->trx[$kwitansi]["items"][$index]["nama_produk"] = $value[1];
        $this->trx[$kwitansi]["items"][$index]["berat"] = $value[2];
        $this->trx[$kwitansi]["items"][$index]["kadar"] = $value[3];
    }

    public function onChangeTotalItemKwitansi($value, $kwitansi, $index)
    {
        $this->trx[$kwitansi]["items"][$index]["total"] = $value;
    }

    public function addRow($index)
    {
        $this->trx[$index]["items"][] = [
            "jenis_id" => '',
            "nama_jenis" => '',
            "varian" => '',
            "produk_id" => '',
            "nama_produk" => '',
            "berat" => 0,
            "kadar" => 0,
            "harga" => 0,
            "ongkos" => 0,
            "uploaded" => null
        ];
    }

    public function removeTrxRow($index)
    {
        unset($this->trx[$index]);
        $this->trx = array_values($this->trx);
        $this->totalKuitansi--;
        $this->calculateGrandTotal();
    }

    public function deleteRow($indexKuitansi, $indexRow)
    {
        unset($this->trx[$indexKuitansi-1]["items"][$indexRow]);
        $this->trx[$indexKuitansi-1]["items"] = array_values($this->trx[$indexKuitansi-1]["items"]);
        $this->calculateGrandTotal();
    }

    public function hitungSubTotal($indexKuitansi)
    {
        $subTotal = 0;
        foreach ($this->trx[$indexKuitansi-1]["items"] as $item){
            $subTotal += ((float) $item["berat"] * (float) $this->decodeCurrency($item["harga"]) + (float) $this->decodeCurrency($item["ongkos"]));
            $item["harga"] = $this->decodeCurrency($item["harga"]);
        }
        $this->trx[$indexKuitansi-1]["sub_total"] = $subTotal;
    }

    public function updatingTotalKuitansi($value)
    {
        if ($value < 1 || $value == ""){

            $this->trx = [];
            $this->trx[] = [
                "sub_total" => 0,
                "items" => [
                    [
                        "jenis_id" => '',
                        "nama_jenis" => '',
                        "varian" => '',
                        "produk_id" => '',
                        "nama_produk" => '',
                        "berat" => $this->encodeCurrency(0),
                        "kadar" => $this->encodeCurrency(0),
                        "harga" => $this->encodeCurrency(0),
                        "ongkos" => $this->encodeCurrency(0),
                        "uploaded" => null
                    ]
                ]
            ];
            $this->calculateSisaPembayaran();
            return;
        }

        if ($value <= $this->totalKuitansi){
            for ($i=$this->totalKuitansi-1; $i >= $value; $i--){
               unset($this->trx[$i]);
               $this->trx = array_values($this->trx);
            }
        }

        for ($i=count($this->trx); $i < $value; $i++){
            $this->trx[] = [
                "sub_total" => 0,
                "items" => [
                    [
                        "jenis_id" => '',
                        "nama_jenis" => '',
                        "varian" => '',
                        "produk_id" => '',
                        "nama_produk" => '',
                        "berat" => 0,
                        "kadar" => 0,
                        "harga" => 0,
                        "ongkos" => 0,
                        "uploaded" => null
                    ]
                ]
            ];
        }
        $this->calculateSisaPembayaran();
    }

    public function render()
    {
        return view('livewire.create-penjualan');
    }
}
