<?php

namespace App\Http\Requests;

use App\Models\Karyawan;
use Gate;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Response;

class UpdateKaryawanRequest extends FormRequest
{
    public function authorize()
    {
        return Gate::allows('karyawan_edit');
    }

    public function rules()
    {
        return [
            'name' => [
                'required',
                'string',
            ],
            'alamat' => [
                'required',
            ],
            'bagian' => [
                'string',
                'required',
            ],
            'gaji' => [
                'required',
            ],
            'tanggal_masuk' => [
                'required',
                'date_format:' . config('panel.date_format'),
            ],
            'tanggal_keluar' => [
                'date_format:' . config('panel.date_format'),
                'nullable',
            ],
        ];
    }
}
