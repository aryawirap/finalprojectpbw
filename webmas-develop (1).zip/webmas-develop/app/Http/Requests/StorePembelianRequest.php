<?php

namespace App\Http\Requests;

use App\Models\Sale;
use Gate;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Response;

class StorePembelianRequest extends FormRequest
{
    public function authorize()
    {
        return Gate::allows('pembelian_create');
    }

    public function rules()
    {
        return [
            'noTrx' => [
                'string',
                'required',
            ],
            'customer_id' => [
                'integer',
                'required',
            ],
            'total_kuitansi' => [
                'required',
                'integer',
                'min:-2147483648',
                'max:2147483647',
            ],
            'grand_total' => [
                'required',
            ],
            'status' => [
                'required',
            ],
            'from' => [
                'required',
            ],
            'metode_pembayarans.*' => [
                'integer',
            ],
            'metode_pembayarans' => [
                'required',
                'array',
            ],
        ];
    }
}
