<?php

namespace App\Http\Requests;

use App\Models\GeneralConfig;
use Gate;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Response;

class StoreGeneralConfigRequest extends FormRequest
{
    public function authorize()
    {
        return Gate::allows('general_config_create');
    }

    public function rules()
    {
        return [
            'name' => [
                'string',
                'required',
                'unique:general_configs',
            ],
            'type' => [
                'required',
            ],
            'value' => [
                'string',
                'required',
            ],
        ];
    }
}
