<?php

namespace App\Http\Requests;

use App\Models\Hutang;
use Gate;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Response;

class UpdateHutangRequest extends FormRequest
{
    public function authorize()
    {
        return Gate::allows('hutang_edit');
    }

    public function rules()
    {
        return [
            'karyawan_id' => [
                'required',
                'integer',
            ],
            'jenis_barang_id' => [
                'nullable',
                'integer',
            ],
            'jenis_barang' => [
                'nullable',
                'string',
            ],
            'jumlah_hutang' => [
                'required',
            ]
            ,'jenis_hutang' => [
                'required',
            ],
            'nominal_cicilan' => [
                'required',
            ],
            'lama_cicilan' => [
                'required',
                'integer',
                'min:-2147483648',
                'max:2147483647',
            ],
        ];
    }
}
