<?php

namespace App\Http\Requests;

use App\Models\GeneralConfig;
use Gate;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Response;

class UpdateGeneralConfigRequest extends FormRequest
{
    public function authorize()
    {
        return Gate::allows('general_config_edit');
    }

    public function rules()
    {
        return [
            'website_name' => [
                'required',
            ],
            'logo' => [
                'nullable',
            ],
        ];
    }
}
