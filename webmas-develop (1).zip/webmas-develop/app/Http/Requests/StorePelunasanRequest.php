<?php

namespace App\Http\Requests;

use App\Models\Sale;
use Gate;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Response;

class StorePelunasanRequest extends FormRequest
{
    public function authorize()
    {
        return Gate::allows('pelunasan_create');
    }

    public function rules()
    {
        return [
            'metode_pembayaran_id' => [
                'integer',
                'required',
            ],
            'tanggal_pelunasan' => [
                'required',
            ],
        ];
    }
}
