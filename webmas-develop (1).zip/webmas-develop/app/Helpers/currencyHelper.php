<?php


if (! function_exists('decodeCurrency')) {
    function decodeCurrency($value)
    {
        $checkHasSpace = strpos($value," ");
        $formatted = str_replace([".","Rp"],"" ,$value);
        if ($checkHasSpace === false){ // ini untuk create
            return substr($formatted,2, strlen($formatted));
        }else{ // biasanya untuk edit
            return substr($formatted,1, strlen($formatted));
        }
    }
}

if (! function_exists('encodeCurrency')) {
    function encodeCurrency($value)
    {
        return 'Rp '. number_format($value,0, '.', '.');
    }
}

if (! function_exists('encodeCurrencyWithOutPrefix')) {
    function encodeCurrencyWithOutPrefix($value)
    {
        return number_format($value,0, '.', '.');
    }
}