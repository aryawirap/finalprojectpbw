<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\Models\Customer;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tb_pemesanan', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('noTrx');
            $table->foreignIdFor(Customer::class)->constrained();
            $table->integer('total_kuitansi');
            $table->double('grand_total', 15, 2);
            $table->double('sisa_pelunasan', 15, 2)->nullable();
            $table->integer('status')->default(0);
            $table->integer('from')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tb_pemesanan');
    }
};
