<?php

use App\Models\Pembelian;
use App\Models\Stock;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tb_kuitansi', function (Blueprint $table) {
            $table->foreignIdFor(Pembelian::class)->references('id')->on('tb_pembelian')->onDelete('cascade')->constrained();
            $table->foreignIdFor(Stock::class)->references('id')->on('stocks')->onDelete('cascade')->constrained();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tb_kuitansi');
    }
};
