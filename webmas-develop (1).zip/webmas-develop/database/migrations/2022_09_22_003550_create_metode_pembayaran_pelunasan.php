<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('metode_pembayaran_pelunasan', function (Blueprint $table) {
            $table->foreignIdFor(\App\Models\Pelunasan::class)->constrained()->cascadeOnDelete()->references('id')->on('tb_pelunasan');
            $table->foreignIdFor(\App\Models\MetodePembayaran::class)->constrained()->cascadeOnDelete();
            $table->integer("amount")->default(0);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('metode_pembayaran_pelunasan');
    }
};
