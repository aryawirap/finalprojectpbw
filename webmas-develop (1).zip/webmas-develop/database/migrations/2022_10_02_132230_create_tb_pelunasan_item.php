<?php

use App\Models\Pelunasan;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\Models\Category;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tb_pelunasan_item', function (Blueprint $table) {
            $table->id();
            $table->foreignIdFor(Pelunasan::class)->constrained()->cascadeOnDelete()->references('id')->on('tb_pelunasan');
            $table->foreignIdFor(Category::class)->constrained()->cascadeOnDelete();
            $table->integer("noKuitansi");
            $table->string("jenisEmas");
            $table->string("namaBarang");
            $table->double("berat");
            $table->double("kadar");
            $table->double("hargaPerGram");
            $table->double("hargaSekarang");
            $table->double("ongkos");
            $table->double("total");
            $table->string("image")->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tb_pelunasan_item');
    }
};
