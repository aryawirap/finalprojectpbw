<?php

use App\Models\Category;
use App\Models\Stock;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tukar_tambah_kurang_items', function (Blueprint $table) {
            $table->id();
            $table->foreignIdFor(\App\Models\TukarTambahKurang::class)->constrained()->cascadeOnDelete();
            $table->foreignIdFor(Category::class)->constrained()->cascadeOnDelete();
            $table->foreignIdFor(Stock::class)->constrained()->cascadeOnDelete();
            $table->integer("noKuitansi");
            $table->string("jenisEmas");
            $table->string("namaBarang");
            $table->double("berat");
            $table->double("kadar");
            $table->double("hargaPerGram");
            $table->double("hargaPerGramBaru");
            $table->double("potongan");
            $table->double("total");
            $table->string("image")->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tukar_tambah_kurang_items');
    }
};
