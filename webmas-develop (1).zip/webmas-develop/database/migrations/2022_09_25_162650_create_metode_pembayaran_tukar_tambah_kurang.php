<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('metode_pembayaran_tukarTambahKurang', function (Blueprint $table) {
            $table->unsignedBigInteger('tukar_tambah_kurang_id');
            $table->foreign('tukar_tambah_kurang_id', 'tukarTambahKurang_fk_7078341')->references('id')->on('tukar_tambah_kurangs')->cascadeOnDelete();
            $table->foreignIdFor(\App\Models\MetodePembayaran::class)->constrained()->cascadeOnDelete();
            $table->integer("amount")->default(0);
            $table->integer("return")->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('metode_pembayaran_tukar_tambah_kurang');
    }
};
