<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddRelationshipFieldsToHutangsTable extends Migration
{
    public function up()
    {
        Schema::table('hutangs', function (Blueprint $table) {
            $table->unsignedBigInteger('karyawan_id')->nullable();
            $table->foreign('karyawan_id', 'karyawan_fk_7220868')->references('id')->on('karyawans');
            $table->unsignedBigInteger('jenis_barang_id')->nullable();
            $table->foreign('jenis_barang_id', 'jenis_barang_fk_7221001')->references('id')->on('jenis_barang_hutangs');
        });
    }
}
