<?php

use App\Models\Category;
use App\Models\Pembelian;
use App\Models\Stock;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tb_pembelian_item', function (Blueprint $table) {
            $table->id();
            $table->foreignIdFor(Pembelian::class)->constrained()->cascadeOnDelete()->references('id')->on('tb_pembelian');
            $table->foreignIdFor(Category::class)->constrained()->cascadeOnDelete();
            $table->foreignIdFor(Stock::class)->constrained()->cascadeOnDelete();
            $table->integer('no');
            $table->string('jenis_emas');
            $table->string('nama_barang');
            $table->double('berat', 15, 2);
            $table->double('kadar', 15, 2);
            $table->double('harga_pergram', 15, 2);
            $table->double('potongan', 15, 2);
            $table->double('total', 15, 2);
            $table->string('images')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tb_pembelian_item');
    }
};
