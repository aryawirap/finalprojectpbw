<?php

use App\Models\MetodePembayaran;
use App\Models\Pembelian;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tb_pembelian_payment', function (Blueprint $table) {
            $table->foreignIdFor(Pembelian::class)->references('id')->on('tb_pembelian')->onDelete('cascade')->constrained();
            $table->foreignIdFor(MetodePembayaran::class)->references('id')->on('metode_pembayarans')->onDelete('cascade')->constrained();
            $table->double('value', 15, 2);
            $table->double('kembalian', 15, 2, true)->default(0);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tb_pembelian_payment');
    }
};
