<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('berangkas', function (Blueprint $table) {
            $table->id();
            $table->date("tanggal");
            $table->smallInteger("type_berangkas")->default(1)->comment('1 = berangkas, 2 = uang masuk, 3 = uang keluar');
            $table->smallInteger("type")->default(1)->comment('1 = pengurangan, 2 = penambahan');
            $table->longText("keterangan");
            $table->integer("jumlah");
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('berangkas');
    }
};
