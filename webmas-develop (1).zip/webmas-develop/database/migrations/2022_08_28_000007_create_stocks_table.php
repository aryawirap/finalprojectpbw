<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateStocksTable extends Migration
{
    public function up()
    {
        Schema::create('stocks', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('nama_barang');
            $table->integer('jumlah_product');
            $table->float('berat', 15, 2)->nullable();
            $table->float('karat', 15, 2)->nullable();
            $table->float('kadar', 15, 2)->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }
}
