<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\Models\Pemesanan;
use App\Models\MetodePembayaran;
use App\Models\Customer;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tb_pelunasan', function (Blueprint $table) {
            $table->id();
            $table->foreignIdFor(Pemesanan::class)->nullable()->references('id')->on('tb_pemesanan');
            $table->string('barkode');
            $table->date('tanggal_pelunasan');
            $table->string("noTrx");
            $table->integer("totalKuitansi");
            $table->foreignIdFor(Customer::class)->constrained();
            $table->integer("grandTotal");
            $table->longText("note")->nullable();
            $table->integer("status")->default(0)->comment("0 = belum lunas, 1 = lunas");
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tb_pelunasan');
    }
};
