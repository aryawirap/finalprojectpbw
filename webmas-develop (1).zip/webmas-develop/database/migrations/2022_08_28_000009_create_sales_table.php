<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSalesTable extends Migration
{
    public function up()
    {
        Schema::create('sales', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('no_trx');
            $table->string('nama_customer');
            $table->string('nomor_hp')->nullable();
            $table->integer('total_kuitansi');
            $table->decimal('grand_total', 15, 2);
            $table->timestamps();
            $table->softDeletes();
        });
    }
}
