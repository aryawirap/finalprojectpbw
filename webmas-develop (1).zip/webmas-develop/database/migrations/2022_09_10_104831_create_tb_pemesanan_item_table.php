<?php

use App\Models\Pemesanan;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\Models\Category;
use App\Models\Stock;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tb_pemesanan_item', function (Blueprint $table) {
            $table->id();
            $table->foreignIdFor(Pemesanan::class)->constrained()->cascadeOnDelete()->references('id')->on('tb_pemesanan')->onDelete('cascade')->constrained();
            $table->foreignIdFor(Category::class)->constrained()->cascadeOnDelete();
            $table->foreignIdFor(Stock::class)->cascadeOnDelete()->nullable();
            $table->integer('no');
            $table->string('jenis_emas');
            $table->string('nama_barang');
            $table->double('berat', 15, 2);
            $table->double('kadar', 15, 2);
            $table->double('harga_pergram', 15, 2);
            $table->double('ongkos', 15, 2);
            $table->double('total', 15, 2);
            $table->string('payment')->nullable();
            $table->date('selesai_pesanan')->nullable();
            $table->string('images')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tb_pemesanan_item');
    }
};
