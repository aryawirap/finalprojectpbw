<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up()
    {
        Schema::table('hutangs', function (Blueprint $table) {
            $table->double("sudahDibayar")->default(0);
            $table->smallInteger("status")->default(1)->comment("1 = belum lunas, 2 = lunas");
        });
    }

    public function down()
    {
        Schema::table('hutangs', function (Blueprint $table) {
            $table->dropColumn("sudahDibayar");
            $table->dropColumn("status");
        });
    }
};