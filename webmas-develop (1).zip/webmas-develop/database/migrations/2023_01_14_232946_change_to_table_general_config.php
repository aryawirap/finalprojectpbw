<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up()
    {
        Schema::table('general_configs', function (Blueprint $table) {
            $table->dropColumn("name");
            $table->dropColumn("type");
            $table->dropColumn("value");
            $table->string("website_name");
            $table->string("logo");
        });
    }

    public function down()
    {
        Schema::table('general_configs', function (Blueprint $table) {
            $table->dropColumn("website_name");
            $table->dropColumn("logo");
        });
    }
};