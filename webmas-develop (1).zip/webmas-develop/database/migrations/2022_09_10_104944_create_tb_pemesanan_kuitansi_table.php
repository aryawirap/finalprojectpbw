<?php

use App\Models\Pemesanan;
use App\Models\Stock;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tb_pemesanan_kuitansi', function (Blueprint $table) {
            $table->foreignIdFor(Pemesanan::class)->constrained()->references('id')->on('tb_pemesanan')->onDelete('cascade')->constrained();
            $table->foreignIdFor(Stock::class)->constrained();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tb_pemesanan_kuitansi');
    }
};
