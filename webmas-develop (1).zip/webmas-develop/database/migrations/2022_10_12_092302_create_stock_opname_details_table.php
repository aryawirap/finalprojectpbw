<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up()
    {
        Schema::create('stock_opname_details', function (Blueprint $table) {
            $table->id();
            $table->foreignIdFor(\App\Models\StockOpname::class)->constrained()->cascadeOnDelete();
            $table->smallInteger("type")->comment("1 = pengurangan penjualan, 2 = penambahan");
            $table->foreignIdFor(\App\Models\Penjualan::class)->nullable()->constrained()->cascadeOnDelete();
            $table->integer("jumlah");
            $table->longText("catatan")->nullable();
            $table->softDeletes();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('stock_opname_details');
    }
};