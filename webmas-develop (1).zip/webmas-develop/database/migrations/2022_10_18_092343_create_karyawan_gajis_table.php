<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up()
    {
        Schema::create('karyawan_gajis', function (Blueprint $table) {
            $table->id();
            $table->foreignIdFor(\App\Models\Karyawan::class)->constrained()->cascadeOnDelete();
            $table->double("gaji");
            $table->double("potongan");
            $table->date("tanggalGajian");
            $table->double("totalGaji");
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('karyawan_gajis');
    }
};