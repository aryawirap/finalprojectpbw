<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateHutangsTable extends Migration
{
    public function up()
    {
        Schema::create('hutangs', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('jenis_hutang')->nullable();
            $table->decimal('jumlah_hutang', 15, 2);
            $table->decimal('nominal_cicilan', 15, 2);
            $table->integer('lama_cicilan');
            $table->timestamps();
            $table->softDeletes();
        });
    }
}
