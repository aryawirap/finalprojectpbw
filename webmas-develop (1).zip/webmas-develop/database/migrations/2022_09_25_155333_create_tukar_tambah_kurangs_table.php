<?php

use App\Models\Customer;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tukar_tambah_kurangs', function (Blueprint $table) {
            $table->id();
            $table->string('noTrx');
            $table->foreignIdFor(Customer::class)->constrained();
            $table->integer('total_kuitansi');
            $table->integer('from')->default(0)->comment('0 = toko ini, 1 = toko lain');
            $table->double('grand_total', 15, 2);
            $table->integer('status')->default(0);
            $table->string('nota')->nullable();
            $table->smallInteger("type")->default(1)->comment("1 = tukar tambah, 2 = tukar kurang");
            $table->smallInteger("payment_type")->default(1)->comment("1 = single, 2 = multi");
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tukar_tambah_kurangs');
    }
};
