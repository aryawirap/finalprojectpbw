<?php

use App\Models\Customer;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('penjualans', function (Blueprint $table) {
            $table->id();
            $table->string("noTrx");
            $table->integer("totalKuitansi");
            $table->foreignIdFor(Customer::class)->constrained();
            $table->integer("grandTotal");
            $table->longText("note")->nullable();
            $table->integer("status")->default(0)->comment("0 = belum lunas, 1 = lunas");
            $table->integer("type")->default(1)->comment("1 = penjualan, 2 = pemesanan");
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('penjualans');
    }
};
