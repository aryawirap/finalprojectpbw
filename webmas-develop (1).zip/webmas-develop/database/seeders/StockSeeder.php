<?php

namespace Database\Seeders;

use App\Models\Stock;
use Illuminate\Database\Seeder;

class StockSeeder extends Seeder
{
    public function run()
    {
        Stock::create([
            'category_id' => 1,
            'berat' => 30,
            'jumlah_product' => 10,
            'kadar' => 35,
            'karat' => 40,
            'nama_barang' => 'Cincin anak'
        ]);
    }
}
