<?php

namespace Database\Seeders;

use App\Models\GeneralConfig;
use Illuminate\Database\Seeder;

class GeneralConfigTableSeeder extends Seeder
{
    public function run()
    {
        GeneralConfig::create([
            "website_name" => "Webmas",
            "logo" => ""
        ]);
    }
}
