<?php

namespace Database\Seeders;

use App\Models\Customer;
use Illuminate\Database\Seeder;

class CustomerSeeder extends Seeder
{
    public function run()
    {
        Customer::create([
            'email' => 'test@gmail.com',
            'nama' => 'testingCustomer',
            'nomor_hp' => '08999913',
        ]);
    }
}
