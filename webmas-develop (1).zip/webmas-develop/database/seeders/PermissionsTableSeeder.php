<?php

namespace Database\Seeders;

use App\Models\Permission;
use Illuminate\Database\Seeder;

class PermissionsTableSeeder extends Seeder
{
    public function run()
    {
        $permissions = [
            [
                'id'    => 1,
                'title' => 'user_management_access',
            ],
            [
                'id'    => 2,
                'title' => 'permission_create',
            ],
            [
                'id'    => 3,
                'title' => 'permission_edit',
            ],
            [
                'id'    => 4,
                'title' => 'permission_show',
            ],
            [
                'id'    => 5,
                'title' => 'permission_delete',
            ],
            [
                'id'    => 6,
                'title' => 'permission_access',
            ],
            [
                'id'    => 7,
                'title' => 'role_create',
            ],
            [
                'id'    => 8,
                'title' => 'role_edit',
            ],
            [
                'id'    => 9,
                'title' => 'role_show',
            ],
            [
                'id'    => 10,
                'title' => 'role_delete',
            ],
            [
                'id'    => 11,
                'title' => 'role_access',
            ],
            [
                'id'    => 12,
                'title' => 'user_create',
            ],
            [
                'id'    => 13,
                'title' => 'user_edit',
            ],
            [
                'id'    => 14,
                'title' => 'user_show',
            ],
            [
                'id'    => 15,
                'title' => 'user_delete',
            ],
            [
                'id'    => 16,
                'title' => 'user_access',
            ],
            [
                'id'    => 17,
                'title' => 'master_data_access',
            ],
            [
                'id'    => 18,
                'title' => 'category_create',
            ],
            [
                'id'    => 19,
                'title' => 'category_edit',
            ],
            [
                'id'    => 20,
                'title' => 'category_show',
            ],
            [
                'id'    => 21,
                'title' => 'category_delete',
            ],
            [
                'id'    => 22,
                'title' => 'category_access',
            ],
            [
                'id'    => 23,
                'title' => 'stock_create',
            ],
            [
                'id'    => 24,
                'title' => 'stock_edit',
            ],
            [
                'id'    => 25,
                'title' => 'stock_show',
            ],
            [
                'id'    => 26,
                'title' => 'stock_delete',
            ],
            [
                'id'    => 27,
                'title' => 'stock_access',
            ],
            [
                'id'    => 28,
                'title' => 'general_config_create',
            ],
            [
                'id'    => 29,
                'title' => 'general_config_edit',
            ],
            [
                'id'    => 30,
                'title' => 'general_config_show',
            ],
            [
                'id'    => 31,
                'title' => 'general_config_delete',
            ],
            [
                'id'    => 32,
                'title' => 'general_config_access',
            ],
            [
                'id'    => 33,
                'title' => 'audit_log_show',
            ],
            [
                'id'    => 34,
                'title' => 'audit_log_access',
            ],
            [
                'id'    => 35,
                'title' => 'transaksi_access',
            ],
            [
                'id'    => 36,
                'title' => 'sale_create',
            ],
            [
                'id'    => 37,
                'title' => 'sale_edit',
            ],
            [
                'id'    => 38,
                'title' => 'sale_show',
            ],
            [
                'id'    => 39,
                'title' => 'sale_delete',
            ],
            [
                'id'    => 40,
                'title' => 'sale_access',
            ],
            [
                'id'    => 41,
                'title' => 'metode_pembayaran_create',
            ],
            [
                'id'    => 42,
                'title' => 'metode_pembayaran_edit',
            ],
            [
                'id'    => 43,
                'title' => 'metode_pembayaran_show',
            ],
            [
                'id'    => 44,
                'title' => 'metode_pembayaran_delete',
            ],
            [
                'id'    => 45,
                'title' => 'metode_pembayaran_access',
            ],
            [
                'id'    => 46,
                'title' => 'customer_create',
            ],
            [
                'id'    => 47,
                'title' => 'customer_edit',
            ],
            [
                'id'    => 48,
                'title' => 'customer_show',
            ],
            [
                'id'    => 49,
                'title' => 'customer_delete',
            ],
            [
                'id'    => 50,
                'title' => 'customer_access',
            ],
            [
                'id'    => 51,
                'title' => 'karyawan_create',
            ],
            [
                'id'    => 52,
                'title' => 'karyawan_edit',
            ],
            [
                'id'    => 53,
                'title' => 'karyawan_show',
            ],
            [
                'id'    => 54,
                'title' => 'karyawan_delete',
            ],
            [
                'id'    => 55,
                'title' => 'karyawan_access',
            ],
            [
                'id'    => 56,
                'title' => 'jenis_barang_hutang_create',
            ],
            [
                'id'    => 57,
                'title' => 'jenis_barang_hutang_edit',
            ],
            [
                'id'    => 58,
                'title' => 'jenis_barang_hutang_show',
            ],
            [
                'id'    => 59,
                'title' => 'jenis_barang_hutang_delete',
            ],
            [
                'id'    => 60,
                'title' => 'jenis_barang_hutang_access',
            ],
            [
                'id'    => 61,
                'title' => 'hutang_create',
            ],
            [
                'id'    => 62,
                'title' => 'hutang_edit',
            ],
            [
                'id'    => 63,
                'title' => 'hutang_show',
            ],
            [
                'id'    => 64,
                'title' => 'hutang_delete',
            ],
            [
                'id'    => 65,
                'title' => 'hutang_access',
            ],
            [
                'id'    => 66,
                'title' => 'profile_password_edit',
            ],
            [
                'id'    => 67,
                'title' => 'pembelian_create',
            ],
            [
                'id'    => 68,
                'title' => 'pembelian_edit',
            ],
            [
                'id'    => 69,
                'title' => 'pembelian_show',
            ],
            [
                'id'    => 70,
                'title' => 'pembelian_delete',
            ],
            [
                'id'    => 71,
                'title' => 'pembelian_access',
            ],
            [
                'id'    => 72,
                'title' => 'pemesanan_create',
            ],
            [
                'id'    => 73,
                'title' => 'pemesanan_edit',
            ],
            [
                'id'    => 74,
                'title' => 'pemesanan_show',
            ],
            [
                'id'    => 75,
                'title' => 'pemesanan_delete',
            ],
            [
                'id'    => 76,
                'title' => 'pemesanan_access',
            ],
            [
                'id'    => 77,
                'title' => 'pelunasan_create',
            ],
            [
                'id'    => 78,
                'title' => 'pelunasan_edit',
            ],
            [
                'id'    => 79,
                'title' => 'pelunasan_show',
            ],
            [
                'id'    => 80,
                'title' => 'pelunasan_delete',
            ],
            [
                'id'    => 81,
                'title' => 'pelunasan_access',
            ],
            [
                'id'    => 82,
                'title' => 'master_karyawan_access',
            ],
            [
                'id'    => 83,
                'title' => 'finance_access',
            ],
            [
                'id'    => 84,
                'title' => 'tukar_tambah_kurang_access',
            ],
            [
                'id'    => 85,
                'title' => 'tukarTambahKurang_edit',
            ],
            [
                'id'    => 86,
                'title' => 'tukarTambahKurang_delete',
            ],
            [
                'id'    => 87,
                'title' => 'tukarTambahKurang_create',
            ],
            [
                'id'    => 88,
                'title' => 'berangkas_access',
            ],
            [
                'id'    => 89,
                'title' => 'berangkas_edit',
            ],
            [
                'id'    => 90,
                'title' => 'berangkas_delete',
            ],
            [
                'id'    => 91,
                'title' => 'berangkas_create',
            ],
            [
                'id' => 92,
                'title' => 'sale_invoice'
            ],
            [
                'id' => 93,
                'title' => 'tukarTambahKurang_invoice'
            ],
            [
                'id' => 94,
                'title' => 'pembelian_invoice'
            ],
            [
                'id' => 95,
                'title' => 'pemesanan_invoice'
            ],
            [
                'id' => 96,
                'title' => 'stockOpname_access'
            ],
            [
                'id' => 97,
                'title' => 'stockOpname_create'
            ],
            [
                'id' => 98,
                'title' => 'stockOpname_detail'
            ],
            [
                'id' => 99,
                'title' => 'gaji_show'
            ],
            [
                'id' => 100,
                'title' => 'gaji_edit'
            ],
            [
                'id' => 101,
                'title' => 'gaji_delete'
            ],
            [
                'id' => 102,
                'title' => 'gaji_access'
            ],
            [
                'id' => 103,
                'title' => 'pelunasan_invoice'
            ],
            [
                'id' => 104,
                'title' => 'gaji_create'
            ]
        ];

        Permission::insert($permissions);
    }
}
