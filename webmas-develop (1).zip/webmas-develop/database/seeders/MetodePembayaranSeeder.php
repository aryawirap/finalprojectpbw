<?php

namespace Database\Seeders;

use App\Models\MetodePembayaran;
use Illuminate\Database\Seeder;

class MetodePembayaranSeeder extends Seeder
{
    public function run()
    {
        $metodePembayaran = [
            [
                'nama_metode'             => "BCA",
            ],
            [
                'nama_metode'             => "MANDIRI",
            ],
            [
                'nama_metode'             => "CASH",
            ],
            [
                'nama_metode'             => "BRI",
            ],
            [
                'nama_metode'             => "BPTN",
            ],
            [
                'nama_metode'             => "BNI",
            ]
        ];
        MetodePembayaran::insert($metodePembayaran);
    }
}
